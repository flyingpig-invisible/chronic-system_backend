-- ============================================================
--  算法一：危急重症预警与组合升级
--    1) cd_warning_rule 增加 is_critical 标记「危急值规则」
--    2) cd_warning 增加 critical_flag / escalate_reason / escalate_type
--    3) 种入 8 条危急值规则（warning_level=3，is_critical=1）
--  可重复执行：全部用 IF NOT EXISTS 判断
-- ============================================================

SET @db := DATABASE();

-- ---------- 1. 规则表：危急值标记 ----------
SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE cd_warning_rule ADD COLUMN is_critical TINYINT NOT NULL DEFAULT 0 COMMENT ''是否危急值规则：1是''',
    'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'cd_warning_rule' AND COLUMN_NAME = 'is_critical'
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE cd_warning_rule ADD COLUMN combo_group VARCHAR(32) NULL COMMENT ''组合升级分组：同组指标同时异常可升级''',
    'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'cd_warning_rule' AND COLUMN_NAME = 'combo_group'
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------- 2. 预警表：升级结果落库 ----------
SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE cd_warning ADD COLUMN critical_flag CHAR(1) NOT NULL DEFAULT ''0'' COMMENT ''是否危急值：1是''',
    'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'cd_warning' AND COLUMN_NAME = 'critical_flag'
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE cd_warning ADD COLUMN escalate_type VARCHAR(16) NULL COMMENT ''升级类型：COMBO组合 / PERSIST持续''',
    'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'cd_warning' AND COLUMN_NAME = 'escalate_type'
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE cd_warning ADD COLUMN escalate_reason VARCHAR(200) NULL COMMENT ''升级原因说明''',
    'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'cd_warning' AND COLUMN_NAME = 'escalate_reason'
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE cd_warning ADD COLUMN origin_level CHAR(1) NULL COMMENT ''升级前等级''',
    'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'cd_warning' AND COLUMN_NAME = 'origin_level'
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------- 3. 危急值规则种子 ----------
-- 用 (disease_code, indicator_code, operator, threshold_value) 去重，避免重复插入
INSERT INTO cd_warning_rule
  (rule_name, disease_code, indicator_code, indicator_name, operator, threshold_value,
   threshold_desc, warning_level, duration_minutes, action_desc, status, is_critical, create_time)
SELECT * FROM (
  SELECT '高血压急症-收缩压危急' AS rule_name, '1' AS disease_code, 'sbp' AS indicator_code,
         '收缩压' AS indicator_name, '>=' AS operator, 200.00 AS threshold_value,
         '【危急值】收缩压 ≥ 200 mmHg' AS threshold_desc, '3' AS warning_level, 0 AS duration_minutes,
         '疑似高血压急症：立即静卧复测，评估靶器官损害（胸痛/呼吸困难/意识改变/视物模糊），通知上级医师并启动急救联动' AS action_desc,
         '0' AS status, 1 AS is_critical, NOW() AS create_time
  UNION ALL SELECT '高血压急症-舒张压危急','1','dbp','舒张压','>=',130.00,
         '【危急值】舒张压 ≥ 130 mmHg','3',0,
         '疑似高血压急症：立即静卧复测并评估靶器官损害，通知上级医师，必要时呼叫 120','0',1,NOW()
  UNION ALL SELECT '低血压休克-收缩压危急','1','sbp','收缩压','<=',80.00,
         '【危急值】收缩压 ≤ 80 mmHg','3',0,
         '疑似低血压/休克：平卧抬高下肢，立即复测并查意识、脉搏、尿量，通知上级医师并启动急救联动','0',1,NOW()
  UNION ALL SELECT '高血糖危象','2','glu','血糖','>=',25.00,
         '【危急值】血糖 ≥ 25.0 mmol/L','3',0,
         '疑似高血糖危象：核查是否漏用胰岛素，查酮体/电解质，补液并通知上级医师','0',1,NOW()
  UNION ALL SELECT '低血糖危象','2','glu','血糖','<=',2.80,
         '【危急值】血糖 ≤ 2.8 mmol/L','3',0,
         '低血糖危象：意识清醒者立即口服 15g 速效碳水并 15 分钟后复测；意识障碍立即静推葡萄糖并呼叫 120','0',1,NOW()
  UNION ALL SELECT '快速性心律失常','3','hr','心率','>=',150.00,
         '【危急值】静息心率 ≥ 150 次/分','3',0,
         '疑似快速性心律失常：静卧复测，评估胸痛/黑矇/晕厥，做心电图并通知上级医师','0',1,NOW()
  UNION ALL SELECT '严重心动过缓','3','hr','心率','<=',40.00,
         '【危急值】静息心率 ≤ 40 次/分','3',0,
         '疑似严重心动过缓：平卧复测，评估头晕/黑矇/晕厥，做心电图并通知上级医师','0',1,NOW()
  UNION ALL SELECT '呼吸衰竭风险-血氧危急','4','spo2','血氧SpO2','<=',85.00,
         '【危急值】血氧 SpO2 ≤ 85%','3',0,
         '呼吸衰竭风险：半坐位、保持气道通畅、必要时给氧，立即通知上级医师并呼叫 120','0',1,NOW()
  UNION ALL SELECT '呼吸窘迫-呼吸频率危急','4','rr','呼吸频率','>=',30.00,
         '【危急值】呼吸频率 ≥ 30 次/分','3',0,
         '呼吸窘迫：半坐位、评估三凹征与血氧，立即通知上级医师并呼叫 120','0',1,NOW()
) t
WHERE NOT EXISTS (
  SELECT 1 FROM cd_warning_rule r
  WHERE r.disease_code = t.disease_code
    AND r.indicator_code = t.indicator_code
    AND r.operator = t.operator
    AND r.threshold_value = t.threshold_value
);

-- ---------- 4. 组合升级分组（同一疾病的指标归为一组） ----------
UPDATE cd_warning_rule SET combo_group = CONCAT('D', disease_code)
WHERE combo_group IS NULL;

SELECT is_critical, COUNT(*) AS cnt FROM cd_warning_rule GROUP BY is_critical;
