-- ============================================================
--  算法三：GraphRAG —— 指南知识图谱
--    kb_triple 存「头实体 —关系→ 尾实体」，每条都带来源文档与章节
--    origin = SEED（人工从指南整理的基线） / AUTO（从文档正文规则抽取）
--  可重复执行
-- ============================================================

CREATE TABLE IF NOT EXISTS kb_triple (
  triple_id     BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  head_entity   VARCHAR(80)  NOT NULL COMMENT '头实体',
  relation      VARCHAR(40)  NOT NULL COMMENT '关系',
  tail_entity   VARCHAR(200) NOT NULL COMMENT '尾实体',
  disease_code  CHAR(1)      NULL COMMENT '病种：1高血压 2糖尿病 3冠心病 4慢阻肺 0通用',
  doc_id        BIGINT       NULL COMMENT '来源文档',
  source_title  VARCHAR(200) NULL COMMENT '来源文档标题',
  source_section VARCHAR(120) NULL COMMENT '来源章节',
  origin        VARCHAR(8)   NOT NULL DEFAULT 'SEED' COMMENT 'SEED/AUTO',
  weight        DECIMAL(3,2) NOT NULL DEFAULT 1.00 COMMENT '权重（人工整理高于自动抽取）',
  create_time   DATETIME     NULL,
  PRIMARY KEY (triple_id),
  KEY idx_head (head_entity),
  KEY idx_tail (tail_entity),
  KEY idx_disease (disease_code),
  KEY idx_doc (doc_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GraphRAG 三元组（指南知识图谱）';

-- 唯一约束：同一头实体+关系+尾实体不重复（用生成列做唯一索引，兼容长文本）
SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE kb_triple ADD COLUMN uniq_key VARCHAR(255) GENERATED ALWAYS AS (CONCAT(head_entity, ''|'', relation, ''|'', LEFT(tail_entity, 120))) STORED,
     ADD UNIQUE KEY uk_triple (uniq_key)',
    'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'kb_triple' AND COLUMN_NAME = 'uniq_key'
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------- 种子三元组（来源：kb_document 各篇指南章节） ----------
INSERT IGNORE INTO kb_triple
  (head_entity, relation, tail_entity, disease_code, doc_id, source_title, source_section, origin, weight, create_time)
SELECT t.* FROM (
  -- 高血压
  SELECT '高血压' AS h, '诊断标准' AS r, '诊室血压≥140/90mmHg' AS t2, '1' AS d, 103 AS doc,
         '高血压的诊断标准与分级' AS st, '第三章 诊断与分级 3.1 血压水平分类与定义' AS ss, 'SEED' AS o, 1.00 AS w, NOW() AS ct
  UNION ALL SELECT '高血压','降压目标','一般患者<140/90mmHg','1',104,'高血压患者的降压目标值','第四章 治疗目标 4.1 降压目标','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','降压目标','能耐受者及部分高危患者<130/80mmHg','1',104,'高血压患者的降压目标值','第四章 治疗目标 4.1 降压目标','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','降压目标_老年','65~79岁先降至<150/90mmHg，可耐受则<140/90mmHg','1',104,'高血压患者的降压目标值','第四章 治疗目标 4.1 降压目标','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','降压目标_老年','≥80岁降至<150/90mmHg即可','1',104,'高血压患者的降压目标值','第四章 治疗目标 4.1 降压目标','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','合并糖尿病或慢性肾病目标','<130/80mmHg，需监测肾功能与血钾','1',104,'高血压患者的降压目标值','第四章 治疗目标 4.1 降压目标','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','限钠','每日食盐<5g，减少酱油、腌制品、加工食品','1',105,'生活方式干预：限盐与饮食（高血压）','第五章 治疗 5.2 生活方式干预','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','推荐','富钾食物：新鲜蔬菜、水果、豆类','1',105,'生活方式干预：限盐与饮食（高血压）','第五章 治疗 5.2 生活方式干预','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','限制','饱和脂肪与胆固醇','1',105,'生活方式干预：限盐与饮食（高血压）','第五章 治疗 5.2 生活方式干预','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','控制体重','BMI<24kg/m²，男性腰围<90cm、女性<85cm','1',105,'生活方式干预：限盐与饮食（高血压）','第五章 治疗 5.2 生活方式干预','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','戒烟限酒','戒烟，不饮酒或严格限制','1',105,'生活方式干预：限盐与饮食（高血压）','第五章 治疗 5.2 生活方式干预','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','测量规范','静坐5分钟后测量2次取均值，早晚各测1次','1',101,'家庭血压测量的规范方法','第一章 血压测量 1.4 家庭血压监测','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','用药原则','长期规律服药，血压正常也不可自行停药','1',106,'高血压的用药原则与依从性','第六章 药物治疗 6.1 治疗原则','SEED',1.00,NOW()
  UNION ALL SELECT '高血压','急症警示','血压≥180/120mmHg伴胸痛、呼吸困难或意识改变需立即就医','1',107,'血压急症：什么情况必须立即就医','第七章 特殊类型 7.3 高血压急症','SEED',1.00,NOW()
  -- 2型糖尿病
  UNION ALL SELECT '2型糖尿病','诊断标准','空腹血糖≥7.0mmol/L','2',108,'2型糖尿病的诊断标准','第二章 诊断 2.1 诊断标准','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','诊断标准','餐后2小时血糖≥11.1mmol/L','2',108,'2型糖尿病的诊断标准','第二章 诊断 2.1 诊断标准','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','血糖控制目标','空腹4.4~7.0mmol/L','2',109,'2型糖尿病的血糖控制目标','第三章 控制目标 3.1 血糖控制目标','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','血糖控制目标','非空腹<10.0mmol/L','2',109,'2型糖尿病的血糖控制目标','第三章 控制目标 3.1 血糖控制目标','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','饮食原则','碳水化合物占总热量50%~60%','2',110,'糖尿病饮食治疗原则','第五章 医学营养治疗 5.2 营养素分配','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','推荐','低升糖指数食物（GI≤55）：全谷物、杂豆、绿叶蔬菜','2',110,'糖尿病饮食治疗原则','第五章 医学营养治疗 5.2 营养素分配','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','限制','添加糖与含糖饮料','2',110,'糖尿病饮食治疗原则','第五章 医学营养治疗 5.2 营养素分配','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','蛋白质占比','占总热量15%~20%，合并肾病者适当限制','2',110,'糖尿病饮食治疗原则','第五章 医学营养治疗 5.2 营养素分配','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','低血糖处理','口服15g速效碳水，15分钟后复测，未纠正立即就医','2',112,'低血糖的识别与处理','第十章 低血糖 10.2 处理流程','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','运动建议','每周150分钟中等强度有氧运动，避免空腹运动','2',111,'糖尿病运动治疗建议','第六章 运动治疗 6.1 运动原则','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','高血糖危象警示','血糖≥16.7mmol/L伴口渴多尿乏力需及时就医','2',113,'糖尿病酮症与高血糖危象警示','第九章 急性并发症 9.1 酮症酸中毒','SEED',1.00,NOW()
  UNION ALL SELECT '2型糖尿病','血糖监测','轮换采血部位，记录餐前餐后配对血糖','2',102,'居家血糖监测的规范方法','第二章 血糖监测 2.3 自我血糖监测方案','SEED',1.00,NOW()
  -- 冠心病
  UNION ALL SELECT '冠心病','危险因素','高血压、血脂异常、糖尿病、吸烟','3',114,'冠心病的危险因素与预防','第三章 危险因素与一级预防 3.2 危险因素管理','SEED',1.00,NOW()
  UNION ALL SELECT '冠心病','心绞痛特征','胸骨后压榨性疼痛，劳累或情绪激动诱发，休息或含服硝酸甘油可缓解','3',115,'心绞痛的识别与应对','第四章 临床表现 4.2 心绞痛','SEED',1.00,NOW()
  UNION ALL SELECT '冠心病','急救','胸痛持续>15分钟不缓解立即拨打120','3',116,'急性心肌梗死的急救要点','第八章 急性冠脉综合征 8.4 急救','SEED',1.00,NOW()
  UNION ALL SELECT '冠心病','运动康复','中等强度有氧运动，循序渐进，避免剧烈运动','3',117,'冠心病患者的运动与康复','第九章 心脏康复 9.1 运动处方','SEED',1.00,NOW()
  UNION ALL SELECT '冠心病','限制','饱和脂肪与高胆固醇食物','3',114,'冠心病的危险因素与预防','第三章 危险因素与一级预防 3.2 危险因素管理','SEED',1.00,NOW()
  UNION ALL SELECT '冠心病','戒烟','完全戒烟并避免二手烟','3',114,'冠心病的危险因素与预防','第三章 危险因素与一级预防 3.2 危险因素管理','SEED',1.00,NOW()
  -- 慢阻肺
  UNION ALL SELECT '慢阻肺','诊断标准','吸入支气管舒张剂后FEV1/FVC<70%','4',118,'慢阻肺的诊断与肺功能标准','第二章 诊断与评估 2.2 肺功能','SEED',1.00,NOW()
  UNION ALL SELECT '慢阻肺','稳定期治疗','长期规律吸入支气管舒张剂，不规范停药会加重','4',119,'慢阻肺的稳定期吸入治疗与用药依从性','第四章 稳定期治疗 4.3 吸入药物治疗','SEED',1.00,NOW()
  UNION ALL SELECT '慢阻肺','急性加重识别','呼吸困难加重、痰量增多或出现脓性痰','4',120,'慢阻肺急性加重的识别','第五章 急性加重 5.2 识别与分级','SEED',1.00,NOW()
  UNION ALL SELECT '慢阻肺','营养支持','高蛋白高热量饮食，少量多餐，避免餐后腹胀','4',121,'慢阻肺呼吸康复与营养支持','第六章 康复与支持 6.1 呼吸康复','SEED',1.00,NOW()
  UNION ALL SELECT '慢阻肺','戒烟','戒烟是延缓肺功能下降最有效的措施','4',122,'慢阻肺患者戒烟与疫苗预防','第七章 预防 7.1 戒烟与免疫接种','SEED',1.00,NOW()
  UNION ALL SELECT '慢阻肺','疫苗','每年接种流感疫苗，定期接种肺炎球菌疫苗','4',122,'慢阻肺患者戒烟与疫苗预防','第七章 预防 7.1 戒烟与免疫接种','SEED',1.00,NOW()
  UNION ALL SELECT '慢阻肺','呼吸康复','缩唇呼吸与腹式呼吸训练，每日2~3次','4',121,'慢阻肺呼吸康复与营养支持','第六章 康复与支持 6.1 呼吸康复','SEED',1.00,NOW()
  -- 通用
  UNION ALL SELECT '家庭血压监测','推荐','早晚各测1次，每次测2~3遍取均值并记录','0',101,'家庭血压测量的规范方法','第一章 血压测量 1.4 家庭血压监测','SEED',1.00,NOW()
  UNION ALL SELECT '家庭血糖监测','推荐','轮换采血部位，记录餐前餐后配对血糖','0',102,'居家血糖监测的规范方法','第二章 血糖监测 2.3 自我血糖监测方案','SEED',1.00,NOW()
) t
WHERE NOT EXISTS (
  SELECT 1 FROM kb_triple k
  WHERE k.head_entity = t.h AND k.relation = t.r AND k.tail_entity = t.t2
);

SELECT COUNT(*) AS total, SUM(origin='SEED') AS seed_cnt FROM kb_triple;
