-- ============================================================
--  算法四：多模态情绪感知     -> cd_emotion_log
--  算法五：病种感知膳食推荐   -> cd_food / cd_diet_plan
--  可重复执行
-- ============================================================

-- ---------- 算法四 ----------
CREATE TABLE IF NOT EXISTS cd_emotion_log (
  log_id        BIGINT      NOT NULL AUTO_INCREMENT,
  patient_id    BIGINT      NOT NULL COMMENT '患者ID',
  source        VARCHAR(16) NULL COMMENT '触发来源：AI_CHAT/MANUAL/VOICE_TEXT',
  text_content  VARCHAR(500) NULL COMMENT '本次分析的文本',
  text_score    INT         NULL COMMENT '文本模态得分 0-100（越高越负面）',
  text_label    VARCHAR(20) NULL COMMENT '文本情绪标签',
  text_hits     VARCHAR(200) NULL COMMENT '命中的情绪词',
  physio_score  INT         NULL COMMENT '生理模态得分 0-100',
  physio_note   VARCHAR(200) NULL COMMENT '生理模态依据',
  behavior_score INT        NULL COMMENT '行为模态得分 0-100',
  behavior_note VARCHAR(200) NULL COMMENT '行为模态依据',
  fused_score   INT         NULL COMMENT '融合风险分 0-100',
  emotion_level VARCHAR(10) NULL COMMENT '等级：CALM关注 CARE关注 WARN预警',
  advice        VARCHAR(500) NULL COMMENT '建议',
  create_time   DATETIME    NULL,
  PRIMARY KEY (log_id),
  KEY idx_patient (patient_id, create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='情绪感知记录（多模态融合）';

-- ---------- 算法五：食物营养库 ----------
CREATE TABLE IF NOT EXISTS cd_food (
  food_id    BIGINT       NOT NULL AUTO_INCREMENT,
  name       VARCHAR(50)  NOT NULL COMMENT '食物/菜品名',
  category   VARCHAR(16)  NOT NULL COMMENT '主食/蛋白/蔬菜/水果/奶类/坚果',
  serving_g  INT          NOT NULL DEFAULT 100 COMMENT '一份克数',
  kcal       DECIMAL(7,1) NOT NULL COMMENT '每100g能量',
  protein    DECIMAL(5,1) NOT NULL DEFAULT 0 COMMENT '每100g蛋白质',
  fat        DECIMAL(5,1) NOT NULL DEFAULT 0 COMMENT '每100g脂肪',
  sat_fat    DECIMAL(5,1) NOT NULL DEFAULT 0 COMMENT '每100g饱和脂肪',
  carb       DECIMAL(5,1) NOT NULL DEFAULT 0 COMMENT '每100g碳水',
  fiber      DECIMAL(4,1) NOT NULL DEFAULT 0 COMMENT '每100g膳食纤维',
  sodium_mg  DECIMAL(7,1) NOT NULL DEFAULT 0 COMMENT '每100g钠 mg',
  potassium_mg DECIMAL(7,1) NOT NULL DEFAULT 0 COMMENT '每100g钾 mg',
  gi         INT          NOT NULL DEFAULT 0 COMMENT '升糖指数，0表示不含碳水',
  tags       VARCHAR(80)  NULL COMMENT '低钠/低GI/高钾/高蛋白/高纤维/富不饱和脂肪',
  status     CHAR(1)      NOT NULL DEFAULT '1',
  PRIMARY KEY (food_id),
  UNIQUE KEY uk_food_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='食物营养库（每100g）';

-- ---------- 算法五：推荐结果 ----------
CREATE TABLE IF NOT EXISTS cd_diet_plan (
  plan_id       BIGINT      NOT NULL AUTO_INCREMENT,
  patient_id    BIGINT      NOT NULL,
  plan_date     DATE        NOT NULL COMMENT '适用日期',
  target_kcal   INT         NULL COMMENT '能量目标',
  disease_codes VARCHAR(16) NULL COMMENT '参与约束的病种',
  meals_json    MEDIUMTEXT  NULL COMMENT '三餐明细',
  totals_json   VARCHAR(1000) NULL COMMENT '全天营养合计',
  constraint_json VARCHAR(2000) NULL COMMENT '约束满足情况',
  score         DECIMAL(5,1) NULL COMMENT '方案得分 0-100',
  advice        VARCHAR(500) NULL COMMENT '提示建议',
  create_time   DATETIME    NULL,
  PRIMARY KEY (plan_id),
  KEY idx_patient_date (patient_id, plan_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='膳食推荐方案';

-- ---------- 食物库种子数据（每100g可食部） ----------
INSERT IGNORE INTO cd_food
 (name, category, serving_g, kcal, protein, fat, sat_fat, carb, fiber, sodium_mg, potassium_mg, gi, tags, status)
VALUES
 ('杂粮饭（糙米+燕麦+藜麦）','主食',100,110,3.2,1.0,0.2,22.0,2.2,3,95,55,'低GI,高纤维','1'),
 ('米饭（蒸）','主食',100,116,2.6,0.3,0.1,25.9,0.3,2,30,83,'','1'),
 ('荞麦面（煮）','主食',100,110,4.1,0.3,0.1,22.0,1.5,5,100,59,'低GI','1'),
 ('燕麦粥（无糖）','主食',100,68,2.4,1.4,0.3,12.0,1.7,2,90,55,'低GI,高纤维','1'),
 ('全麦馒头','主食',100,246,8.0,1.5,0.3,49.0,1.6,230,120,69,'高纤维','1'),
 ('蒸红薯','主食',100,86,1.6,0.2,0.1,20.0,1.6,28,130,77,'高钾,高纤维','1'),
 ('蒸玉米','主食',100,112,4.0,1.2,0.3,22.0,2.9,1,238,60,'高纤维,高钾','1'),
 ('山药（蒸）','主食',100,57,1.9,0.2,0.1,12.4,0.8,18,213,51,'低GI','1'),
 ('水煮蛋','蛋白',50,144,13.3,8.8,2.8,2.8,0,131,154,0,'高蛋白','1'),
 ('清蒸鲈鱼','蛋白',100,105,18.6,3.4,1.0,0,0,144,205,0,'高蛋白,富不饱和脂肪','1'),
 ('白灼鸡胸肉','蛋白',100,133,19.4,5.0,1.4,2.5,0,63,338,0,'高蛋白,低钠','1'),
 ('北豆腐','蛋白',100,98,12.2,4.8,0.7,2.0,0.5,7,106,0,'高蛋白,低钠','1'),
 ('清炖瘦牛肉','蛋白',100,190,20.0,11.0,4.5,1.0,0,60,280,0,'高蛋白','1'),
 ('白灼虾仁','蛋白',100,93,18.6,0.8,0.2,2.8,0,165,215,0,'高蛋白','1'),
 ('无糖豆浆','蛋白',250,31,3.0,1.6,0.2,1.2,0.4,3,48,0,'低钠,高蛋白','1'),
 ('低脂牛奶','奶类',250,43,3.4,1.3,0.8,5.0,0,44,110,27,'高蛋白','1'),
 ('无糖酸奶','奶类',150,72,3.2,3.3,2.1,4.9,0,50,150,36,'','1'),
 ('清炒西兰花','蔬菜',150,55,3.5,2.5,0.4,4.0,3.0,180,300,15,'高纤维,高钾','1'),
 ('凉拌菠菜（少油少盐）','蔬菜',150,40,2.6,1.5,0.2,3.0,2.2,150,500,15,'高钾,高纤维','1'),
 ('蒜蓉油菜','蔬菜',150,45,1.8,2.5,0.4,3.0,1.6,160,280,15,'高纤维','1'),
 ('清炒冬瓜','蔬菜',150,30,0.4,1.8,0.3,2.5,0.7,120,80,15,'低钠,低能量','1'),
 ('白灼秋葵','蔬菜',150,35,1.9,1.0,0.2,4.0,3.2,100,180,15,'高纤维','1'),
 ('香菇青菜','蔬菜',150,50,2.2,2.4,0.4,4.5,2.0,170,260,15,'高纤维','1'),
 ('木耳炒山药','蔬菜',150,80,2.0,3.0,0.5,11.0,2.4,150,250,45,'高纤维','1'),
 ('番茄炒蛋（少油）','蔬菜',150,95,5.5,6.0,1.6,4.0,0.9,210,200,15,'高蛋白','1'),
 ('紫菜蛋花汤（淡）','汤',250,25,2.0,1.2,0.4,1.5,0.4,300,180,0,'','1'),
 ('番茄豆腐汤（淡）','汤',250,35,2.8,1.6,0.3,2.5,0.6,250,220,0,'','1'),
 ('苹果','水果',150,54,0.2,0.2,0.0,13.0,1.2,1,119,36,'低GI,高纤维','1'),
 ('柚子','水果',150,42,0.8,0.2,0.0,9.5,0.4,3,119,25,'低GI,高钾','1'),
 ('蓝莓','水果',100,57,0.7,0.3,0.0,14.0,2.4,1,77,53,'低GI','1'),
 ('猕猴桃','水果',100,61,0.8,0.6,0.0,14.5,2.6,10,144,52,'低GI,高钾','1'),
 ('原味混合坚果','坚果',15,600,20.0,53.0,7.0,20.0,8.0,2,600,15,'富不饱和脂肪,高纤维','1');

SELECT COUNT(*) AS food_cnt FROM cd_food;
