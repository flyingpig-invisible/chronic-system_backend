-- ============================================================================
-- 算法五 数据底座升级：cd_food 接入《四种慢病饮食推荐与限制清单(1).xlsx》
-- ----------------------------------------------------------------------------
-- 变更内容
--   1. 新增四病种判定列（推荐/适量/限制）与判定依据文本，供算法五直接读判定，
--      不再由代码自造阈值。
--   2. 新增 max_g（单项每餐上限，按能量密度推导），避免"用 600g 山药凑能量"。
--   3. 新增 source，标明数据出处，便于溯源。
--   4. 数据本身由 backend/tools/import_food_xlsx.py 导入（1725 条），
--      本文件只负责表结构，不含 INSERT。
-- 说明：源表为食材表，无餐次分类；category 由导入脚本按名称规则推断，
--      status='0' 表示仅入库可查、不参与配餐组合（酒类、调味、纯油脂、生粮粉等）。
-- ============================================================================

ALTER TABLE cd_food
    ADD COLUMN max_g INT NOT NULL DEFAULT 300 COMMENT '单项每餐上限(g)' AFTER serving_g,
    ADD COLUMN verdict_htn VARCHAR(4) DEFAULT NULL COMMENT '高血压判定：推荐/适量/限制' AFTER status,
    ADD COLUMN evidence_htn VARCHAR(160) DEFAULT NULL COMMENT '高血压判定依据' AFTER verdict_htn,
    ADD COLUMN verdict_dm VARCHAR(4) DEFAULT NULL COMMENT '糖尿病判定' AFTER evidence_htn,
    ADD COLUMN evidence_dm VARCHAR(160) DEFAULT NULL COMMENT '糖尿病判定依据' AFTER verdict_dm,
    ADD COLUMN verdict_chd VARCHAR(4) DEFAULT NULL COMMENT '冠心病判定' AFTER evidence_dm,
    ADD COLUMN evidence_chd VARCHAR(160) DEFAULT NULL COMMENT '冠心病判定依据' AFTER verdict_chd,
    ADD COLUMN verdict_copd VARCHAR(4) DEFAULT NULL COMMENT '慢阻肺判定' AFTER evidence_chd,
    ADD COLUMN evidence_copd VARCHAR(160) DEFAULT NULL COMMENT '慢阻肺判定依据' AFTER verdict_copd,
    ADD COLUMN source VARCHAR(80) DEFAULT NULL COMMENT '数据来源' AFTER evidence_copd;

CREATE INDEX idx_food_cat_status ON cd_food (category, status);
