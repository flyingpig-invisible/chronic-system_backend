-- 算法五·份量修正：解决「干制奶制品按一杯奶配餐」「百页按 100g 配餐」导致蛋白虚高、碳水被挤低
-- 只改份量与可选状态，不动 food_id，历史膳食方案仍可解析

-- 1) 干制奶制品 / 奶豆腐（实为奶粉或奶酪块，蛋白 45~55g/100g）不作日常奶类配餐
UPDATE cd_food SET status = '0'
WHERE category = '奶类'
  AND (name LIKE '%干酸奶%' OR name LIKE '%奶疙瘩%' OR name LIKE '%奶酷%'
       OR name LIKE '%酸酪%' OR name LIKE '%奶豆腐%' OR name LIKE '%奶皮%');

-- 2) 蛋白类能量密度 ≥200 kcal/100g 的（腐竹、百页、千张、豆腐皮等干货）一份 40g，上限 90g
UPDATE cd_food SET serving_g = 40, max_g = 90
WHERE category = '蛋白' AND status = '1' AND kcal >= 200 AND serving_g > 40;

-- 3) 干制蔬菜（苔菜等蛋白 19g/100g 的干海菜）不作鲜蔬配餐
UPDATE cd_food SET status = '0'
WHERE category = '蔬菜' AND (name LIKE '%苔菜%' OR name LIKE '%紫菜(干)%' OR name LIKE '%海带(干)%');

-- 4) 干豆类主食（豌豆(干)/蚕豆/绿豆/赤豆）蛋白高，一份压到 80g
UPDATE cd_food SET serving_g = 80, max_g = 80
WHERE category = '主食' AND status = '1' AND protein >= 15;

SELECT category, COUNT(*) FROM cd_food WHERE status='1' GROUP BY category;
