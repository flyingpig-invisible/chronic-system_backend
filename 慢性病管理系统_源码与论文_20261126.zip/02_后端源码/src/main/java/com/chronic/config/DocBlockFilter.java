package com.chronic.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * 生产环境文档屏蔽（仅 prod profile 生效）
 * <p>
 * knife4j 的 {@code enable=false} / {@code production=true} 只是关闭增强功能与数据，
 * doc.html 静态页仍可能被其它配置注册，因此在 Servlet 层做一次确定性拦截，
 * 避免接口清单对外暴露。
 *
 * @author chronic
 */
@Component
@Profile("prod")
public class DocBlockFilter extends OncePerRequestFilter {

    private static final String[] BLOCKED_PREFIXES = {
            "/webjars/", "/v3/api-docs", "/swagger-ui"
    };

    private static final String[] BLOCKED_PATHS = {
            "/doc.html", "/swagger-ui.html"
    };

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String uri = request.getRequestURI();

        boolean blocked = false;
        for (String path : BLOCKED_PATHS) {
            if (uri.equals(path)) {
                blocked = true;
                break;
            }
        }
        if (!blocked) {
            for (String prefix : BLOCKED_PREFIXES) {
                if (uri.startsWith(prefix)) {
                    blocked = true;
                    break;
                }
            }
        }

        if (blocked) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            response.setContentType("application/json");
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
            response.getWriter().write("{\"code\":404,\"msg\":\"资源不存在\",\"data\":null}");
            return;
        }
        chain.doFilter(request, response);
    }
}
