package com.chronic.config;

import com.chronic.common.result.Result;
import com.chronic.common.result.ResultCode;
import com.chronic.security.JwtAuthenticationFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Spring Security 配置
 *
 * @author chronic
 */
@Configuration
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final ObjectMapper objectMapper;

    /** 无需认证的路径 */
    public static final String[] WHITE_LIST = {
            "/auth/login",
            "/auth/register",
            "/auth/captcha",
            "/mp/auth/login",
            "/mp/auth/register",
            "/mp/auth/reset-password",
            // 注册页需要展示科室选项，此时用户尚未登录（仅返回科室名称，无隐私数据）
            "/mp/dept/options",
            "/doc.html",
            "/webjars/**",
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/swagger-ui.html",
            "/favicon.ico",
            "/profile/**",
            "/upload/**",
            "/error"
    };

    /**
     * 后端接口/资源路径前缀。
     * 不在这些前缀下的 GET 请求会被当作前端 SPA 路由（history 模式）处理。
     */
    private static final String[] BACKEND_PREFIXES = {
            "/auth", "/mp", "/chronic", "/system", "/device", "/kb", "/ai", "/simdata",
            "/upload", "/profile", "/doc.html", "/webjars", "/v3/api-docs",
            "/swagger-ui", "/swagger-ui.html", "/error"
    };

    /** 判断 URI 是否属于后端接口/资源（用于区分前端路由与后端请求） */
    public static boolean isBackendPath(String uri) {
        for (String prefix : BACKEND_PREFIXES) {
            if (uri.equals(prefix) || uri.startsWith(prefix + "/")) {
                return true;
            }
        }
        return false;
    }

    /**
     * 前端 SPA 请求：GET 请求，满足以下任一条件即视为前端请求。
     *
     * <ol>
     *   <li>路径不属于后端接口前缀 —— 普通的 history 路由，如 /dashboard、/patient/list；</li>
     *   <li>路径虽与接口前缀重名（/system/indicator、/ai/chat、/kb/document），
     *       但请求来自浏览器地址栏导航或 F5 刷新 —— 判据是 Accept 含 text/html。</li>
     * </ol>
     *
     * <p>axios 发出的请求 Accept 只有 application/json 与 text/plain，不含 text/html，
     * 所以同名前缀下的真实接口调用仍然会走鉴权，未登录时照常拿到 401 JSON。</p>
     */
    public static boolean isSpaRequest(jakarta.servlet.http.HttpServletRequest request) {
        if (!"GET".equalsIgnoreCase(request.getMethod())) {
            return false;
        }
        String uri = request.getRequestURI();
        if (!isBackendPath(uri)) {
            return true;
        }
        return isBrowserNavigation(request) && !isDocPath(uri);
    }

    /** 是否浏览器地址栏导航/刷新（Accept 含 text/html）；接口调用不含该值 */
    public static boolean isBrowserNavigation(jakarta.servlet.http.HttpServletRequest request) {
        String accept = request.getHeader("Accept");
        return accept != null && accept.toLowerCase().contains("text/html");
    }

    /** 接口文档与静态资源：即使用浏览器直接打开，也应返回原始内容而不是前端页面 */
    public static boolean isDocPath(String uri) {
        return uri.startsWith("/doc.html")
                || uri.startsWith("/swagger-ui")
                || uri.startsWith("/v3/api-docs")
                || uri.startsWith("/webjars");
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()))
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> {
                auth.requestMatchers(WHITE_LIST).permitAll();
                // 前端 SPA：静态资源与 history 路由（非后端前缀的 GET）直接放行，业务鉴权由接口上的 @PreAuthorize 负责
                auth.requestMatchers(SecurityConfig::isSpaRequest).permitAll();
                auth.requestMatchers(org.springframework.security.web.util.matcher.AntPathRequestMatcher.antMatcher("/mp/**")).authenticated();
                auth.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        .anyRequest().authenticated();
            })
            .exceptionHandling(ex -> ex
                    .authenticationEntryPoint((request, response, e) ->
                            writeJson(response, Result.error(ResultCode.UNAUTHORIZED, "未登录或登录已过期")))
                    .accessDeniedHandler((request, response, e) ->
                            writeJson(response, Result.error(ResultCode.FORBIDDEN, "没有访问权限")))
            )
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
            ;

        return http.build();
    }

    private void writeJson(HttpServletResponse response, Result<?> result) throws java.io.IOException {
        response.setStatus(200);
        response.setContentType("application/json;charset=UTF-8");
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.getWriter().write(objectMapper.writeValueAsString(result));
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOriginPatterns(List.of("*"));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
