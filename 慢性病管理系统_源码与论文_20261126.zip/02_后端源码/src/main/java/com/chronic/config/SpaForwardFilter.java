package com.chronic.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * 前端单页应用（history 路由）转发过滤
 *
 * <p>前端使用 createWebHistory()，直接访问 /dashboard 之类的子路由时服务端并没有对应资源，
 * 需要把请求转交给 index.html，由前端路由接管，否则刷新就是 404。</p>
 *
 * <p><b>为什么不能只靠路径前缀判断：</b>前端路由 /system/user、/system/indicator、/ai/chat
 * 与后端接口前缀 /system、/ai 是重名的。如果只按前缀排除，在地址栏直接访问（或按 F5 刷新）
 * 这些页面时，请求会被当成后端接口处理，返回的是 401/404 的 JSON 而不是页面。</p>
 *
 * <p><b>判断顺序（先认浏览器，再认路径）：</b></p>
 * <ol>
 *   <li>带扩展名 → 静态资源，放行（js/css/png/vrm 等）；</li>
 *   <li>Accept 含 text/html → 是浏览器地址栏导航/刷新，一律转 index.html，哪怕路径与接口前缀重名；</li>
 *   <li>其余若不在后端前缀内 → 也转 index.html（兼容 curl 等无 Accept 的访问）；</li>
 *   <li>剩下的才是真正的接口请求，交给业务处理。</li>
 * </ol>
 * <p>axios 发出的请求 Accept 为 application/json 与 text/plain（外加通配符），不含 text/html，
 * 因此不会被误转发，未登录时仍然能正常拿到 401 JSON。</p>
 *
 * <p><b>注意：</b>本注释里不要出现星号加斜杠的组合，否则会被当成注释结束符。</p>
 *
 * @author chronic
 */
@Component
public class SpaForwardFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String uri = request.getRequestURI();
        boolean isGet = "GET".equalsIgnoreCase(request.getMethod());
        // 带扩展名的一律视为静态资源（js/css/png/glb/vrm 等），交给静态资源处理器
        boolean hasExtension = uri.lastIndexOf('.') > uri.lastIndexOf('/');

        if (isGet && !hasExtension) {
            // 浏览器导航优先：即使路径与 /system、/ai、/kb 等接口前缀重名，也应当返回前端页面。
            // 接口文档路径除外，浏览器直接打开 /v3/api-docs 时应当返回 JSON 而不是页面。
            boolean browserNav = SecurityConfig.isBrowserNavigation(request) && !SecurityConfig.isDocPath(uri);
            if (browserNav || !SecurityConfig.isBackendPath(uri)) {
                request.getRequestDispatcher("/index.html").forward(request, response);
                return;
            }
        }
        chain.doFilter(request, response);
    }
}
