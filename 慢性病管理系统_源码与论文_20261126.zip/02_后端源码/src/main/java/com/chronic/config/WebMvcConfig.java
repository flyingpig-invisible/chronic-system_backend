package com.chronic.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web MVC 配置
 *
 * @author chronic
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Value("${chronic.upload-path}")
    private String uploadPath;

    private final Environment environment;

    public WebMvcConfig(Environment environment) {
        this.environment = environment;
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 本地上传文件映射
        registry.addResourceHandler("/upload/**")
                .addResourceLocations("file:" + uploadPath + "/");
        // Knife4j 静态资源：生产环境（knife4j.enable=false）不再注册，避免文档页对外暴露
        if (this.isDocEnabled()) {
            registry.addResourceHandler("/doc.html")
                    .addResourceLocations("classpath:/META-INF/resources/");
            registry.addResourceHandler("/webjars/**")
                    .addResourceLocations("classpath:/META-INF/resources/webjars/");
        }
    }

    /** 文档页开关：读不到配置时默认开启（开发环境行为不变） */
    private boolean isDocEnabled() {
        return Boolean.parseBoolean(environment.getProperty("knife4j.enable", "true"));
    }
}
