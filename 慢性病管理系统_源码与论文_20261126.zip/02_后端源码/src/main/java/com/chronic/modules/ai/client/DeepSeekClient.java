package com.chronic.modules.ai.client;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.chronic.common.exception.ServiceException;
import com.chronic.config.AiProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DeepSeek 大模型客户端
 *
 * @author chronic
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DeepSeekClient {

    private final AiProperties aiProperties;

    /** 发送多轮对话，返回模型回复 */
    public ChatResult chat(String systemPrompt, List<Map<String, String>> messages) {
        if (Boolean.FALSE.equals(aiProperties.getEnabled())) {
            throw new ServiceException("AI 健康助手当前未启用，请联系管理员");
        }
        if (aiProperties.getApiKey() == null || aiProperties.getApiKey().isBlank()) {
            throw new ServiceException("AI 服务未配置 API Key");
        }

        JSONArray msgArr = new JSONArray();
        if (systemPrompt != null && !systemPrompt.isBlank()) {
            JSONObject sys = new JSONObject();
            sys.set("role", "system");
            sys.set("content", systemPrompt);
            msgArr.add(sys);
        }
        for (Map<String, String> m : messages) {
            JSONObject o = new JSONObject();
            o.set("role", m.get("role"));
            o.set("content", m.get("content"));
            msgArr.add(o);
        }

        JSONObject body = new JSONObject();
        body.set("model", aiProperties.getModel());
        body.set("messages", msgArr);
        body.set("temperature", aiProperties.getTemperature());
        body.set("max_tokens", aiProperties.getMaxTokens());
        body.set("stream", false);

        String url = aiProperties.getBaseUrl() + "/chat/completions";
        long start = System.currentTimeMillis();
        String payload = body.toString();

        // 连接超时和读取超时必须分开设：
        // 连不上是网络/DNS 问题，几秒内就该失败；陪着读等满 60 秒，用户看到的是「转圈到超时」，
        // 而且会把一次瞬时抖动放大成 60 秒的卡死。
        int readTimeout = aiProperties.getTimeout() == null ? 60000 : aiProperties.getTimeout();
        // 连接 5 秒为上限：配合下方一次重试，最坏 11 秒出结果，不会让医生干等到 60 秒
        int connectTimeout = Math.max(3000, Math.min(5000, readTimeout / 10));

        HttpResponse response = executeWithRetry(url, payload, connectTimeout, readTimeout);
        try (HttpResponse resp = response) {
            String respBody = resp.body();
            int status = resp.getStatus();
            if (!resp.isOk()) {
                log.error("DeepSeek 调用失败, status={}, body={}", status, respBody);
                throw new ServiceException(friendlyHttpMessage(status));
            }

            JSONObject json;
            try {
                json = JSONUtil.parseObj(respBody);
            } catch (Exception e) {
                log.error("DeepSeek 响应无法解析, body={}", respBody, e);
                throw new ServiceException("AI 助手返回内容异常，请稍后重试");
            }
            JSONArray choices = json.getJSONArray("choices");
            if (choices == null || choices.isEmpty()) {
                log.error("DeepSeek 响应无 choices, body={}", respBody);
                throw new ServiceException("AI 助手没有给出回答，请换个问法再试");
            }
            String content = choices.getJSONObject(0).getJSONObject("message").getStr("content");

            ChatResult result = new ChatResult();
            result.setAnswer(content);
            result.setCostTime(System.currentTimeMillis() - start);
            JSONObject usage = json.getJSONObject("usage");
            if (usage != null) {
                result.setPromptTokens(usage.getInt("prompt_tokens", 0));
                result.setCompletionTokens(usage.getInt("completion_tokens", 0));
            }
            return result;
        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw translate(e);
        }
    }

    /**
     * 发请求，连接阶段失败自动重试一次。
     * <p>只有「根本没连上服务器」才重试——这种失败请求肯定没进模型，不会重复计费；
     * 读超时则可能是模型正在生成，重试会造成双份 token 消耗，所以不重试。</p>
     */
    private HttpResponse executeWithRetry(String url, String payload, int connectTimeout, int readTimeout) {
        for (int attempt = 1; ; attempt++) {
            try {
                return HttpRequest.post(url)
                        .header("Authorization", "Bearer " + aiProperties.getApiKey())
                        .header("Content-Type", "application/json")
                        .body(payload)
                        .setConnectionTimeout(connectTimeout)
                        .setReadTimeout(readTimeout)
                        .execute();
            } catch (Exception e) {
                if (attempt == 1 && isConnectFailure(e)) {
                    log.warn("AI 服务连接失败，1 秒后重试一次（{}）", rootMessage(e));
                    try {
                        Thread.sleep(1000L);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw translate(e);
                    }
                    continue;
                }
                throw translate(e);
            }
        }
    }

    /**
     * 是否属于「没连上服务器」类失败——可安全重试，不会重复计费。
     * <p>注意 hutool 会把底层异常包一层（如 IORuntimeException），
     * 且「连接超时」抛的是 {@code SocketTimeoutException("Connect timed out")} 而不是 ConnectException，
     * 所以必须沿 cause 链判断，不能只看最外层类型。</p>
     */
    private boolean isConnectFailure(Throwable e) {
        if (hasCause(e, java.net.ConnectException.class)
                || hasCause(e, java.net.UnknownHostException.class)
                || hasCause(e, java.net.NoRouteToHostException.class)) {
            return true;
        }
        // 「Connect timed out」是连接阶段超时，可重试；「Read timed out」是模型已开始生成，不能重试
        if (hasCause(e, java.net.SocketTimeoutException.class)) {
            return rootMessage(e).toLowerCase().contains("connect");
        }
        return false;
    }

    /** 沿 cause 链判断是否出现某类异常 */
    private boolean hasCause(Throwable e, Class<? extends Throwable> type) {
        Throwable t = e;
        while (t != null) {
            if (type.isInstance(t)) {
                return true;
            }
            if (t.getCause() == t) {
                break;
            }
            t = t.getCause();
        }
        return false;
    }

    /**
     * 把技术异常翻译成医生看得懂的话。
     * <p>原始堆栈只进日志，绝不回传给前端——否则界面会出现
     * 「ConnectException: Connection timed out: getsockopt」这种字样。</p>
     */
    private ServiceException translate(Exception e) {
        log.error("DeepSeek 调用异常（{}）", rootMessage(e), e);

        if (hasCause(e, java.net.UnknownHostException.class)) {
            return new ServiceException("AI 助手暂时不可用，请稍后重试");
        }
        if (hasCause(e, java.net.ConnectException.class)) {
            return new ServiceException("AI 助手暂时连接不上，请稍后重试");
        }
        if (hasCause(e, java.net.NoRouteToHostException.class)) {
            return new ServiceException("AI 助手暂时不可用，请联系管理员检查服务器出网");
        }
        if (hasCause(e, java.net.SocketTimeoutException.class)) {
            return rootMessage(e).toLowerCase().contains("connect")
                    ? new ServiceException("AI 助手暂时连接不上，请稍后重试")
                    : new ServiceException("AI 助手响应超时，请稍后重试");
        }
        if (hasCause(e, javax.net.ssl.SSLException.class)) {
            return new ServiceException("AI 助手安全连接失败，请联系管理员");
        }
        return new ServiceException("AI 助手暂时不可用，请稍后重试");
    }

    /** HTTP 状态码 -> 对用户有意义的中文说明 */
    private String friendlyHttpMessage(int status) {
        switch (status) {
            case 401:
                return "AI 助手配置有误（鉴权失败），请联系管理员";
            case 402:
                return "AI 服务额度已用完，请联系管理员";
            case 404:
                return "AI 助手配置有误（接口地址不存在），请联系管理员";
            case 429:
                return "提问太频繁了，请等几秒再问";
            default:
                return status >= 500
                        ? "AI 服务繁忙，请稍后重试"
                        : "AI 助手调用失败（" + status + "），请稍后重试";
        }
    }

    /** 取最内层异常的类型与消息，用于日志 */
    private String rootMessage(Throwable e) {
        Throwable t = e;
        while (t.getCause() != null && t.getCause() != t) {
            t = t.getCause();
        }
        return t.getClass().getSimpleName() + ": " + t.getMessage();
    }

    /** 简单单轮对话 */
    public ChatResult chat(String systemPrompt, String userMessage) {
        List<Map<String, String>> messages = new ArrayList<>();
        Map<String, String> m = new LinkedHashMap<>();
        m.put("role", "user");
        m.put("content", userMessage);
        messages.add(m);
        return chat(systemPrompt, messages);
    }

    /** 调用结果 */
    public static class ChatResult {
        private String answer;
        private Long costTime;
        private Integer promptTokens = 0;
        private Integer completionTokens = 0;

        public String getAnswer() { return answer; }
        public void setAnswer(String answer) { this.answer = answer; }
        public Long getCostTime() { return costTime; }
        public void setCostTime(Long costTime) { this.costTime = costTime; }
        public Integer getPromptTokens() { return promptTokens; }
        public void setPromptTokens(Integer promptTokens) { this.promptTokens = promptTokens; }
        public Integer getCompletionTokens() { return completionTokens; }
        public void setCompletionTokens(Integer completionTokens) { this.completionTokens = completionTokens; }
    }
}
