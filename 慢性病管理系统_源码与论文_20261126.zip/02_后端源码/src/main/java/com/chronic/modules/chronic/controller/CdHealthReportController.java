package com.chronic.modules.chronic.controller;

import com.chronic.common.result.Result;
import com.chronic.modules.chronic.service.CdHealthReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 健康报告
 *
 * <p>报告为只读的实时生成结果，不落库：每次调用都基于当前监测、预警、评分数据重新计算，
 * 保证报告内容与系统数据一致、结论可回溯。</p>
 *
 * @author chronic
 */
@Tag(name = "13-健康报告", description = "按患者生成带依据的健康报告，支持自定义统计窗口")
@RestController
@RequestMapping("/chronic/report")
@RequiredArgsConstructor
public class CdHealthReportController {

    private final CdHealthReportService healthReportService;

    @Operation(summary = "生成患者健康报告（含结论、依据清单与建议）")
    @PreAuthorize("@ss.hasPermi('chronic:patient:query')")
    @GetMapping("/{patientId}")
    public Result<Map<String, Object>> generate(
            @Parameter(description = "患者ID") @PathVariable Long patientId,
            @Parameter(description = "统计窗口天数，默认 30，范围 7～365")
            @RequestParam(required = false, defaultValue = "30") Integer days) {
        return Result.success(healthReportService.generate(patientId, days));
    }
}
