package com.chronic.modules.chronic.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.chronic.common.exception.ServiceException;
import com.chronic.common.result.Result;
import com.chronic.modules.chronic.entity.CdScoreWeight;
import com.chronic.modules.chronic.mapper.CdScoreWeightMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

/**
 * 病种评分权重配置
 *
 * <p>对应表 cd_score_weight：按「病种 + 指标」维护权重，用于病种维度的评分口径。
 * 与「患者专属四项权重」（cd_patient_score_weight）是两套配置，互不影响。</p>
 *
 * @author chronic
 */
@Tag(name = "12-评分权重配置", description = "按病种+指标维护评分权重")
@RestController
@RequestMapping("/chronic/score/weight")
@RequiredArgsConstructor
public class CdScoreWeightController {

    private final CdScoreWeightMapper weightMapper;

    @Operation(summary = "按病种查询权重列表")
    @PreAuthorize("@ss.hasPermi('chronic:score:list')")
    @GetMapping("/list")
    public Result<List<CdScoreWeight>> list(@RequestParam(required = false) String diseaseCode) {
        LambdaQueryWrapper<CdScoreWeight> w = Wrappers.<CdScoreWeight>lambdaQuery()
                .eq(StringUtils.hasText(diseaseCode), CdScoreWeight::getDiseaseCode, diseaseCode)
                .orderByAsc(CdScoreWeight::getDiseaseCode)
                .orderByDesc(CdScoreWeight::getWeight);
        return Result.success(weightMapper.selectList(w));
    }

    @Operation(summary = "新增或更新权重（同病种同指标则覆盖）")
    @PreAuthorize("@ss.hasPermi('chronic:score:list')")
    @PostMapping
    public Result<Void> save(@RequestBody CdScoreWeight weight) {
        if (!StringUtils.hasText(weight.getDiseaseCode()) || !StringUtils.hasText(weight.getIndicatorCode())) {
            throw new ServiceException("病种与指标不能为空");
        }
        if (weight.getWeight() == null) {
            throw new ServiceException("权重不能为空");
        }
        if (weight.getWeight().compareTo(BigDecimal.ZERO) < 0
                || weight.getWeight().compareTo(BigDecimal.ONE) > 0) {
            throw new ServiceException("权重必须在 0~1 之间");
        }
        CdScoreWeight exist = weightMapper.selectOne(Wrappers.<CdScoreWeight>lambdaQuery()
                .eq(CdScoreWeight::getDiseaseCode, weight.getDiseaseCode())
                .eq(CdScoreWeight::getIndicatorCode, weight.getIndicatorCode())
                .last("limit 1"));
        if (exist != null) {
            exist.setIndicatorName(weight.getIndicatorName());
            exist.setWeight(weight.getWeight());
            weightMapper.updateById(exist);
        } else {
            weight.setWeightId(null);
            weightMapper.insert(weight);
        }
        return Result.success();
    }
}
