package com.chronic.modules.chronic.controller;

import com.chronic.common.result.Result;
import com.chronic.modules.chronic.service.CdStatService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Tag(name = "14-统计分析", description = "按病种统计慢性病控制率，参考范围与预警引擎同源")
@RestController
@RequestMapping("/chronic/stat")
@RequiredArgsConstructor
public class CdStatController {

    private final CdStatService statService;

    @Operation(summary = "按病种统计慢性病控制率（含患者明细）")
    @PreAuthorize("@ss.hasPermi('chronic:stat:control')")
    @GetMapping("/control")
    public Result<Map<String, Object>> control(
            @RequestParam(required = false, defaultValue = "30") Integer days) {
        return Result.success(statService.diseaseControl(days));
    }
}
