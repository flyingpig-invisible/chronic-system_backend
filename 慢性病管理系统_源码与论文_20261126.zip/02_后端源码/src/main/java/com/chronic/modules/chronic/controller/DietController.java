package com.chronic.modules.chronic.controller;

import com.chronic.common.result.Result;
import com.chronic.modules.chronic.service.DietService;
import com.chronic.modules.chronic.vo.DietPlanVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

/**
 * 算法五：病种感知的膳食约束优化推荐
 *
 * @author chronic
 */
@Tag(name = "29-膳食推荐（病种约束优化）", description = "按患者病种生成满足钠/GI/脂肪/蛋白约束的一日三餐")
@RestController
@RequestMapping("/chronic/diet")
@RequiredArgsConstructor
public class DietController {

    private final DietService dietService;

    @Operation(summary = "生成膳食方案（不传 date 默认今天）")
    @PreAuthorize("@ss.hasPermi('chronic:ai:list')")
    @PostMapping("/recommend")
    public Result<DietPlanVO> recommend(@RequestParam Long patientId,
                                        @RequestParam(required = false) String date,
                                        @RequestParam(required = false) Integer kcal) {
        LocalDate d = date == null || date.isBlank() ? LocalDate.now() : LocalDate.parse(date);
        return Result.success(dietService.recommend(patientId, d, kcal));
    }

    @Operation(summary = "最近一次方案（没有则即时生成）")
    @PreAuthorize("@ss.hasPermi('chronic:ai:list')")
    @GetMapping("/latest")
    public Result<DietPlanVO> latest(@RequestParam Long patientId) {
        return Result.success(dietService.latest(patientId));
    }
}
