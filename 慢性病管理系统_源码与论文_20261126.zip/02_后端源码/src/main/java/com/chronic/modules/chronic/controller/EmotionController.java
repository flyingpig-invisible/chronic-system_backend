package com.chronic.modules.chronic.controller;

import com.chronic.common.result.Result;
import com.chronic.modules.chronic.entity.CdEmotionLog;
import com.chronic.modules.chronic.service.EmotionService;
import com.chronic.modules.chronic.vo.EmotionResultVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 算法四：多模态情绪感知
 *
 * @author chronic
 */
@Tag(name = "28-情绪感知（多模态融合）", description = "文本 + 生理 + 行为三模态融合，输出情绪风险与建议")
@RestController
@RequestMapping("/chronic/emotion")
@RequiredArgsConstructor
public class EmotionController {

    private final EmotionService emotionService;

    /** 请求体 */
    public static class AnalyzeParam {
        public Long patientId;
        public String text;
        public String source;
    }

    @Operation(summary = "分析情绪（可只传 patientId，纯生理+行为融合；也可附文本）")
    @PreAuthorize("@ss.hasPermi('chronic:ai:list')")
    @PostMapping("/analyze")
    public Result<EmotionResultVO> analyze(@RequestBody AnalyzeParam param) {
        return Result.success(emotionService.analyze(param.patientId, param.text,
                param.source == null ? "MANUAL" : param.source));
    }

    @Operation(summary = "情绪分析历史")
    @PreAuthorize("@ss.hasPermi('chronic:ai:list')")
    @GetMapping("/history")
    public Result<List<CdEmotionLog>> history(@RequestParam Long patientId,
                                              @RequestParam(required = false, defaultValue = "10") Integer limit) {
        return Result.success(emotionService.recent(patientId, limit == null ? 10 : limit));
    }

    @Operation(summary = "情绪等级说明（供前端展示口径）")
    @PreAuthorize("@ss.hasPermi('chronic:ai:list')")
    @GetMapping("/levels")
    public Result<Map<String, String>> levels() {
        return Result.success(Map.of(
                "CALM", "平稳（融合分 < 35）",
                "CARE", "需关注（35 ~ 65）",
                "WARN", "预警（> 65，建议医生 24 小时内介入）"));
    }
}
