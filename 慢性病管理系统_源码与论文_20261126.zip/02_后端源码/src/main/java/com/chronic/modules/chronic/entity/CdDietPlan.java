package com.chronic.modules.chronic.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 膳食推荐方案（算法五）
 *
 * @author chronic
 */
@Data
@TableName("cd_diet_plan")
@Schema(description = "膳食推荐方案")
public class CdDietPlan implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long planId;

    private Long patientId;

    private LocalDate planDate;

    @Schema(description = "能量目标 kcal")
    private Integer targetKcal;

    @Schema(description = "参与约束的病种编码，逗号分隔")
    private String diseaseCodes;

    @Schema(description = "三餐明细 JSON")
    private String mealsJson;

    @Schema(description = "全天营养合计 JSON")
    private String totalsJson;

    @Schema(description = "约束满足情况 JSON")
    private String constraintJson;

    @Schema(description = "方案得分 0-100")
    private BigDecimal score;

    private String advice;

    private LocalDateTime createTime;
}
