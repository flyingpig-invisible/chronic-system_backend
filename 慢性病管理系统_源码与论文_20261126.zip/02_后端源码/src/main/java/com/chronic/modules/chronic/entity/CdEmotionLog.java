package com.chronic.modules.chronic.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 情绪感知记录（算法四：文本 + 生理 + 行为 三模态融合）
 *
 * @author chronic
 */
@Data
@TableName("cd_emotion_log")
@Schema(description = "情绪感知记录")
public class CdEmotionLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long logId;

    private Long patientId;

    @Schema(description = "触发来源：AI_CHAT/MANUAL")
    private String source;

    private String textContent;

    @Schema(description = "文本模态得分，越大越负面")
    private Integer textScore;

    private String textLabel;

    @Schema(description = "命中的情绪词")
    private String textHits;

    @Schema(description = "生理模态得分")
    private Integer physioScore;

    private String physioNote;

    @Schema(description = "行为模态得分")
    private Integer behaviorScore;

    private String behaviorNote;

    @Schema(description = "融合风险分 0-100")
    private Integer fusedScore;

    @Schema(description = "CALM/CARE/WARN")
    private String emotionLevel;

    private String advice;

    private LocalDateTime createTime;
}
