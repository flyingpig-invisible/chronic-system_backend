package com.chronic.modules.chronic.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 食物营养库（算法五：数值均为每 100g 可食部）
 * <p>
 * 数据来源：《四种慢病饮食推荐与限制清单(1).xlsx》的「全量食物营养分析」表（1698 条去重后），
 * 含每 100g 能量/蛋白质/糖类/脂肪/纤维/钾/钠，以及高血压、糖尿病、冠心病、慢阻肺
 * 四个病种的「推荐 / 适量 / 限制」判定与判定依据。算法五直接读判定，不自造阈值。
 *
 * @author chronic
 */
@Data
@TableName("cd_food")
@Schema(description = "食物营养库")
public class CdFood implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long foodId;

    private String name;

    @Schema(description = "主食/蛋白/蔬菜/水果/奶类/坚果/调味/油脂/其他")
    private String category;

    @Schema(description = "默认一份的克数")
    private Integer servingG;

    @Schema(description = "单项每餐上限(g)，按能量密度推导")
    private Integer maxG;

    private BigDecimal kcal;

    private BigDecimal protein;

    private BigDecimal fat;

    @Schema(description = "饱和脂肪（源表未收录，按类别系数估算）")
    private BigDecimal satFat;

    private BigDecimal carb;

    private BigDecimal fiber;

    @Schema(description = "钠 mg/100g")
    private BigDecimal sodiumMg;

    @Schema(description = "钾 mg/100g")
    private BigDecimal potassiumMg;

    @Schema(description = "升糖指数，0 表示源表未收录")
    private Integer gi;

    @Schema(description = "标签：低钠/高钾/高蛋白/高纤维/清单推荐/产气注意")
    private String tags;

    @Schema(description = "1 参与配餐；0 仅入库可查（酒、调味、纯油脂、生粮粉、糕点零食等）")
    private String status;

    // ---------- 四病种判定（推荐 / 适量 / 限制）与判定依据 ----------

    private String verdictHtn;

    private String evidenceHtn;

    private String verdictDm;

    private String evidenceDm;

    private String verdictChd;

    private String evidenceChd;

    private String verdictCopd;

    private String evidenceCopd;

    private String source;
}
