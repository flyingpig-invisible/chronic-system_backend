package com.chronic.modules.chronic.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 转诊申请
 *
 * @author chronic
 */
@Data
@TableName("cd_referral")
@Schema(description = "转诊申请")
public class CdReferral implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long referralId;

    private Long patientId;

    private String patientName;

    @Schema(description = "申请科室ID（取当前医生科室）")
    private Long fromDeptId;

    private String fromDeptName;

    @Schema(description = "拟接收医院")
    private String targetHospital;

    @Schema(description = "拟接收科室")
    private String targetDept;

    private String reason;

    @Schema(description = "紧急程度：1一般 2紧急 3严重")
    private String urgency;

    @Schema(description = "状态：0待审核 1已通过 2已驳回 3已完成")
    private String referralStatus;

    private String auditOpinion;

    @Schema(description = "实际接收医院")
    private String receiveHospital;

    @Schema(description = "实际接收科室")
    private String receiveDept;

    private String referralResult;

    private LocalDateTime applyTime;

    private LocalDateTime auditTime;

    @TableLogic
    private String delFlag;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
