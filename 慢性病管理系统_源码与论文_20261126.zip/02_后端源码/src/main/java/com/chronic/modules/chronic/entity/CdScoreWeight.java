package com.chronic.modules.chronic.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 病种评分权重（按病种+指标配置权重）
 *
 * @author chronic
 */
@Data
@TableName("cd_score_weight")
@Schema(description = "病种评分权重")
public class CdScoreWeight implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long weightId;

    @Schema(description = "病种编码：1高血压 2糖尿病 3冠心病 4慢阻肺")
    private String diseaseCode;

    private String indicatorCode;

    private String indicatorName;

    @Schema(description = "权重 0~1")
    private BigDecimal weight;
}
