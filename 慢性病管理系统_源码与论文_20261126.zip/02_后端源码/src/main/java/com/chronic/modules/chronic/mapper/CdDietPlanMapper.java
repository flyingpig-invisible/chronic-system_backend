package com.chronic.modules.chronic.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chronic.modules.chronic.entity.CdDietPlan;
import org.apache.ibatis.annotations.Mapper;

/**
 * 膳食推荐方案 Mapper
 *
 * @author chronic
 */
@Mapper
public interface CdDietPlanMapper extends BaseMapper<CdDietPlan> {
}
