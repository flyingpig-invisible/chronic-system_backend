package com.chronic.modules.chronic.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chronic.modules.chronic.entity.CdEmotionLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * 情绪感知记录 Mapper
 *
 * @author chronic
 */
@Mapper
public interface CdEmotionLogMapper extends BaseMapper<CdEmotionLog> {
}
