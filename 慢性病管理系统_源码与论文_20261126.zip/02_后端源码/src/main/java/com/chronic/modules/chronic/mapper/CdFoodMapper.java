package com.chronic.modules.chronic.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chronic.modules.chronic.entity.CdFood;
import org.apache.ibatis.annotations.Mapper;

/**
 * 食物营养库 Mapper
 *
 * @author chronic
 */
@Mapper
public interface CdFoodMapper extends BaseMapper<CdFood> {
}
