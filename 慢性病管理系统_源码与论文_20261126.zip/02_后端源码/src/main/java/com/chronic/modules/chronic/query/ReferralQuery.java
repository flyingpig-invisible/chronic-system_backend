package com.chronic.modules.chronic.query;

import com.chronic.common.page.PageQuery;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "转诊查询条件")
public class ReferralQuery extends PageQuery {
    private Long patientId;
    @Schema(description = "紧急程度：1一般 2紧急 3严重")
    private String urgency;
    @Schema(description = "状态：0待审核 1已通过 2已驳回 3已完成")
    private String referralStatus;
    private String keyword;
}
