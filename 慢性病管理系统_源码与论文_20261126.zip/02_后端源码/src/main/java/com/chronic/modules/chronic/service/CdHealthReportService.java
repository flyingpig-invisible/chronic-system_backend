package com.chronic.modules.chronic.service;

import java.util.Map;

/**
 * 健康报告生成服务。
 *
 * <p>报告中的每一条结论都必须能回溯到具体数据来源：
 * 监测记录（时间 + 数值）、预警规则（阈值）、预警记录（触发详情）、评分明细（评分项 + 描述）。
 * 不生成任何无数据支撑的判断。</p>
 *
 * @author chronic
 */
public interface CdHealthReportService {

    /**
     * 生成患者健康报告。
     *
     * @param patientId 患者ID
     * @param days      统计窗口天数（默认 30，限制 7～365）
     * @return 结构化报告，含 结论 / 依据清单 / 指标明细 / 建议
     */
    Map<String, Object> generate(Long patientId, Integer days);
}
