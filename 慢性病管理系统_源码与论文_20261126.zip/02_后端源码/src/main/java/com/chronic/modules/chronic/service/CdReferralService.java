package com.chronic.modules.chronic.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.chronic.common.result.PageResult;
import com.chronic.modules.chronic.entity.CdReferral;
import com.chronic.modules.chronic.query.ReferralQuery;

import java.util.Map;

/**
 * 转诊
 *
 * @author chronic
 */
public interface CdReferralService extends IService<CdReferral> {

    PageResult<CdReferral> queryPage(ReferralQuery query);

    /** 发起转诊，返回新记录ID */
    Long apply(CdReferral referral);

    /** 审核转诊（status=1 通过 / 2 驳回） */
    void audit(Long referralId, Map<String, String> body);
}
