package com.chronic.modules.chronic.service;

import java.util.Map;

/**
 * 慢性病控制率统计。
 *
 * <p>控制率口径：某病种的核心指标在统计窗口内<b>全部</b>落在参考范围内，才算该患者「达标」。
 * 参考范围不是写死的，而是从 cd_warning_rule 推导（≥ 类规则取最小阈值作上限、≤ 类规则取最大阈值作下限），
 * 与预警引擎、健康报告同一套口径，因此统计说「不达标」的地方，预警中心一定也有对应记录。</p>
 */
public interface CdStatService {

    /**
     * 按病种统计控制率。
     *
     * @param days 统计窗口天数，默认 30
     */
    Map<String, Object> diseaseControl(Integer days);
}
