package com.chronic.modules.chronic.service;

import com.chronic.modules.chronic.vo.DietPlanVO;

import java.time.LocalDate;

/**
 * 算法五：病种感知的膳食约束优化推荐
 *
 * @author chronic
 */
public interface DietService {

    /** 生成（或重新生成）某天的膳食方案 */
    DietPlanVO recommend(Long patientId, LocalDate date, Integer kcalOverride);

    /** 取最近一次方案，没有则即时生成 */
    DietPlanVO latest(Long patientId);
}
