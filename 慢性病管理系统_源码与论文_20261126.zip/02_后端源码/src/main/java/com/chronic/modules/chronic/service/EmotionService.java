package com.chronic.modules.chronic.service;

import com.chronic.modules.chronic.entity.CdEmotionLog;
import com.chronic.modules.chronic.vo.EmotionResultVO;

import java.util.List;

/**
 * 算法四：多模态情绪感知
 * <p>
 * 融合三个模态：文本（对话/档案情绪描述）、生理（近 7 天指标异常）、行为（漏服与监测缺口）。
 *
 * @author chronic
 */
public interface EmotionService {

    /** 融合分析并落库，返回带各模态明细的结果 */
    EmotionResultVO analyze(Long patientId, String text, String source);

    /** 最近若干条记录 */
    List<CdEmotionLog> recent(Long patientId, int limit);
}
