package com.chronic.modules.chronic.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.chronic.modules.chronic.entity.CdHealthScore;
import com.chronic.modules.chronic.entity.CdMeasure;
import com.chronic.modules.chronic.entity.CdPatient;
import com.chronic.modules.chronic.entity.CdPatientDisease;
import com.chronic.modules.chronic.entity.CdWarning;
import com.chronic.modules.chronic.entity.CdWarningRule;
import com.chronic.modules.chronic.mapper.CdHealthScoreMapper;
import com.chronic.modules.chronic.mapper.CdMeasureMapper;
import com.chronic.modules.chronic.mapper.CdPatientDiseaseMapper;
import com.chronic.modules.chronic.mapper.CdPatientMapper;
import com.chronic.modules.chronic.mapper.CdWarningMapper;
import com.chronic.modules.chronic.mapper.CdWarningRuleMapper;
import com.chronic.modules.chronic.service.CdHealthReportService;
import com.chronic.modules.system.entity.SysDept;
import com.chronic.modules.system.entity.SysUser;
import com.chronic.modules.system.mapper.SysDeptMapper;
import com.chronic.modules.system.mapper.SysUserMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 健康报告生成实现。
 *
 * <p>核心原则：<b>先算数据，再下结论，每条结论都挂依据编号。</b>
 * 依据只有四种来源，全部可回溯：</p>
 * <ol>
 *   <li>监测记录 —— 具体时间 + 具体数值</li>
 *   <li>预警规则 —— 规则编号 + 阈值描述（判定标准的出处）</li>
 *   <li>预警记录 —— 系统实际触发过的预警及其处置情况</li>
 *   <li>评分明细 —— 健康分各分项的公式、权重、得分说明</li>
 * </ol>
 *
 * @author chronic
 */
@Service
@RequiredArgsConstructor
public class CdHealthReportServiceImpl implements CdHealthReportService {

    private static final DateTimeFormatter DT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final DateTimeFormatter D = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter DAY_NO = DateTimeFormatter.ofPattern("yyyyMMdd");

    /** 指标展示顺序：先血压，再血糖，再其他 */
    private static final List<String> IND_ORDER = List.of("sbp", "dbp", "glu", "hr", "spo2", "rr", "sleep");

    private static final Map<String, String> IND_CN = Map.of(
            "sbp", "收缩压", "dbp", "舒张压", "glu", "血糖", "hr", "心率",
            "spo2", "血氧饱和度", "rr", "呼吸频率", "sleep", "睡眠时长");

    /** 结论分组：一个组可以包含多个指标（血压 = 收缩压 + 舒张压） */
    private static final List<String[]> GROUPS = List.of(
            new String[]{"血压", "sbp,dbp"},
            new String[]{"血糖", "glu"},
            new String[]{"心率", "hr"},
            new String[]{"血氧", "spo2"},
            new String[]{"呼吸频率", "rr"},
            new String[]{"睡眠", "sleep"});

    private final CdPatientMapper patientMapper;
    private final CdPatientDiseaseMapper patientDiseaseMapper;
    private final CdMeasureMapper measureMapper;
    private final CdWarningMapper warningMapper;
    private final CdWarningRuleMapper warningRuleMapper;
    private final CdHealthScoreMapper healthScoreMapper;
    private final SysUserMapper sysUserMapper;
    private final SysDeptMapper sysDeptMapper;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public Map<String, Object> generate(Long patientId, Integer days) {
        int win = days == null ? 30 : Math.max(7, Math.min(365, days));
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime from = now.minusDays(win);

        CdPatient patient = patientMapper.selectById(patientId);
        if (patient == null) {
            throw new RuntimeException("患者不存在或已删除");
        }

        List<CdPatientDisease> diseases = patientDiseaseMapper.selectList(
                Wrappers.<CdPatientDisease>lambdaQuery().eq(CdPatientDisease::getPatientId, patientId));

        List<CdWarningRule> rules = warningRuleMapper.selectList(
                Wrappers.<CdWarningRule>lambdaQuery().eq(CdWarningRule::getStatus, "0"));
        Map<String, List<CdWarningRule>> ruleByInd = rules.stream()
                .filter(r -> StringUtils.hasText(r.getIndicatorCode()))
                .collect(Collectors.groupingBy(CdWarningRule::getIndicatorCode, LinkedHashMap::new,
                        Collectors.toList()));

        List<CdMeasure> measures = measureMapper.selectList(
                Wrappers.<CdMeasure>lambdaQuery()
                        .eq(CdMeasure::getPatientId, patientId)
                        .ge(CdMeasure::getMeasureTime, from)
                        .orderByAsc(CdMeasure::getMeasureTime));
        List<CdWarning> warnings = warningMapper.selectList(
                Wrappers.<CdWarning>lambdaQuery()
                        .eq(CdWarning::getPatientId, patientId)
                        .ge(CdWarning::getTriggerTime, from)
                        .orderByDesc(CdWarning::getTriggerTime));
        CdHealthScore score = latestScore(patientId);

        Map<String, List<CdMeasure>> byInd = measures.stream()
                .filter(m -> StringUtils.hasText(m.getIndicatorCode()))
                .collect(Collectors.groupingBy(CdMeasure::getIndicatorCode, LinkedHashMap::new, Collectors.toList()));

        /* ---------- 1. 指标聚合（含达标区间推导） ---------- */
        List<Map<String, Object>> indicators = new ArrayList<>();
        Map<String, Map<String, Object>> indMap = new LinkedHashMap<>();
        for (String code : IND_ORDER) {
            List<CdMeasure> ms = byInd.getOrDefault(code, new ArrayList<>());
            List<CdWarningRule> rs = ruleByInd.getOrDefault(code, new ArrayList<>());
            Map<String, Object> agg = aggregate(code, ms, rs, now);
            indicators.add(agg);
            indMap.put(code, agg);
        }
        // 兜底：数据里出现但不在 IND_ORDER 内的指标（例如后续新增指标）
        for (Map.Entry<String, List<CdMeasure>> e : byInd.entrySet()) {
            if (!indMap.containsKey(e.getKey())) {
                Map<String, Object> agg = aggregate(e.getKey(), e.getValue(),
                        ruleByInd.getOrDefault(e.getKey(), new ArrayList<>()), now);
                indicators.add(agg);
                indMap.put(e.getKey(), agg);
            }
        }

        /* ---------- 2. 依据收集器 ---------- */
        Ev ev = new Ev();

        /* ---------- 3. 生成结论（每条结论绑定依据编号） ---------- */
        List<Map<String, Object>> conclusions = new ArrayList<>();
        int cNo = 1;

        // 3.1 数据完整性
        LocalDateTime lastTime = measures.stream()
                .map(this::timeOf).filter(t -> t != null).max(Comparator.naturalOrder()).orElse(null);
        // 窗口内没有数据时，再查一次「历史上最后一条」，避免报告只说"没数据"却说不出中断多久
        LocalDateTime lastEver = lastTime;
        if (lastEver == null) {
            List<CdMeasure> lastOne = measureMapper.selectList(
                    Wrappers.<CdMeasure>lambdaQuery()
                            .eq(CdMeasure::getPatientId, patientId)
                            .orderByDesc(CdMeasure::getMeasureTime)
                            .last("limit 1"));
            if (!lastOne.isEmpty()) {
                lastEver = timeOf(lastOne.get(0));
            }
        }
        long gapDays = lastEver == null ? -1
                : java.time.Duration.between(lastEver, now).toDays();
        if (measures.isEmpty()) {
            if (lastEver != null) {
                String e1 = ev.add("监测记录", String.format(
                        "统计窗口 %s 至 %s 内记录数为 0；库中最后一条历史记录为 %s（距今 %d 天）",
                        from.format(D), now.format(D), lastEver.format(DT), gapDays));
                conclusions.add(conclusion(cNo++, 3, "监测数据缺失，已中断 " + gapDays + " 天",
                        String.format("近 %d 天未采集到任何监测数据。患者最后一次上传为 %s，"
                                + "距今已中断 %d 天，远超随访周期。中断期间的健康状态完全不可知，"
                                + "系统当前的健康评分（%s 分）仅反映历史数据，不能代表现状，"
                                + "在慢病管理中属于「失访」信号，应优先核实患者是否仍在管理范围内。",
                                win, lastEver.format(DT), gapDays,
                                patient.getHealthScore() == null ? "-" : patient.getHealthScore()),
                        List.of(e1)));
            } else {
                String e1 = ev.add("监测记录", String.format(
                        "统计窗口 %s 至 %s 内记录数为 0，且库中不存在该患者的任何历史监测记录",
                        from.format(D), now.format(D)));
                conclusions.add(conclusion(cNo++, 3, "无任何监测数据，无法评估",
                        String.format("系统内不存在该患者的任何监测记录，无法对其健康状况作出任何判断。"
                                + "建议先核实档案是否新建、设备是否已绑定，再安排首次随访与指标采集。", win),
                        List.of(e1)));
            }
        } else if (gapDays >= 7) {
            String e1 = ev.add("监测记录", String.format(
                    "最后一条监测记录时间：%s（距今 %d 天）", lastTime.format(DT), gapDays));
            String e2 = ev.add("监测记录", String.format(
                    "统计窗口内共 %d 条记录，覆盖 %d 个指标", measures.size(),
                    byInd.size()));
            conclusions.add(conclusion(cNo++, 2, String.format("监测中断 %d 天", gapDays),
                    String.format("患者最后一次上传数据为 %s，截至报告生成已中断 %d 天，"
                            + "超过 7 天随访阈值。中断期间的健康状态不可知，现有评分与分级可能失真。",
                            lastTime.format(DT), gapDays),
                    List.of(e1, e2)));
        } else {
            String e1 = ev.add("监测记录", String.format(
                    "统计窗口内共 %d 条记录，最后一条为 %s，数据连续", measures.size(), lastTime.format(DT)));
            conclusions.add(conclusion(cNo++, 0, "监测数据连续",
                    String.format("近 %d 天共采集 %d 条监测数据，最后一条记录于 %s，"
                            + "数据上传连续，可用于本次评估。", win, measures.size(), lastTime.format(DT)),
                    List.of(e1)));
        }

        // 3.2 各指标组（完全无数据时不再逐项罗列"未采集"，避免报告被 6 条空结论灌水）
        for (String[] g : GROUPS) {
            if (measures.isEmpty()) {
                break;
            }
            String groupName = g[0];
            String[] codes = g[1].split(",");
            List<Map<String, Object>> groupInds = new ArrayList<>();
            for (String code : codes) {
                Map<String, Object> agg = indMap.get(code);
                if (agg != null) {
                    groupInds.add(agg);
                }
            }
            Map<String, Object> one = groupConclusion(win, groupName, groupInds, ruleByInd, ev);
            if (one != null) {
                one.put("no", cNo++);
                conclusions.add(one);
            }
        }

        // 3.3 预警情况
        Map<String, Object> warnCon = warningConclusion(win, warnings, measures.size(), rules.size(), ev);
        warnCon.put("no", cNo++);
        conclusions.add(warnCon);

        // 3.4 健康评分
        if (score != null) {
            Map<String, Object> sc = scoreConclusion(score, ev);
            sc.put("no", cNo++);
            conclusions.add(sc);
        }

        /* ---------- 4. 建议（尽量引用规则的处置建议） ---------- */
        List<Map<String, Object>> suggestions = suggestions(conclusions, warnings, gapDays,
                measures.isEmpty(), lastTime, indMap, ruleByInd);

        /* ---------- 5. 组装 ---------- */
        int maxLevel = conclusions.stream()
                .mapToInt(c -> (Integer) c.getOrDefault("level", 0))
                .max().orElse(0);

        Map<String, Object> patientView = new LinkedHashMap<>();
        patientView.put("patientId", patient.getPatientId());
        patientView.put("patientNo", patient.getPatientNo());
        patientView.put("name", patient.getName());
        patientView.put("gender", patient.getGender());
        patientView.put("genderName", genderName(patient.getGender()));
        patientView.put("birthday", patient.getBirthday() == null ? null : patient.getBirthday().format(D));
        patientView.put("age", patient.getBirthday() == null ? patient.getAge()
                : Period.between(patient.getBirthday(), LocalDate.now()).getYears());
        patientView.put("phone", patient.getPhone());
        patientView.put("deptName", deptNameOf(patient));
        patientView.put("doctorName", doctorNameOf(patient));
        patientView.put("diseases", diseases.stream().map(d -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("code", d.getDiseaseCode());
            m.put("name", StringUtils.hasText(d.getDiseaseName()) ? d.getDiseaseName() : d.getDiseaseCode());
            m.put("diagnoseDate", d.getDiagnoseDate() == null ? null : d.getDiagnoseDate().format(D));
            return m;
        }).collect(Collectors.toList()));

        Map<String, Object> period = new LinkedHashMap<>();
        period.put("start", from.format(D));
        period.put("end", now.format(D));
        period.put("days", win);

        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("healthScore", patient.getHealthScore() == null ? null : patient.getHealthScore());
        // 健康等级：与患者列表同口径（健康分区间），不是本次评估的最高结论级别
        String hl = score == null || score.getHealthScore() == null
                ? null : CdScoreServiceImpl.healthLevel(score.getHealthScore());
        summary.put("healthLevelName", hl == null ? "-" : CdScoreServiceImpl.healthLevelName(hl));
        // 本次评估级别：所有结论里最严重的那个（由指标异常与预警共同决定）
        summary.put("assessLevel", maxLevel);
        summary.put("assessName", riskName(maxLevel));
        summary.put("measureCount", measures.size());
        summary.put("indicatorCount", byInd.size());
        summary.put("warningCount", warnings.size());
        summary.put("pendingWarningCount", warnings.stream()
                .filter(w -> "0".equals(w.getHandleStatus())).count());
        summary.put("lastMeasureTime", lastEver == null ? null : lastEver.format(DT));
        summary.put("lastMeasureInWindow", lastTime != null);
        summary.put("dataGapDays", gapDays);
        summary.put("abnormalIndicatorCount", indicators.stream()
                .filter(i -> ((Integer) i.get("level")) > 0).count());
        summary.put("ruleCount", rules.size());

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("reportNo", "HR-" + now.format(DAY_NO) + "-" + String.format("%04d", patientId));
        result.put("generatedAt", now.format(DT));
        result.put("patient", patientView);
        result.put("period", period);
        result.put("summary", summary);
        result.put("indicators", indicators);
        result.put("warnings", warningView(warnings));
        result.put("score", scoreView(score));
        result.put("conclusions", conclusions);
        result.put("evidence", ev.list);
        result.put("suggestions", suggestions);
        result.put("rulesUsed", rulesUsed(indicators, ruleByInd));
        result.put("notes", notes(from, now, rules.size()));
        return result;
    }

    /* ==================== 指标聚合 ==================== */

    private Map<String, Object> aggregate(String code, List<CdMeasure> ms,
                                          List<CdWarningRule> rules, LocalDateTime now) {
        String name = ms.stream().map(CdMeasure::getIndicatorName)
                .filter(StringUtils::hasText).findFirst()
                .orElse(IND_CN.getOrDefault(code, code));
        String unit = ms.stream().map(CdMeasure::getUnit)
                .filter(StringUtils::hasText).findFirst().orElse("");

        // 由规则推导达标区间：≥类取最小阈值作上限；≤类取最大阈值作下限
        BigDecimal upper = null;
        BigDecimal lower = null;
        String upperRule = null;
        String lowerRule = null;
        for (CdWarningRule r : rules) {
            if (r.getThresholdValue() == null || !StringUtils.hasText(r.getOperator())) {
                continue;
            }
            String op = r.getOperator().trim();
            if (op.startsWith(">")) {
                if (upper == null || r.getThresholdValue().compareTo(upper) < 0) {
                    upper = r.getThresholdValue();
                    upperRule = ruleLabel(r);
                }
            } else if (op.startsWith("<")) {
                if (lower == null || r.getThresholdValue().compareTo(lower) > 0) {
                    lower = r.getThresholdValue();
                    lowerRule = ruleLabel(r);
                }
            }
        }

        Map<String, Object> m = new LinkedHashMap<>();
        m.put("code", code);
        m.put("name", name);
        m.put("unit", unit);
        m.put("count", ms.size());
        m.put("lowerLimit", lower);
        m.put("upperLimit", upper);
        m.put("lowerRule", lowerRule);
        m.put("upperRule", upperRule);
        m.put("targetText", targetText(upper, lower, unit));

        if (ms.isEmpty()) {
            m.put("avg", null);
            m.put("min", null);
            m.put("max", null);
            m.put("last", null);
            m.put("lastTime", null);
            m.put("qualifiedCount", 0);
            m.put("abnormalCount", 0);
            m.put("rate", null);
            m.put("level", 0);
            m.put("status", "无数据");
            m.put("samples", new ArrayList<>());
            return m;
        }

        BigDecimal sum = BigDecimal.ZERO;
        BigDecimal min = null;
        BigDecimal max = null;
        int abnormal = 0;
        int levelMax = 0;
        List<Map<String, Object>> samples = new ArrayList<>();

        for (CdMeasure x : ms) {
            if (x.getValue() == null) {
                continue;
            }
            sum = sum.add(x.getValue());
            min = (min == null || x.getValue().compareTo(min) < 0) ? x.getValue() : min;
            max = (max == null || x.getValue().compareTo(max) > 0) ? x.getValue() : max;

            List<CdWarningRule> hits = new ArrayList<>();
            for (CdWarningRule r : rules) {
                if (match(r.getOperator(), x.getValue(), r.getThresholdValue())) {
                    hits.add(r);
                }
            }
            if (!hits.isEmpty()) {
                abnormal++;
                // 一条记录可能同时命中多档规则（如舒张压 123 同时满足 ≥90 和 ≥110），
                // 统一按级别升序排列，取最后一个即「最严重的那条规则」，避免依据与实际判定错配
                hits.sort(Comparator.comparingInt(r -> parseInt(r.getWarningLevel())));
                int lvl = parseInt(hits.get(hits.size() - 1).getWarningLevel());
                levelMax = Math.max(levelMax, lvl);
                LocalDateTime t = timeOf(x);
                Map<String, Object> s = new LinkedHashMap<>();
                s.put("time", t == null ? null : t.format(DT));
                s.put("value", x.getValue());
                s.put("level", lvl);
                s.put("rules", hits.stream().map(r -> {
                    Map<String, Object> rm = new LinkedHashMap<>();
                    rm.put("ruleId", r.getRuleId());
                    rm.put("ruleName", r.getRuleName());
                    rm.put("thresholdDesc", r.getThresholdDesc());
                    rm.put("warningLevel", parseInt(r.getWarningLevel()));
                    return rm;
                }).collect(Collectors.toList()));
                samples.add(s);
            }
        }

        // 越界样本按严重程度、时间倒序，最多留 6 条，避免报告过长
        samples.sort((a, b) -> {
            int c = Integer.compare((Integer) b.get("level"), (Integer) a.get("level"));
            if (c != 0) {
                return c;
            }
            return String.valueOf(b.get("time")).compareTo(String.valueOf(a.get("time")));
        });
        // 最严重的一次：偏低类指标（血氧、睡眠）要看最小值，不能一律取 max
        Map<String, Object> worstSample = samples.isEmpty() ? null : samples.get(0);
        m.put("worstValue", worstSample == null ? null : worstSample.get("value"));
        m.put("worstTime", worstSample == null ? null : worstSample.get("time"));
        if (samples.size() > 6) {
            samples = new ArrayList<>(samples.subList(0, 6));
        }

        int n = ms.size();
        BigDecimal avg = n == 0 ? null : sum.divide(BigDecimal.valueOf(n), 2, RoundingMode.HALF_UP);
        CdMeasure last = ms.get(n - 1);

        m.put("avg", avg);
        m.put("min", min);
        m.put("max", max);
        m.put("last", last.getValue());
        m.put("lastTime", timeOf(last) == null ? null : timeOf(last).format(DT));
        m.put("qualifiedCount", n - abnormal);
        m.put("abnormalCount", abnormal);
        m.put("rate", n == 0 ? null : BigDecimal.valueOf(n - abnormal)
                .divide(BigDecimal.valueOf(n), 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100)).setScale(1, RoundingMode.HALF_UP));
        m.put("level", levelMax);
        m.put("status", levelMax == 0 ? "达标" : levelMax == 1 ? "轻度异常"
                : levelMax == 2 ? "中度异常" : "重度异常");
        m.put("samples", samples);
        return m;
    }

    /* ==================== 结论生成 ==================== */

    private Map<String, Object> groupConclusion(int win, String groupName,
                                                List<Map<String, Object>> inds,
                                                Map<String, List<CdWarningRule>> ruleByInd,
                                                Ev ev) {
        if (inds.isEmpty()) {
            return null;
        }
        int totalCount = inds.stream().mapToInt(i -> (Integer) i.get("count")).sum();
        if (totalCount == 0) {
            String names = inds.stream().map(i -> (String) i.get("name")).collect(Collectors.joining("、"));
            String e = ev.add("监测记录", String.format("统计窗口 %d 天内，%s 无任何监测记录", win, names));
            return conclusion(0, 1, groupName + "未采集，无法评估",
                    String.format("近 %d 天未采集%s数据。该项指标缺失会导致健康评分中的"
                            + "「指标达标率」无法完整计算，报告结论存在盲区。", win, names),
                    List.of(e));
        }

        int worst = inds.stream().mapToInt(i -> (Integer) i.get("level")).max().orElse(0);
        int worstCount = inds.stream().mapToInt(i -> (Integer) i.get("abnormalCount")).sum();

        if (worst == 0) {
            List<String> evs = new ArrayList<>();
            for (Map<String, Object> i : inds) {
                evs.add(ev.add("监测记录", String.format(
                        "%s 共 %d 次，均值 %s%s，范围 %s～%s%s，参考范围 %s，全部达标",
                        i.get("name"), i.get("count"), fmt(i.get("avg")), unitSuffix((String) i.get("unit")),
                        fmt(i.get("min")), fmt(i.get("max")), unitSuffix((String) i.get("unit")),
                        i.get("targetText")), null, String.valueOf(i.get("code"))));
            }
            Map<String, Object> ruleRef = findRuleRef(inds, ruleByInd);
            if (ruleRef != null) {
                evs.add(ev.add("预警规则", (String) ruleRef.get("text")));
            }
            String detail = inds.stream()
                    .map(i -> String.format("%s均值 %s%s", i.get("name"), fmt(i.get("avg")),
                            unitSuffix((String) i.get("unit"))))
                    .collect(Collectors.joining("，"));
            return conclusion(0, 0, groupName + "控制达标",
                    String.format("近 %d 天%s均在参考范围内，%s，未见异常波动。",
                            win, String.join("、", inds.stream().map(i -> (String) i.get("name"))
                                    .collect(Collectors.toList())), detail),
                    evs);
        }

        // 有异常：挑最严重的那个指标做主语，其余作为补充
        Map<String, Object> worstInd = inds.stream()
                .max(Comparator.comparingInt(i -> (Integer) i.get("level"))).orElse(inds.get(0));

        List<String> evs = new ArrayList<>();
        for (Map<String, Object> i : inds) {
            evs.add(ev.add("监测记录", String.format(
                    "%s 共 %d 次，均值 %s%s，最高 %s%s，超标 %d 次，参考范围 %s",
                    i.get("name"), i.get("count"), fmt(i.get("avg")), unitSuffix((String) i.get("unit")),
                    fmt(i.get("max")), unitSuffix((String) i.get("unit")),
                    i.get("abnormalCount"), i.get("targetText")), null, String.valueOf(i.get("code"))));
        }
        // 最严重的一次记录 + 命中的规则（这是「凭什么这么判」的核心依据）
        List<Map<String, Object>> samples = (List<Map<String, Object>>) worstInd.get("samples");
        String mainRuleName = "";
        if (!samples.isEmpty()) {
            Map<String, Object> s0 = samples.get(0);
            List<Map<String, Object>> rs = (List<Map<String, Object>>) s0.get("rules");
            if (!rs.isEmpty()) {
                Map<String, Object> r0 = rs.get(rs.size() - 1);
                mainRuleName = String.valueOf(r0.get("ruleName"));
                evs.add(ev.add("监测记录", String.format(
                        "%s %s %s%s，该条记录命中规则 #%s《%s》（%s），同一条记录共命中 %d 条规则",
                        s0.get("time"), worstInd.get("name"), fmt(s0.get("value")),
                        unitSuffix((String) worstInd.get("unit")), r0.get("ruleId"), r0.get("ruleName"),
                        r0.get("thresholdDesc"), rs.size()), null, String.valueOf(worstInd.get("code"))));
            }
        }
        Map<String, Object> ruleRef = findRuleRef(inds, ruleByInd);
        if (ruleRef != null) {
            evs.add(ev.add("预警规则", (String) ruleRef.get("text")));
        }

        // 参考范围在括号里要标清是哪个指标的，否则「＜140；＜90」看不出对应关系
        String targetBrief = inds.size() > 1
                ? inds.stream().map(i -> i.get("name") + " " + i.get("targetText"))
                        .collect(Collectors.joining("；"))
                : String.valueOf(inds.get(0).get("targetText"));

        String text = String.format(
                "近 %d 天%s共采集 %d 次，其中 %d 次超出参考范围（%s）。最严重的一次为 %s 的 %s %s%s，"
                        + "按《%s》判定为%s。",
                win, groupName, totalCount, worstCount, targetBrief,
                worstInd.get("worstTime"), worstInd.get("name"),
                fmt(worstInd.get("worstValue")), unitSuffix((String) worstInd.get("unit")),
                StringUtils.hasText(mainRuleName) ? mainRuleName : "系统预警规则",
                riskName(worst));

        return conclusion(0, worst, groupName + (worst >= 3 ? "重度异常" : worst == 2 ? "控制不佳" : "轻度异常"),
                text, evs);
    }

    private Map<String, Object> warningConclusion(int win, List<CdWarning> warnings,
                                                  int measureCount, int ruleCount, Ev ev) {
        if (warnings.isEmpty()) {
            String detail = measureCount == 0
                    ? "窗口内无监测数据，规则无从比对，因此不可能产生预警；这不代表病情稳定"
                    : String.format("窗口内 %d 条监测记录已逐条比对 %d 条启用规则，均未触发", measureCount, ruleCount);
            String e = ev.add("预警记录", "统计窗口内 cd_warning 中该患者预警记录为 0 条；" + detail);
            return conclusion(0, measureCount == 0 ? 1 : 0, "窗口期内未触发预警",
                    String.format("近 %d 天系统未对该患者产生任何预警。%s。", win, detail),
                    List.of(e));
        }
        long l3 = warnings.stream().filter(w -> "3".equals(w.getWarningLevel())).count();
        long l2 = warnings.stream().filter(w -> "2".equals(w.getWarningLevel())).count();
        long l1 = warnings.stream().filter(w -> "1".equals(w.getWarningLevel())).count();
        long pending = warnings.stream().filter(w -> "0".equals(w.getHandleStatus())).count();
        long handling = warnings.stream().filter(w -> "1".equals(w.getHandleStatus())).count();
        long done = warnings.stream().filter(w -> "2".equals(w.getHandleStatus())).count();

        int level = l3 > 0 ? 3 : l2 > 0 ? 2 : 1;

        List<String> evs = new ArrayList<>();
        evs.add(ev.add("预警记录", String.format(
                "近 %d 天共触发预警 %d 条：高危 %d 条、中危 %d 条、低危 %d 条",
                win, warnings.size(), l3, l2, l1)));
        // 带 warningId 的依据在前端可「定位」到预警列表的那一条
        warnings.stream().limit(3).forEach(w -> evs.add(ev.add("预警记录", String.format(
                "%s %s %s %s，触发条件：%s，级别 %s，处置状态：%s",
                w.getTriggerTime() == null ? "-" : w.getTriggerTime().format(DT),
                nvl(w.getIndicatorName()), fmt(w.getIndicatorValue()), nvl(w.getUnit()),
                nvl(w.getThresholdDesc()), riskName(parseInt(w.getWarningLevel())),
                handleStatusName(w.getHandleStatus())), w.getWarningId())));
        if (pending > 0) {
            evs.add(ev.add("预警记录", String.format(
                    "待处理 %d 条、处理中 %d 条、已处理 %d 条（处置状态字段 handle_status）",
                    pending, handling, done)));
        }

        String text = String.format(
                "近 %d 天系统共触发预警 %d 条，其中高危 %d 条、中危 %d 条、低危 %d 条；"
                        + "处置情况为待处理 %d 条、处理中 %d 条、已处理 %d 条。%s",
                win, warnings.size(), l3, l2, l1, pending, handling, done,
                pending > 0 ? String.format("仍有 %d 条未处置，需优先闭环。", pending) : "预警已全部进入处置流程。");

        return conclusion(0, level, l3 > 0 ? "发生高危预警" : l2 > 0 ? "发生中危预警" : "发生低危预警", text, evs);
    }

    private Map<String, Object> scoreConclusion(CdHealthScore score, Ev ev) {
        int hs = score.getHealthScore() == null ? 0 : score.getHealthScore();
        // 注意：cd_health_score.risk_level 这个字段没有被评分任务正确写入（历史上恒为 1），
        // 不能直接拿来用。系统各页面显示的患者风险等级，都是用 healthLevel(healthScore) 现算的，
        // 报告必须与之同口径，否则会出现「列表显示一般、报告显示低危」的矛盾。
        String hl = CdScoreServiceImpl.healthLevel(hs);
        String hlName = CdScoreServiceImpl.healthLevelName(hl);
        int conclLevel = "1".equals(hl) ? 3 : "2".equals(hl) ? 2 : 0;

        List<String> evs = new ArrayList<>();
        evs.add(ev.add("评分模型", String.format(
                "最近一次评分：健康分 %d 分，计算时间 %s，触发来源 %s；按系统阈值（≥80 健康良好、50～79 一般、<50 较差）判定为「%s」",
                hs, score.getCalcTime() == null ? "-" : score.getCalcTime().format(DT),
                triggerName(score.getTriggerType()), hlName)));

        List<Map<String, Object>> items = new ArrayList<>();
        String dj = score.getDetailJson();
        if (StringUtils.hasText(dj)) {
            try {
                Map<String, Object> root = objectMapper.readValue(dj, Map.class);
                Object arr = root.get("items");
                if (arr instanceof List<?> list) {
                    for (Object o : list) {
                        if (o instanceof Map<?, ?> mm) {
                            Map<String, Object> item = new LinkedHashMap<>();
                            item.put("code", mm.get("code"));
                            item.put("name", mm.get("name"));
                            item.put("formula", mm.get("formula"));
                            item.put("value", mm.get("value"));
                            item.put("weight", mm.get("weight"));
                            item.put("contribution", mm.get("contribution"));
                            item.put("desc", mm.get("desc"));
                            items.add(item);
                            evs.add(ev.add("评分模型", String.format(
                                    "%s（%s）：得分 %s × 权重 %s = 贡献 %s —— %s",
                                    mm.get("name"), mm.get("formula"), mm.get("value"),
                                    mm.get("weight"), mm.get("contribution"), mm.get("desc"))));
                        }
                    }
                }
            } catch (Exception ignored) {
                // 明细解析失败不影响报告主体，评分结论仍可用
            }
        }

        String weightText = items.stream()
                .map(it -> String.format("%s（权重 %s）", it.get("name"), it.get("weight")))
                .collect(Collectors.joining("、"));
        if (!StringUtils.hasText(weightText)) {
            weightText = "指标达标率、用药依从率、预警密度、检测完成率";
        }
        String text = String.format(
                "系统按 %s 四项加权计算，得出健康分 %d 分。按系统阈值（≥80 健康良好、50～79 一般、<50 较差），"
                        + "本次评估结论为「%s」。%s",
                weightText, hs, hlName,
                hs >= 80 ? "整体控制良好，维持现有方案并定期复评即可。"
                        : hs >= 50 ? "处于中等风险区间，需针对扣分项加强干预。"
                        : "处于高风险区间，建议尽快面诊并调整管理方案。");
        Map<String, Object> c = conclusion(0, conclLevel, "健康评分 " + hs + " 分（" + hlName + "）", text, evs);
        // 徽章用健康等级名（良好/一般/较差），避免与「中危/低危」的风险级别混在一起
        c.put("badge", hlName);
        return c;
    }

    /* ==================== 建议 ==================== */

    private List<Map<String, Object>> suggestions(List<Map<String, Object>> conclusions,
                                                  List<CdWarning> warnings, long gapDays,
                                                  boolean noData, LocalDateTime lastTime,
                                                  Map<String, Map<String, Object>> indMap,
                                                  Map<String, List<CdWarningRule>> ruleByInd) {
        List<Map<String, Object>> list = new ArrayList<>();

        // 1) 优先：由超标指标命中的规则给出处置建议（action_desc 是系统里配置的动作）
        // 顺序按「严重级别 → 超标次数」排，避免血压那 1 条记录把心率 77 次超标的处置动作挤掉
        List<String[]> orderedGroups = new ArrayList<>(GROUPS);
        orderedGroups.sort((a, b) -> {
            int sa = groupSeverity(a[1], indMap);
            int sb = groupSeverity(b[1], indMap);
            return Integer.compare(sb, sa);
        });

        // 同一个处置动作常被多条指标规则共用（心率偏快、舒张压偏高都是「立即联系患者并联动急救」），
        // 逐指标罗列会出现连续两条一字不差的建议。这里按 action_desc 归并，把指标名合成主语。
        Map<String, Sug> byAction = new LinkedHashMap<>();
        for (String[] g : orderedGroups) {
            for (String code : g[1].split(",")) {
                Map<String, Object> ind = indMap.get(code);
                if (ind == null || (Integer) ind.get("level") == 0) {
                    continue;
                }
                List<Map<String, Object>> samples = (List<Map<String, Object>>) ind.get("samples");
                if (samples.isEmpty()) {
                    continue;
                }
                List<Map<String, Object>> rs = (List<Map<String, Object>>) samples.get(0).get("rules");
                if (rs.isEmpty()) {
                    continue;
                }
                Map<String, Object> top = rs.get(rs.size() - 1);
                Object ruleId = top.get("ruleId");
                CdWarningRule rule = ruleByInd.getOrDefault(code, new ArrayList<>()).stream()
                        .filter(r -> ruleId != null && ruleId.equals(r.getRuleId()))
                        .findFirst().orElse(null);
                if (rule == null || !StringUtils.hasText(rule.getActionDesc())) {
                    continue;
                }
                String action = rule.getActionDesc().trim();
                Sug s = byAction.computeIfAbsent(action, Sug::new);
                s.names.add(String.valueOf(ind.get("name")));
                // 依据里带上「系统判定级别」，避免规则名称与级别不一致时读者无法判断严重程度
                s.basis.add(String.format("规则 #%s《%s》（%s，系统判定 %s）",
                        rule.getRuleId(), rule.getRuleName(), rule.getThresholdDesc(),
                        riskName(parseInt(rule.getWarningLevel()))));
                s.priority = Math.max(s.priority, parseInt(rule.getWarningLevel()));
                // 归并后的严重度：级别取最高，超标次数累加，用于与其它动作排序
                s.severity += (Integer) ind.get("level") * 10000 + (Integer) ind.get("abnormalCount");
            }
        }
        List<Sug> merged = new ArrayList<>(byAction.values());
        merged.sort((a, b) -> Integer.compare(b.severity, a.severity));
        for (Sug s : merged) {
            Map<String, Object> sug = new LinkedHashMap<>();
            sug.put("priority", s.priority);
            sug.put("text", String.format("%s：%s", String.join("、", s.names), s.action));
            sug.put("basis", String.join("；", s.basis));
            list.add(sug);
        }

        // 2) 未闭环预警
        long pending = warnings.stream().filter(w -> "0".equals(w.getHandleStatus())).count();
        if (pending > 0) {
            Map<String, Object> sug = new LinkedHashMap<>();
            sug.put("priority", 3);
            sug.put("text", String.format("预警闭环：%d 条待处理预警需逐条跟进并填写处置记录", pending));
            sug.put("basis", "预警模块中处置状态为「待处理」的记录条数");
            list.add(sug);
        }

        // 3) 数据补录
        if (noData) {
            Map<String, Object> sug = new LinkedHashMap<>();
            sug.put("priority", 3);
            sug.put("text", gapDays > 0
                    ? String.format("数据补录：已停测 %d 天，先联系患者确认是否继续接受管理，再安排补测血压、血糖", gapDays)
                    : "数据补录：该患者尚无任何监测记录，需先确认档案与设备，再安排首次采集");
            sug.put("basis", gapDays > 0
                    ? String.format("统计窗口内监测记录数为 0，最后一条历史记录距今 %d 天", gapDays)
                    : "系统内该患者历史监测记录数为 0");
            list.add(sug);
        } else if (gapDays >= 7) {
            Map<String, Object> sug = new LinkedHashMap<>();
            sug.put("priority", 2);
            sug.put("text", String.format("数据补录：已停测 %d 天，建议电话提醒复测或安排设备上门采集", gapDays));
            sug.put("basis", String.format("最后一条监测记录时间 %s", lastTime.format(DT)));
            list.add(sug);
        }

        // 4) 复评周期（按最高风险等级）：随访安排放最后，不抢前面的处置建议
        int maxLevel = conclusions.stream().mapToInt(c -> (Integer) c.getOrDefault("level", 0)).max().orElse(0);
        Map<String, Object> sug = new LinkedHashMap<>();
        sug.put("priority", 0);
        sug.put("text", String.format("复评安排：建议 %s后重新生成健康报告并复评",
                maxLevel >= 3 ? "1 周" : maxLevel == 2 ? "2 周" : "4 周"));
        sug.put("basis", String.format("按本次报告最高风险等级（%s）确定随访间隔", riskName(maxLevel)));
        list.add(sug);

        list.sort(Comparator.comparingInt((Map<String, Object> m) -> (Integer) m.get("priority")).reversed());
        return list;
    }

    /* ==================== 辅助 ==================== */

    /** 组的严重度：级别优先，其次看超标次数，用于给建议排序 */
    private int groupSeverity(String codes, Map<String, Map<String, Object>> indMap) {
        int maxLevel = 0;
        int abnormal = 0;
        for (String code : codes.split(",")) {
            Map<String, Object> ind = indMap.get(code);
            if (ind == null) {
                continue;
            }
            maxLevel = Math.max(maxLevel, (Integer) ind.get("level"));
            abnormal += (Integer) ind.get("abnormalCount");
        }
        return maxLevel * 10000 + abnormal;
    }

    private Map<String, Object> conclusion(int no, int level, String title, String text, List<String> evidenceNos) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("no", no);
        m.put("level", level);
        m.put("levelName", riskName(level));
        m.put("badge", riskName(level));
        m.put("title", title);
        m.put("text", text);
        m.put("evidenceNos", evidenceNos);
        return m;
    }

    /**
     * 参考范围出处：必须引用「真正决定边界的那条规则」。
     * 之前按顺序取第一条 ≥/≤ 规则，会出现「上限来自 140，却引用 180 那条规则」的依据错配。
     */
    private Map<String, Object> findRuleRef(List<Map<String, Object>> inds,
                                            Map<String, List<CdWarningRule>> ruleByInd) {
        List<String> refs = new ArrayList<>();
        for (Map<String, Object> i : inds) {
            Object up = i.get("upperRule");
            Object lo = i.get("lowerRule");
            if (up != null) {
                refs.add("上限依据 " + up);
            }
            if (lo != null) {
                refs.add("下限依据 " + lo);
            }
        }
        if (refs.isEmpty()) {
            return null;
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("text", "参考范围出处：" + String.join("；", refs)
                + "。达标判定口径为「≥ 类规则取最小阈值作上限、≤ 类规则取最大阈值作下限」，与预警引擎一致");
        return m;
    }

    private List<Map<String, Object>> rulesUsed(List<Map<String, Object>> indicators,
                                                Map<String, List<CdWarningRule>> ruleByInd) {
        List<Map<String, Object>> list = new ArrayList<>();
        for (Map<String, Object> i : indicators) {
            String code = (String) i.get("code");
            if ((Integer) i.get("count") == 0) {
                continue;
            }
            for (CdWarningRule r : ruleByInd.getOrDefault(code, new ArrayList<>())) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("ruleId", r.getRuleId());
                m.put("ruleName", r.getRuleName());
                m.put("indicatorCode", r.getIndicatorCode());
                m.put("indicatorName", StringUtils.hasText(r.getIndicatorName())
                        ? r.getIndicatorName() : IND_CN.getOrDefault(code, code));
                m.put("operator", r.getOperator());
                m.put("thresholdValue", r.getThresholdValue());
                m.put("thresholdDesc", r.getThresholdDesc());
                m.put("warningLevel", parseInt(r.getWarningLevel()));
                m.put("actionDesc", r.getActionDesc());
                list.add(m);
            }
        }
        return list;
    }

    private Map<String, Object> warningView(List<CdWarning> warnings) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("total", warnings.size());
        m.put("pending", warnings.stream().filter(w -> "0".equals(w.getHandleStatus())).count());
        m.put("handling", warnings.stream().filter(w -> "1".equals(w.getHandleStatus())).count());
        m.put("handled", warnings.stream().filter(w -> "2".equals(w.getHandleStatus())).count());
        m.put("highRisk", warnings.stream().filter(w -> "3".equals(w.getWarningLevel())).count());
        m.put("midRisk", warnings.stream().filter(w -> "2".equals(w.getWarningLevel())).count());
        m.put("lowRisk", warnings.stream().filter(w -> "1".equals(w.getWarningLevel())).count());
        m.put("items", warnings.stream().limit(10).map(w -> {
            Map<String, Object> x = new LinkedHashMap<>();
            x.put("warningId", w.getWarningId());
            x.put("indicatorName", w.getIndicatorName());
            x.put("value", w.getIndicatorValue());
            x.put("unit", w.getUnit());
            x.put("thresholdDesc", w.getThresholdDesc());
            x.put("level", parseInt(w.getWarningLevel()));
            x.put("handleStatus", w.getHandleStatus());
            x.put("handleStatusName", handleStatusName(w.getHandleStatus()));
            x.put("handleContent", w.getHandleContent());
            x.put("triggerTime", w.getTriggerTime() == null ? null : w.getTriggerTime().format(DT));
            return x;
        }).collect(Collectors.toList()));
        return m;
    }

    private Map<String, Object> scoreView(CdHealthScore score) {
        if (score == null) {
            return null;
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("healthScore", score.getHealthScore());
        // 与页面同口径：按健康分区间现算，不用库里那个不可靠的 risk_level 字段
        String hl = CdScoreServiceImpl.healthLevel(score.getHealthScore());
        m.put("healthLevel", hl);
        m.put("healthLevelName", CdScoreServiceImpl.healthLevelName(hl));
        m.put("calcTime", score.getCalcTime() == null ? null : score.getCalcTime().format(DT));
        m.put("triggerName", triggerName(score.getTriggerType()));
        List<Map<String, Object>> items = new ArrayList<>();
        if (StringUtils.hasText(score.getDetailJson())) {
            try {
                Map<String, Object> root = objectMapper.readValue(score.getDetailJson(), Map.class);
                if (root.get("items") instanceof List<?> list) {
                    for (Object o : list) {
                        if (o instanceof Map<?, ?> mm) {
                            Map<String, Object> item = new LinkedHashMap<>();
                            item.put("name", mm.get("name"));
                            item.put("formula", mm.get("formula"));
                            item.put("value", mm.get("value"));
                            item.put("weight", mm.get("weight"));
                            item.put("contribution", mm.get("contribution"));
                            item.put("desc", mm.get("desc"));
                            items.add(item);
                        }
                    }
                }
            } catch (Exception ignored) {
                // 忽略明细解析异常
            }
        }
        m.put("items", items);
        return m;
    }

    /**
     * 责任医生姓名：cd_patient 只存 doctor_id，姓名在 sys_user.real_name。
     * selectById 出来的实体不带非库字段，所以必须显式查一次，否则报告抬头是空的。
     */
    private String doctorNameOf(CdPatient patient) {
        if (StringUtils.hasText(patient.getPhysicianName())) {
            return patient.getPhysicianName();
        }
        if (patient.getDoctorId() == null) {
            return null;
        }
        SysUser u = sysUserMapper.selectById(patient.getDoctorId());
        if (u == null) {
            return null;
        }
        return StringUtils.hasText(u.getRealName()) ? u.getRealName() : u.getUsername();
    }

    private String deptNameOf(CdPatient patient) {
        if (patient.getDeptId() == null) {
            return null;
        }
        SysDept d = sysDeptMapper.selectById(patient.getDeptId());
        return d == null ? null : d.getDeptName();
    }

    private CdHealthScore latestScore(Long patientId) {
        List<CdHealthScore> list = healthScoreMapper.selectList(
                Wrappers.<CdHealthScore>lambdaQuery()
                        .eq(CdHealthScore::getPatientId, patientId)
                        .orderByDesc(CdHealthScore::getCalcTime)
                        .last("limit 1"));
        return list.isEmpty() ? null : list.get(0);
    }

    private List<String> notes(LocalDateTime from, LocalDateTime now, int ruleCount) {
        List<String> list = new ArrayList<>();
        list.add(String.format("数据来源：健康监测模块的原始测量记录（%s 至 %s）、预警中心的预警记录、"
                + "健康评分的评分记录、患者诊断记录。", from.format(D), now.format(D)));
        list.add(String.format("达标判定口径：将每条监测记录逐条比对系统当前启用的 %d 条预警规则，"
                + "任一规则命中即判为超出参考范围。", ruleCount));
        list.add("参考范围来源：由预警规则阈值推导，非人工设定；判定标准与系统预警引擎完全一致，"
                + "所列区间均为开区间（不含边界值）。");
        list.add("窗口差异说明：监测与预警统计使用本报告上方标注的窗口；健康评分使用其独立的 7 天滚动窗口，"
                + "因此评分明细里的录入次数可能少于报告统计的监测条数，两者不矛盾。");
        list.add("健康等级与本次评估级别是两个口径：健康等级按健康分区间划分，本次评估级别取报告内最严重的一条结论。");
        list.add("本报告由系统依据上述数据自动生成，供慢病随访管理使用，不作为临床诊断依据。");
        return list;
    }

    private String targetText(BigDecimal upper, BigDecimal lower, String unit) {
        String u = unitSuffix(unit);
        if (upper != null && lower != null) {
            return String.format("%s～%s%s", fmt(lower), fmt(upper), u);
        }
        if (upper != null) {
            return "＜" + fmt(upper) + u;
        }
        if (lower != null) {
            return "＞" + fmt(lower) + u;
        }
        return "未配置规则阈值";
    }

    /** 单位后缀：百分号直接贴数字，其余单位前置一个空格（"94%" / "140 mmHg"） */
    private String unitSuffix(String unit) {
        if (!StringUtils.hasText(unit)) {
            return "";
        }
        String u = unit.trim();
        return "%".equals(u) ? u : " " + u;
    }

    private boolean match(String op, BigDecimal v, BigDecimal t) {
        if (op == null || v == null || t == null) {
            return false;
        }
        int c = v.compareTo(t);
        return switch (op.trim()) {
            case ">=" -> c >= 0;
            case ">" -> c > 0;
            case "<=" -> c <= 0;
            case "<" -> c < 0;
            case "=", "==" -> c == 0;
            default -> false;
        };
    }

    private String ruleLabel(CdWarningRule r) {
        return String.format("#%s《%s》%s", r.getRuleId(), r.getRuleName(), r.getThresholdDesc());
    }

    private LocalDateTime timeOf(CdMeasure m) {
        return m.getMeasureTime() != null ? m.getMeasureTime() : m.getCreateTime();
    }

    private int parseInt(String s) {
        try {
            return s == null ? 0 : Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private String fmt(Object v) {
        if (v == null) {
            return "-";
        }
        if (v instanceof BigDecimal bd) {
            return bd.stripTrailingZeros().toPlainString();
        }
        return String.valueOf(v);
    }

    private String nvl(String s) {
        return StringUtils.hasText(s) ? s : "-";
    }

    private String riskName(int level) {
        return level >= 3 ? "高危" : level == 2 ? "中危" : level == 1 ? "低危" : "正常";
    }

    private String genderName(String g) {
        return "1".equals(g) ? "男" : "0".equals(g) ? "女" : "未知";
    }

    private String handleStatusName(String s) {
        return "0".equals(s) ? "待处理" : "1".equals(s) ? "处理中" : "2".equals(s) ? "已处理" : "-";
    }

    private String triggerName(String t) {
        return "1".equals(t) ? "监测触发" : "2".equals(t) ? "干预触发" : "3".equals(t) ? "定时任务" : "-";
    }

    /** 建议归并单元：同一处置动作下的多个指标合成一条建议 */
    private static class Sug {
        private final String action;
        private final List<String> names = new ArrayList<>();
        private final List<String> basis = new ArrayList<>();
        private int priority = 0;
        private int severity = 0;

        Sug(String action) {
            this.action = action;
        }
    }

    /** 依据收集器：统一编号 E1、E2 …… */
    private static class Ev {
        private final List<Map<String, Object>> list = new ArrayList<>();

        String add(String source, String detail) {
            return add(source, detail, null, null);
        }

        String add(String source, String detail, Long refWarningId) {
            return add(source, detail, refWarningId, null);
        }

        /**
         * @param refWarningId 非空时前端会在依据清单里给出「去核对」入口，跳到预警列表并高亮该条记录。
         *                     只对「预警记录」类依据有意义，其余来源传 null。
         * @param refIndicator 非空时前端给出「查记录」入口，跳到监测数据页并按该指标 + 超标状态筛选，
         *                     用于核对「某指标超标 N 次」这类依据的原始记录。
         */
        String add(String source, String detail, Long refWarningId, String refIndicator) {
            Map<String, Object> m = new LinkedHashMap<>();
            String no = "E" + (list.size() + 1);
            m.put("no", no);
            m.put("source", source);
            m.put("detail", detail);
            if (refWarningId != null) {
                m.put("refWarningId", refWarningId);
            }
            if (refIndicator != null) {
                m.put("refIndicator", refIndicator);
            }
            list.add(m);
            return no;
        }
    }
}
