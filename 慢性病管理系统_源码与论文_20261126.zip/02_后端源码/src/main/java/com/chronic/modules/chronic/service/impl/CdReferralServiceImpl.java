package com.chronic.modules.chronic.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.chronic.common.exception.ServiceException;
import com.chronic.common.result.PageResult;
import com.chronic.modules.chronic.entity.CdPatient;
import com.chronic.modules.chronic.entity.CdReferral;
import com.chronic.modules.chronic.mapper.CdPatientMapper;
import com.chronic.modules.chronic.mapper.CdReferralMapper;
import com.chronic.modules.chronic.query.ReferralQuery;
import com.chronic.modules.chronic.service.CdReferralService;
import com.chronic.modules.system.entity.SysDept;
import com.chronic.modules.system.mapper.SysDeptMapper;
import com.chronic.security.LoginUser;
import com.chronic.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * 转诊
 *
 * @author chronic
 */
@Service
@RequiredArgsConstructor
public class CdReferralServiceImpl extends ServiceImpl<CdReferralMapper, CdReferral> implements CdReferralService {

    private final CdPatientMapper patientMapper;
    private final SysDeptMapper deptMapper;

    @Override
    public PageResult<CdReferral> queryPage(ReferralQuery query) {
        LambdaQueryWrapper<CdReferral> w = new LambdaQueryWrapper<>();
        w.eq(query.getPatientId() != null, CdReferral::getPatientId, query.getPatientId())
                .eq(StringUtils.hasText(query.getUrgency()), CdReferral::getUrgency, query.getUrgency())
                .eq(StringUtils.hasText(query.getReferralStatus()), CdReferral::getReferralStatus, query.getReferralStatus())
                .like(StringUtils.hasText(query.getKeyword()), CdReferral::getPatientName, query.getKeyword())
                .orderByDesc(CdReferral::getApplyTime);
        Page<CdReferral> page = page(new Page<>(query.getPageNum(), query.getPageSize()), w);
        return PageResult.of(page.getTotal(), page.getRecords());
    }

    @Override
    public Long apply(CdReferral referral) {
        if (referral.getPatientId() == null) {
            throw new ServiceException("患者不能为空");
        }
        CdPatient patient = patientMapper.selectById(referral.getPatientId());
        if (patient == null) {
            throw new ServiceException("患者不存在");
        }
        LoginUser user = SecurityUtils.getLoginUser();
        referral.setReferralId(null);
        // 患者姓名以库里为准，不信任前端传值
        referral.setPatientName(patient.getName());
        referral.setFromDeptId(user.getDeptId());
        if (user.getDeptId() != null) {
            SysDept dept = deptMapper.selectById(user.getDeptId());
            referral.setFromDeptName(dept == null ? null : dept.getDeptName());
        }
        referral.setReferralStatus("0");
        referral.setApplyTime(LocalDateTime.now());
        referral.setAuditTime(null);
        referral.setAuditOpinion(null);
        referral.setDelFlag(null);
        save(referral);
        return referral.getReferralId();
    }

    @Override
    public void audit(Long referralId, Map<String, String> body) {
        CdReferral referral = getById(referralId);
        if (referral == null) {
            throw new ServiceException("转诊记录不存在");
        }
        if (!"0".equals(referral.getReferralStatus())) {
            throw new ServiceException("该转诊已审核，无法重复审核");
        }
        String status = body == null ? null : body.get("referralStatus");
        if (!"1".equals(status) && !"2".equals(status)) {
            throw new ServiceException("审核结果只能是 1(通过) 或 2(驳回)");
        }
        referral.setReferralStatus(status);
        referral.setAuditOpinion(body.get("auditOpinion"));
        referral.setReceiveHospital(body.get("receiveHospital"));
        referral.setReceiveDept(body.get("receiveDept"));
        referral.setAuditTime(LocalDateTime.now());
        updateById(referral);
    }
}
