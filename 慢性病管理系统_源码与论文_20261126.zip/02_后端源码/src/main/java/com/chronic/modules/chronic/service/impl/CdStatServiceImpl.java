package com.chronic.modules.chronic.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.chronic.modules.chronic.entity.CdMeasure;
import com.chronic.modules.chronic.entity.CdPatient;
import com.chronic.modules.chronic.entity.CdPatientDisease;
import com.chronic.modules.chronic.entity.CdWarningRule;
import com.chronic.modules.chronic.mapper.CdMeasureMapper;
import com.chronic.modules.chronic.mapper.CdPatientDiseaseMapper;
import com.chronic.modules.chronic.mapper.CdPatientMapper;
import com.chronic.modules.chronic.mapper.CdWarningRuleMapper;
import com.chronic.modules.chronic.service.CdStatService;
import com.chronic.modules.chronic.service.PatientDataScopeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 慢性病控制率统计实现。
 *
 * <p>判定口径与预警引擎、健康报告完全一致，避免出现「统计说达标、预警说有记录」的矛盾：
 * 参考范围从 cd_warning_rule 推导（≥ 类取最小阈值作上限、≤ 类取最大阈值作下限），均为开区间。</p>
 */
@Service
@RequiredArgsConstructor
public class CdStatServiceImpl implements CdStatService {

    /**
     * 病种 → 核心指标。
     * 高血压只取收缩压、舒张压：睡眠时长虽也在规则表里，但属生活方式指标，不作为血压控制率的判定依据。
     */
    private static final List<String[]> CORE_INDICATORS = List.of(
            new String[]{"1", "高血压", "sbp,dbp"},
            new String[]{"2", "2型糖尿病", "glu"},
            new String[]{"3", "冠心病", "hr"},
            new String[]{"4", "慢阻肺", "spo2,rr"});

    private static final Map<String, String> IND_CN = Map.of(
            "sbp", "收缩压", "dbp", "舒张压", "glu", "血糖", "hr", "心率",
            "spo2", "血氧饱和度", "rr", "呼吸频率", "sleep", "睡眠时长");

    private static final DateTimeFormatter DT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final DateTimeFormatter D = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final CdPatientDiseaseMapper patientDiseaseMapper;
    private final CdMeasureMapper measureMapper;
    private final CdWarningRuleMapper warningRuleMapper;
    private final CdPatientMapper patientMapper;
    private final PatientDataScopeService dataScope;

    @Override
    public Map<String, Object> diseaseControl(Integer days) {
        int win = (days == null || days <= 0) ? 30 : days;
        LocalDateTime to = LocalDateTime.now();
        LocalDateTime from = to.minusDays(win);

        // 统计必须和列表口径一致：医生只能统计自己有权看的患者，否则会出现
        // 「患者列表 9 人、控制率 15 人·病种」这种自相矛盾。管理员为 null 表示不限制。
        Set<Long> visible = dataScope.visiblePatientIds();
        boolean scoped = visible != null;

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("days", win);
        result.put("scoped", scoped);
        Map<String, Object> period = new LinkedHashMap<>();
        period.put("start", from.format(D));
        period.put("end", to.format(D));
        result.put("period", period);

        // 1) 规则参考范围：上限取 ≥ 类最小阈值，下限取 ≤ 类最大阈值
        List<CdWarningRule> rules = warningRuleMapper.selectList(
                Wrappers.<CdWarningRule>lambdaQuery().eq(CdWarningRule::getStatus, "0"));
        Map<String, BigDecimal[]> range = buildRanges(rules);
        Map<String, String> unitByInd = new HashMap<>();
        result.put("ruleCount", rules.size());
        result.put("indicatorCount", range.size());

        // 2) 窗口内监测数据：patientId → indicatorCode → 记录列表
        List<CdMeasure> measures = measureMapper.selectList(Wrappers.<CdMeasure>lambdaQuery()
                .ge(CdMeasure::getMeasureTime, from)
                .le(CdMeasure::getMeasureTime, to)
                .orderByAsc(CdMeasure::getMeasureTime));
        Map<Long, Map<String, List<CdMeasure>>> dataByPatient = new HashMap<>();
        for (CdMeasure m : measures) {
            if (m.getValue() == null || !StringUtils.hasText(m.getIndicatorCode())) {
                continue;
            }
            if (scoped && !visible.contains(m.getPatientId())) {
                continue;
            }
            dataByPatient.computeIfAbsent(m.getPatientId(), k -> new HashMap<>())
                    .computeIfAbsent(m.getIndicatorCode(), k -> new ArrayList<>())
                    .add(m);
            if (StringUtils.hasText(m.getUnit())) {
                unitByInd.put(m.getIndicatorCode(), m.getUnit());
            }
        }

        // 3) 病种 → 患者
        List<CdPatientDisease> pds = patientDiseaseMapper.selectList(null);
        Map<String, LinkedHashSet<Long>> diseasePatients = new LinkedHashMap<>();
        Map<String, String> diseaseNames = new HashMap<>();
        for (CdPatientDisease pd : pds) {
            if (!StringUtils.hasText(pd.getDiseaseCode())) {
                continue;
            }
            if (scoped && !visible.contains(pd.getPatientId())) {
                continue;
            }
            diseasePatients.computeIfAbsent(pd.getDiseaseCode(), k -> new LinkedHashSet<>())
                    .add(pd.getPatientId());
            diseaseNames.put(pd.getDiseaseCode(), pd.getDiseaseName());
        }

        // 患者姓名缓存
        Map<Long, String> nameById = new HashMap<>();
        for (CdPatient p : patientMapper.selectList(null)) {
            if (scoped && !visible.contains(p.getPatientId())) {
                continue;
            }
            nameById.put(p.getPatientId(), p.getName());
        }

        // 4) 逐病种统计
        List<Map<String, Object>> diseases = new ArrayList<>();
        int totalPatients = 0;
        int totalWithData = 0;
        int totalQualified = 0;
        for (String[] core : CORE_INDICATORS) {
            String code = core[0];
            String name = StringUtils.hasText(diseaseNames.get(code)) ? diseaseNames.get(code) : core[1];
            String[] codes = core[2].split(",");
            LinkedHashSet<Long> pids = diseasePatients.getOrDefault(code, new LinkedHashSet<>());

            List<Map<String, Object>> details = new ArrayList<>();
            int withData = 0;
            int qualified = 0;
            for (Long pid : pids) {
                Map<String, List<CdMeasure>> mine = dataByPatient.getOrDefault(pid, Map.of());
                List<Map<String, Object>> items = new ArrayList<>();
                boolean hasAny = false;
                boolean allOk = true;
                for (String ind : codes) {
                    List<CdMeasure> list = mine.getOrDefault(ind, List.of());
                    Map<String, Object> item = new LinkedHashMap<>();
                    item.put("code", ind);
                    item.put("name", IND_CN.getOrDefault(ind, ind));
                    item.put("unit", unitByInd.getOrDefault(ind, ""));
                    BigDecimal[] lr = range.get(ind);
                    item.put("lower", lr == null ? null : lr[0]);
                    item.put("upper", lr == null ? null : lr[1]);
                    if (list.isEmpty()) {
                        item.put("count", 0);
                        item.put("qualified", null);   // 未采集，不判达标也不判不达标
                        items.add(item);
                        continue;
                    }
                    hasAny = true;
                    BigDecimal min = null;
                    BigDecimal max = null;
                    int bad = 0;
                    for (CdMeasure m : list) {
                        BigDecimal v = m.getValue();
                        if (min == null || v.compareTo(min) < 0) {
                            min = v;
                        }
                        if (max == null || v.compareTo(max) > 0) {
                            max = v;
                        }
                        if (!inRange(v, lr)) {
                            bad++;
                        }
                    }
                    boolean ok = bad == 0;
                    if (!ok) {
                        allOk = false;
                    }
                    item.put("count", list.size());
                    item.put("min", min);
                    item.put("max", max);
                    item.put("abnormalCount", bad);
                    item.put("qualified", ok);
                    items.add(item);
                }
                if (!hasAny) {
                    continue;   // 该病种核心指标一条数据都没有，不纳入分母
                }
                withData++;
                if (allOk) {
                    qualified++;
                }
                Map<String, Object> d = new LinkedHashMap<>();
                d.put("patientId", pid);
                d.put("name", nameById.getOrDefault(pid, "患者 " + pid));
                d.put("qualified", allOk);
                d.put("items", items);
                details.add(d);
            }
            details.sort((a, b) -> {
                boolean qa = Boolean.TRUE.equals(a.get("qualified"));
                boolean qb = Boolean.TRUE.equals(b.get("qualified"));
                if (qa != qb) {
                    return qa ? 1 : -1;   // 不达标的排前面，方便一眼看到问题患者
                }
                return String.valueOf(a.get("name")).compareTo(String.valueOf(b.get("name")));
            });

            Map<String, Object> dm = new LinkedHashMap<>();
            dm.put("code", code);
            dm.put("name", name);
            dm.put("indicatorCodes", core[2]);
            dm.put("indicatorText", String.join("、",
                    java.util.Arrays.stream(codes).map(c -> IND_CN.getOrDefault(c, c)).collect(Collectors.toList())));
            dm.put("patientCount", pids.size());
            dm.put("withData", withData);
            dm.put("noData", pids.size() - withData);
            dm.put("qualified", qualified);
            dm.put("unqualified", withData - qualified);
            dm.put("rate", withData == 0 ? null : BigDecimal.valueOf(qualified)
                    .divide(BigDecimal.valueOf(withData), 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100)).setScale(1, RoundingMode.HALF_UP));
            dm.put("details", details);
            diseases.add(dm);

            totalPatients += pids.size();
            totalWithData += withData;
            totalQualified += qualified;
        }
        diseases.sort(Comparator.comparingInt((Map<String, Object> m) -> (Integer) m.get("patientCount")).reversed());

        Map<String, Object> overall = new LinkedHashMap<>();
        overall.put("patientDiseaseCount", totalPatients);   // 患者-病种条目数（一人多病会重复计）
        overall.put("withData", totalWithData);
        overall.put("qualified", totalQualified);
        overall.put("noData", totalPatients - totalWithData);
        overall.put("rate", totalWithData == 0 ? null : BigDecimal.valueOf(totalQualified)
                .divide(BigDecimal.valueOf(totalWithData), 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100)).setScale(1, RoundingMode.HALF_UP));
        result.put("overall", overall);
        result.put("diseases", diseases);
        result.put("generatedAt", to.format(DT));

        List<String> notes = new ArrayList<>();
        notes.add("控制率口径：该病种的核心指标在统计窗口内全部落在参考范围内，才算该患者达标。");
        notes.add("参考范围由系统启用的预警规则推导（≥ 类规则取最小阈值作上限、≤ 类规则取最大阈值作下限，均为开区间），与预警引擎一致。");
        notes.add("窗口内该病种核心指标无任何记录的患者不计入分母，单列为「无数据」，避免把「没测」误算成「达标」或「不达标」。");
        notes.add("高血压以收缩压、舒张压判定；睡眠时长属生活方式指标，虽在规则表内，不纳入血压控制率。");
        if (scoped) {
            notes.add("统计范围：仅当前账号有权查看的患者（与患者列表一致），管理员可见全部。");
        }
        result.put("notes", notes);
        return result;
    }

    /** 从规则推导每个指标的开区间参考范围：[lower, upper] */
    private Map<String, BigDecimal[]> buildRanges(List<CdWarningRule> rules) {
        Map<String, BigDecimal> upper = new HashMap<>();
        Map<String, BigDecimal> lower = new HashMap<>();
        for (CdWarningRule r : rules) {
            if (!StringUtils.hasText(r.getIndicatorCode()) || r.getThresholdValue() == null
                    || !StringUtils.hasText(r.getOperator())) {
                continue;
            }
            String op = r.getOperator().trim();
            String code = r.getIndicatorCode();
            if (op.startsWith(">")) {
                BigDecimal cur = upper.get(code);
                if (cur == null || r.getThresholdValue().compareTo(cur) < 0) {
                    upper.put(code, r.getThresholdValue());
                }
            } else if (op.startsWith("<")) {
                BigDecimal cur = lower.get(code);
                if (cur == null || r.getThresholdValue().compareTo(cur) > 0) {
                    lower.put(code, r.getThresholdValue());
                }
            }
        }
        Map<String, BigDecimal[]> out = new HashMap<>();
        for (String code : upper.keySet()) {
            out.put(code, new BigDecimal[]{lower.get(code), upper.get(code)});
        }
        for (String code : lower.keySet()) {
            out.putIfAbsent(code, new BigDecimal[]{lower.get(code), upper.get(code)});
        }
        return out;
    }

    private boolean inRange(BigDecimal v, BigDecimal[] lr) {
        if (lr == null) {
            return true;
        }
        BigDecimal lo = lr[0];
        BigDecimal hi = lr[1];
        if (lo != null && v.compareTo(lo) <= 0) {
            return false;
        }
        if (hi != null && v.compareTo(hi) >= 0) {
            return false;
        }
        return true;
    }
}
