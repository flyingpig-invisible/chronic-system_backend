package com.chronic.modules.chronic.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chronic.common.exception.ServiceException;
import com.chronic.common.result.PageResult;
import com.chronic.modules.chronic.dto.EmergencyLinkDTO;
import com.chronic.modules.chronic.dto.WarningHandleDTO;
import com.chronic.modules.chronic.entity.*;
import com.chronic.modules.chronic.mapper.*;
import com.chronic.modules.chronic.query.WarningQuery;
import com.chronic.modules.chronic.service.CdWarningService;
import com.chronic.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 预警服务实现
 *
 * @author chronic
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CdWarningServiceImpl implements CdWarningService {

    private final CdWarningMapper warningMapper;
    private final CdWarningRuleMapper ruleMapper;
    private final CdEmergencyLinkMapper emergencyLinkMapper;
    private final CdPatientMapper patientMapper;
    private final CdMeasureMapper measureMapper;

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /** 组合/持续升级的回看窗口（小时） */
    private static final int ESCALATE_WINDOW_HOURS = 24;

    @Override
    public PageResult<CdWarning> pageWarning(WarningQuery query) {
        Page<CdWarning> page = warningMapper.selectPage(
                new Page<>(query.getPageNum(), query.getPageSize()), buildWrapper(query));
        return PageResult.of(page);
    }

    @Override
    public CdWarning getWarning(Long warningId) {
        CdWarning warning = warningMapper.selectById(warningId);
        if (warning == null) {
            throw new ServiceException("预警不存在");
        }
        // 补充处置建议
        if (warning.getRuleId() != null) {
            CdWarningRule rule = ruleMapper.selectById(warning.getRuleId());
            if (rule != null) {
                warning.setActionDesc(rule.getActionDesc());
            }
        }
        return warning;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void handleWarning(Long warningId, WarningHandleDTO dto) {
        CdWarning warning = warningMapper.selectById(warningId);
        if (warning == null) {
            throw new ServiceException("预警不存在");
        }

        CdWarning update = new CdWarning();
        update.setWarningId(warningId);
        update.setHandleStatus(dto.getHandleStatus());
        update.setHandleType(dto.getHandleType());
        update.setHandleContent(dto.getHandleContent());
        update.setHandleBy(SecurityUtils.getUsername());
        update.setHandleTime(LocalDateTime.now());
        warningMapper.updateById(update);

        // 联动急救
        if (Boolean.TRUE.equals(dto.getLinkEmergency())) {
            EmergencyLinkDTO linkDTO = new EmergencyLinkDTO();
            linkDTO.setChannel("120");
            linkDTO.setReceiver("急救中心");
            linkDTO.setRemark(dto.getRemark());
            linkEmergency(warningId, linkDTO);
        }

        // 已处理则减少患者待处理预警数
        if ("2".equals(dto.getHandleStatus())) {
            CdPatient patient = patientMapper.selectById(warning.getPatientId());
            if (patient != null) {
                CdPatient pu = new CdPatient();
                pu.setPatientId(patient.getPatientId());
                int count = patient.getPendingWarningCount() == null ? 0 : patient.getPendingWarningCount();
                pu.setPendingWarningCount(Math.max(0, count - 1));
                patientMapper.updateById(pu);
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void linkEmergency(Long warningId, EmergencyLinkDTO dto) {
        CdWarning warning = warningMapper.selectById(warningId);
        if (warning == null) {
            throw new ServiceException("预警不存在");
        }

        CdEmergencyLink link = new CdEmergencyLink();
        link.setWarningId(warningId);
        link.setPatientId(warning.getPatientId());
        link.setPatientName(warning.getPatientName());
        link.setChannel(dto.getChannel());
        link.setReceiver(dto.getReceiver());
        link.setLinkResult(dto.getLinkResult());
        link.setLinkBy(SecurityUtils.getUsername());
        link.setLinkTime(LocalDateTime.now());
        link.setRemark(dto.getRemark());
        emergencyLinkMapper.insert(link);

        CdWarning update = new CdWarning();
        update.setWarningId(warningId);
        update.setEmergencyLinked("1");
        warningMapper.updateById(update);

        log.info("预警 {} 已联动急救：{} -> {}", warningId, dto.getChannel(), dto.getReceiver());
    }

    @Override
    public List<CdEmergencyLink> listEmergencyByWarning(Long warningId) {
        return emergencyLinkMapper.selectList(Wrappers.<CdEmergencyLink>lambdaQuery()
                .eq(CdEmergencyLink::getWarningId, warningId)
                .orderByDesc(CdEmergencyLink::getLinkTime));
    }

    @Override
    public PageResult<CdEmergencyLink> pageEmergency(WarningQuery query) {
        Page<CdEmergencyLink> page = emergencyLinkMapper.selectPage(
                new Page<>(query.getPageNum(), query.getPageSize()),
                Wrappers.<CdEmergencyLink>lambdaQuery()
                        .like(StringUtils.hasText(query.getPatientName()), CdEmergencyLink::getPatientName, query.getPatientName())
                        .orderByDesc(CdEmergencyLink::getLinkTime));
        return PageResult.of(page);
    }

    @Override
    public List<Map<String, Object>> statByLevel(WarningQuery query) {
        List<CdWarning> list = warningMapper.selectList(buildWrapper(query));
        Map<String, String> levelName = Map.of("1", "低危", "2", "中危", "3", "高危");
        List<Map<String, Object>> result = new ArrayList<>();
        for (String level : new String[]{"3", "2", "1"}) {
            long count = list.stream().filter(w -> level.equals(w.getWarningLevel())).count();
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("riskLevel", level);
            item.put("name", levelName.get(level));
            item.put("count", count);
            item.put("ratio", list.isEmpty() ? 0 : Math.round(count * 10000.0 / list.size()) / 100.0);
            result.add(item);
        }
        return result;
    }

    @Override
    public Map<String, Object> statResponse(WarningQuery query) {
        List<CdWarning> list = warningMapper.selectList(buildWrapper(query));
        long total = list.size();
        long handled = list.stream().filter(w -> "2".equals(w.getHandleStatus())).count();
        long pending = list.stream().filter(w -> "0".equals(w.getHandleStatus())).count();

        double avgMinutes = list.stream()
                .filter(w -> w.getHandleTime() != null && w.getTriggerTime() != null)
                .mapToLong(w -> java.time.Duration.between(w.getTriggerTime(), w.getHandleTime()).toMinutes())
                .average().orElse(0);

        Map<String, Object> stat = new LinkedHashMap<>();
        stat.put("totalCount", total);
        stat.put("handledCount", handled);
        stat.put("pendingCount", pending);
        stat.put("avgResponseMinutes", Math.round(avgMinutes * 100.0) / 100.0);
        stat.put("handleRate", total == 0 ? 0 : Math.round(handled * 10000.0 / total) / 100.0);
        return stat;
    }

    @Override
    public List<CdWarning> listForExport(WarningQuery query) {
        query.setPageNum(1);
        query.setPageSize(10000);
        return warningMapper.selectList(buildWrapper(query));
    }

    @Override
    public void checkAndCreateWarning(Long patientId, String patientName, String indicatorCode,
                                      BigDecimal value, String unit, Long measureId) {
        if (value == null) {
            return;
        }

        // ---------- 算法一·第 1 步：危急值短路 ----------
        // 命中危急值规则的，直接按最高级落库并打标，不与普通规则比大小、不参与后续升级
        CdWarningRule critical = matchCriticalRule(indicatorCode, value);
        CdWarningRule matched = critical != null ? critical : matchRuleCode(indicatorCode, value);
        if (matched == null) {
            return;
        }
        boolean isCritical = critical != null;
        String originLevel = matched.getWarningLevel();

        CdWarning warning = new CdWarning();
        warning.setPatientId(patientId);
        warning.setPatientName(patientName);
        warning.setDiseaseCode(matched.getDiseaseCode());
        warning.setIndicatorCode(indicatorCode);
        warning.setIndicatorName(matched.getIndicatorName());
        warning.setIndicatorValue(value);
        warning.setUnit(unit);
        warning.setThresholdDesc(matched.getThresholdDesc());
        warning.setRuleId(matched.getRuleId());
        warning.setWarningLevel(matched.getWarningLevel());
        warning.setHandleStatus("0");
        warning.setEmergencyLinked("0");
        warning.setCriticalFlag(isCritical ? "1" : "0");
        warning.setTriggerTime(LocalDateTime.now());
        warningMapper.insert(warning);

        // ---------- 算法一·第 2 步：组合 / 持续升级 ----------
        if (!isCritical) {
            Escalation esc = detectEscalation(patientId, matched, warning.getWarningId());
            if (esc != null) {
                warning.setOriginLevel(originLevel);
                warning.setWarningLevel("3");
                warning.setEscalateType(esc.type);
                warning.setEscalateReason(esc.reason);
                warning.setThresholdDesc(matched.getThresholdDesc() + "　" + esc.tag());
                cdWarningUpdate(warning);
                log.info("患者[{}] 指标[{}={}] 触发组合升级：{}", patientName, indicatorCode, value, esc.reason);
            }
        }

        // 关联监测记录
        if (measureId != null) {
            CdMeasure m = new CdMeasure();
            m.setMeasureId(measureId);
            m.setAbnormalFlag("1");
            measureMapper.updateById(m);
        }

        // 更新患者待处理预警数；风险评分/等级统一由评分计算按预警规则得出，此处不再抬高
        CdPatient patient = patientMapper.selectById(patientId);
        if (patient != null) {
            CdPatient pu = new CdPatient();
            pu.setPatientId(patientId);
            pu.setPendingWarningCount((patient.getPendingWarningCount() == null ? 0 : patient.getPendingWarningCount()) + 1);
            patientMapper.updateById(pu);
        }

        log.info("患者[{}] 指标[{}={}] 触发 {} 预警{}", patientName, indicatorCode, value,
                matched.getWarningLevel(), isCritical ? "（危急值）" : "");
    }

    /** 只更新预警的等级/升级信息，避免整行覆盖 */
    private void cdWarningUpdate(CdWarning w) {
        CdWarning upd = new CdWarning();
        upd.setWarningId(w.getWarningId());
        upd.setWarningLevel(w.getWarningLevel());
        upd.setThresholdDesc(w.getThresholdDesc());
        upd.setOriginLevel(w.getOriginLevel());
        upd.setEscalateType(w.getEscalateType());
        upd.setEscalateReason(w.getEscalateReason());
        warningMapper.updateById(upd);
    }

    /** 升级结论 */
    private static class Escalation {
        final String type;
        final String reason;

        Escalation(String type, String reason) {
            this.type = type;
            this.reason = reason;
        }

        String tag() {
            return "【" + ("COMBO".equals(type) ? "组合升级" : "持续升级") + "】";
        }
    }

    /**
     * 组合升级判定。
     * <ul>
     *   <li>COMBO：同一病种在 24 小时内出现 ≥2 个不同指标异常（均中危及以上）→ 升级为高危</li>
     *   <li>PERSIST：同一指标在 24 小时内累计异常 ≥3 次 → 升级为高危</li>
     * </ul>
     */
    private Escalation detectEscalation(Long patientId, CdWarningRule rule, Long selfId) {
        if ("3".equals(rule.getWarningLevel())) {
            return null;
        }
        LocalDateTime from = LocalDateTime.now().minusHours(ESCALATE_WINDOW_HOURS);
        List<CdWarning> recent = warningMapper.selectList(Wrappers.<CdWarning>lambdaQuery()
                .eq(CdWarning::getPatientId, patientId)
                .eq(CdWarning::getHandleStatus, "0")
                .ge(CdWarning::getTriggerTime, from)
                .ne(CdWarning::getWarningId, selfId));

        // a) 同病种多指标组合：设计口径是"均中危及以上"，故本次预警本身也必须 ≥2 级
        if (level(rule.getWarningLevel()) >= 2) {
            LinkedHashSet<String> partners = new LinkedHashSet<>();
            for (CdWarning w : recent) {
                if (!Objects.equals(rule.getDiseaseCode(), w.getDiseaseCode())) {
                    continue;
                }
                if (Objects.equals(w.getIndicatorCode(), rule.getIndicatorCode())) {
                    continue;
                }
                if (level(w.getWarningLevel()) >= 2) {
                    partners.add(w.getIndicatorName() == null ? w.getIndicatorCode() : w.getIndicatorName());
                }
            }
            if (!partners.isEmpty()) {
                return new Escalation("COMBO", String.format(
                        "24 小时内同病种出现 %d 个指标异常（%s + %s），按组合规则升级为高危",
                        partners.size() + 1, rule.getIndicatorName(), String.join("、", partners)));
            }
        }

        // b) 同指标持续异常
        int same = 0;
        for (CdWarning w : recent) {
            if (Objects.equals(w.getIndicatorCode(), rule.getIndicatorCode())) {
                same++;
            }
        }
        if (same >= 2) {
            return new Escalation("PERSIST", String.format(
                    "同一指标「%s」24 小时内累计异常 %d 次，按持续规则升级为高危",
                    rule.getIndicatorName(), same + 1));
        }
        return null;
    }

    private int level(String s) {
        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            return 1;
        }
    }

    /** 命中危急值规则（is_critical=1），取最高等级的一条 */
    @Override
    public CdWarningRule matchCriticalRule(String indicatorCode, BigDecimal value) {
        if (!StringUtils.hasText(indicatorCode) || value == null) {
            return null;
        }
        List<CdWarningRule> rules = ruleMapper.selectList(Wrappers.<CdWarningRule>lambdaQuery()
                .eq(CdWarningRule::getIndicatorCode, indicatorCode)
                .eq(CdWarningRule::getStatus, "0")
                .eq(CdWarningRule::getIsCritical, 1));
        CdWarningRule hit = null;
        for (CdWarningRule rule : rules) {
            if (matchRule(rule, value)) {
                if (hit == null || level(rule.getWarningLevel()) > level(hit.getWarningLevel())) {
                    hit = rule;
                }
            }
        }
        return hit;
    }

    @Override
    public CdWarningRule matchRuleCode(String indicatorCode, BigDecimal value) {
        if (!StringUtils.hasText(indicatorCode) || value == null) {
            return null;
        }
        List<CdWarningRule> rules = ruleMapper.selectList(Wrappers.<CdWarningRule>lambdaQuery()
                .eq(CdWarningRule::getIndicatorCode, indicatorCode)
                .eq(CdWarningRule::getStatus, "0"));
        CdWarningRule matched = null;
        for (CdWarningRule rule : rules) {
            if (matchRule(rule, value)) {
                if (matched == null || rule.getWarningLevel().compareTo(matched.getWarningLevel()) > 0) {
                    matched = rule;
                }
            }
        }
        return matched;
    }

    /** 判断是否命中规则 */
    private boolean matchRule(CdWarningRule rule, BigDecimal value) {
        BigDecimal threshold = rule.getThresholdValue();
        if (threshold == null) {
            return false;
        }
        int cmp = value.compareTo(threshold);
        return switch (rule.getOperator()) {
            case ">=" -> cmp >= 0;
            case ">" -> cmp > 0;
            case "<=" -> cmp <= 0;
            case "<" -> cmp < 0;
            case "=" -> cmp == 0;
            default -> false;
        };
    }

    private LambdaQueryWrapper<CdWarning> buildWrapper(WarningQuery query) {
        LambdaQueryWrapper<CdWarning> wrapper = Wrappers.<CdWarning>lambdaQuery()
                .eq(query.getPatientId() != null, CdWarning::getPatientId, query.getPatientId())
                .like(StringUtils.hasText(query.getPatientName()), CdWarning::getPatientName, query.getPatientName())
                .eq(StringUtils.hasText(query.getDiseaseCode()), CdWarning::getDiseaseCode, query.getDiseaseCode())
                .eq(StringUtils.hasText(query.getWarningLevel()), CdWarning::getWarningLevel, query.getWarningLevel())
                .eq(StringUtils.hasText(query.getHandleStatus()), CdWarning::getHandleStatus, query.getHandleStatus())
                .eq(StringUtils.hasText(query.getIndicatorCode()), CdWarning::getIndicatorCode, query.getIndicatorCode())
                .ge(StringUtils.hasText(query.getBeginTime()), CdWarning::getTriggerTime,
                        StringUtils.hasText(query.getBeginTime()) ? LocalDateTime.parse(query.getBeginTime(), DTF) : null)
                .le(StringUtils.hasText(query.getEndTime()), CdWarning::getTriggerTime,
                        StringUtils.hasText(query.getEndTime()) ? LocalDateTime.parse(query.getEndTime(), DTF) : null);
        // 高危优先
        return wrapper.orderByAsc(CdWarning::getHandleStatus)
                .orderByDesc(CdWarning::getWarningLevel)
                .orderByDesc(CdWarning::getTriggerTime);
    }
}
