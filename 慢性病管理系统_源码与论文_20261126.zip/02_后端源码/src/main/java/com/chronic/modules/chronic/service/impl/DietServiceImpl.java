package com.chronic.modules.chronic.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.chronic.common.exception.ServiceException;
import com.chronic.modules.chronic.entity.CdDietPlan;
import com.chronic.modules.chronic.entity.CdFood;
import com.chronic.modules.chronic.entity.CdPatient;
import com.chronic.modules.chronic.entity.CdPatientDisease;
import com.chronic.modules.chronic.entity.CdPatientProfile;
import com.chronic.modules.chronic.mapper.CdDietPlanMapper;
import com.chronic.modules.chronic.mapper.CdFoodMapper;
import com.chronic.modules.chronic.mapper.CdPatientDiseaseMapper;
import com.chronic.modules.chronic.mapper.CdPatientMapper;
import com.chronic.modules.chronic.mapper.CdPatientProfileMapper;
import com.chronic.modules.chronic.service.DietService;
import com.chronic.modules.chronic.vo.DietPlanVO;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 算法五：病种感知的膳食约束优化推荐
 *
 * <h3>数据底座</h3>
 * 食物候选池来自 cd_food（《四种慢病饮食推荐与限制清单》原文 1698 条），
 * 每条自带高血压 / 糖尿病 / 冠心病 / 慢阻肺的「推荐 / 适量 / 限制」判定与判定依据。
 * 算法不再自造阈值：<b>凡在患者任一病种下判为"限制"的食物直接剔除</b>，
 * 判为"推荐"的在代价函数里加权。
 *
 * <h3>问题形式化</h3>
 * 给定能量目标 T 与病种集合 D，为 4 个餐次各挑一组食物，使
 * ① 全天能量贴近 T ② 各病种约束全部满足 ③ 同一菜品不重复 ④ 清单推荐占比尽量高。
 * 属于带约束的离散 + 连续混合优化。
 *
 * <h3>求解（分解式）</h3>
 * <ul>
 *   <li><b>离散层</b>：每餐枚举 主食×蛋白×蔬菜×蔬菜 的笛卡尔积（每类只保留适配度前 N 个，≤1 万组），
 *       逐组打分取最小代价。</li>
 *   <li><b>连续层</b>：组合定下后，把"主食"份量当作连续变量，直接解
 *       g = (餐目标能量 − 其余菜品能量) / 主食能量密度，再按 [min, maxG] 截断。
 *       这一步让能量偏差从 20%~30% 直接压到 3% 以内——上一版固定份量的方案就是卡在这里。</li>
 *   <li><b>修补层</b>：仍有能量缺口时按餐次逐轮加主食；钠超标时做同类低钠替换。</li>
 * </ul>
 *
 * <h3>调味基准</h3>
 * 清单只管食材，不含烹调油盐。方案显式计入 烹调油 20 g（180 kcal）与 食盐 3 g（钠 1180 mg），
 * 并在 totals 里单列，避免"看起来钠很低"的假象。
 *
 * @author chronic
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DietServiceImpl implements DietService {

    private final CdPatientMapper patientMapper;
    private final CdPatientDiseaseMapper diseaseMapper;
    private final CdFoodMapper foodMapper;
    private final CdDietPlanMapper dietPlanMapper;
    private final CdPatientProfileMapper profileMapper;
    private final ObjectMapper objectMapper;

    private static final Map<String, String> DISEASE_NAME = Map.of(
            "1", "高血压", "2", "2型糖尿病", "3", "冠心病", "4", "慢阻肺");

    /** 调味基准：烹调油 25 g（膳食指南 25~30 g）、食盐 3 g（限盐 <5 g/d，留 2 g 余量自行调味） */
    private static final int OIL_G = 25;
    private static final double OIL_KCAL = 225;
    private static final double OIL_FAT = 25;
    private static final double OIL_SAT = 1.75;         // 菜籽油饱和脂肪约占 7%
    private static final int SALT_G = 3;
    private static final double SALT_SODIUM = 1180;

    /** 每类候选上限：控制笛卡尔积规模（12×8×8 ≈ 800 组/餐） */
    private static final Map<String, Integer> TOP_N = Map.of(
            "主食", 10, "蛋白", 12, "蔬菜", 8, "水果", 8, "奶类", 6, "坚果", 6);

    private static final int MAX_COMBOS = 30000;

    /**
     * 一律降权的食材特征：内脏、加工肉、干制水产、腌腊熏烤。
     * 这类食物营养数字往往"好看"，但日常配餐不合适，也基本是各病种指南明确回避的对象。
     */
    private static final java.util.regex.Pattern PENAL = java.util.regex.Pattern.compile(
            "肝|肚|肠|肺|肾|脑|舌|耳|蹄|爪|血|鞭|心|肫|胰|骨|肘|掌|尾|鼻|唇|猪皮|鸡皮|鸭皮|鱼皮|蹄筋|"
                    + "虾皮|虾米|海米|干贝|鱼子|鱼片干|罐头|腊|咸|熏|午餐肉|火腿|培根|香肠|肉松|肉干|肉脯");

    /** 常见家常食材加权：让方案落在"看得懂、买得到、做得出"的范围里 */
    private static final java.util.regex.Pattern COMMON = java.util.regex.Pattern.compile(
            "鸡胸|鸡腿|鸡蛋|牛肉\\(瘦\\)|猪肉\\(瘦\\)|羊肉\\(瘦\\)|草鱼|鲈鱼|鲫鱼|带鱼|对虾|虾仁|"
                    + "豆腐|腐竹|豆浆|牛乳|酸奶|"
                    + "白菜|菠菜|油菜|芹菜|生菜|西兰花|菜花|番茄|黄瓜|冬瓜|南瓜|茄子|辣椒|萝卜|"
                    + "豆角|豇豆|莴笋|空心菜|茼蒿|韭菜|洋葱|胡萝卜|西葫芦|苦瓜|丝瓜|鲜蘑|香菇|平菇|金针菇|"
                    + "米饭|馒头|面条|燕麦|小米|玉米|红薯|土豆|山药|荞麦|年糕|面包");

    /** 菌藻类：一餐两道菌菇不现实，也容易让人以为方案在凑指标 */
    private static final java.util.regex.Pattern FUNGI = java.util.regex.Pattern.compile(
            "蘑|菇|耳|菌|藻|紫菜|海带|发菜|石花菜|琼脂|地衣");

    private static final java.util.regex.Pattern BREAKFAST_STAPLE = java.util.regex.Pattern.compile(
            "馒头|面包|燕麦|粥|花卷|饼");

    // =========================================================================
    //  入口
    // =========================================================================

    @Override
    public DietPlanVO recommend(Long patientId, LocalDate date, Integer kcalOverride) {
        CdPatient patient = patientMapper.selectById(patientId);
        if (patient == null) {
            throw new ServiceException("患者不存在");
        }
        LocalDate planDate = date == null ? LocalDate.now() : date;

        List<String> diseases = diseaseMapper.selectList(Wrappers.<CdPatientDisease>lambdaQuery()
                        .eq(CdPatientDisease::getPatientId, patientId))
                .stream().map(CdPatientDisease::getDiseaseCode).distinct().collect(Collectors.toList());

        int target = kcalOverride != null && kcalOverride > 800
                ? kcalOverride : energyTarget(patient, diseases);
        // 餐次预算 = 总目标 − 烹调油（油是固定配比，不参与配餐搜索）
        int mealBudget = Math.max(800, (int) Math.round(target - OIL_KCAL));

        List<CdFood> pool = foodMapper.selectList(Wrappers.<CdFood>lambdaQuery()
                .eq(CdFood::getStatus, "1"));
        if (pool.isEmpty()) {
            throw new ServiceException("食物库为空，请先导入《四种慢病饮食推荐与限制清单》");
        }

        // ---- 病种过滤：任一病种判"限制"→ 直接出局 ----
        int limited = 0;
        List<CdFood> usable = new ArrayList<>();
        for (CdFood f : pool) {
            if ("限制".equals(worstVerdict(f, diseases))) {
                limited++;
            } else {
                usable.add(f);
            }
        }
        if (usable.isEmpty()) {
            throw new ServiceException("该患者病种组合下食物池为空，请检查判定数据");
        }
        // 推荐率门槛按该病种池的实际推荐占比折算：清单里慢阻肺判「推荐」的仅约 9%，
        // 一刀切 40% 等于让慢阻肺患者永远不达标；取池内占比的 1.5 倍，并夹在 [25%, 40%]
        long recInPool = usable.stream().filter(f -> "推荐".equals(worstVerdict(f, diseases))).count();
        int recFloor = (int) Math.round(Math.max(25, Math.min(40, recInPool * 150.0 / usable.size())));

        // ---- 每类按适配度排序，取前 N，并按日期做轻量扰动保证每天方案不完全相同 ----
        long seed = planDate.toEpochDay();
        Map<String, List<CdFood>> byCat = usable.stream()
                .collect(Collectors.groupingBy(CdFood::getCategory));
        Map<String, List<CdFood>> candByCat = new HashMap<>();
        for (Map.Entry<String, List<CdFood>> e : byCat.entrySet()) {
            candByCat.put(e.getKey(), pick(e.getValue(), diseases, seed, TOP_N.getOrDefault(e.getKey(), 6)));
        }

        // ---- 逐餐求解 ----
        Set<String> used = new HashSet<>();
        List<DietPlanVO.Meal> meals = new ArrayList<>();
        meals.add(solve("早餐", 0.25, mealBudget, diseases,
                List.of(cand("主食", candByCat), cand("蛋白", candByCat), cand("奶类", candByCat)), used));
        meals.add(solve("午餐", 0.35, mealBudget, diseases,
                List.of(cand("主食", candByCat), cand("蛋白", candByCat), cand("蔬菜", candByCat), cand("蔬菜", candByCat)), used));
        meals.add(solve("晚餐", 0.30, mealBudget, diseases,
                List.of(cand("主食", candByCat), cand("蛋白", candByCat), cand("蔬菜", candByCat), cand("蔬菜", candByCat)), used));
        List<List<CdFood>> snack = new ArrayList<>();
        if (diseases.contains("4") || diseases.contains("3")) {
            // 慢阻肺需高能量高蛋白加餐；冠心病用坚果补不饱和脂肪（清单亦推荐核桃）
            snack.add(cand("坚果", candByCat));
        }
        snack.add(cand("水果", candByCat));
        meals.add(solve("加餐", 0.10, mealBudget, diseases, snack, used));
        meals.removeIf(m -> m.getItems().isEmpty());

        // ---- 能量补齐 ----
        double preTopUp = meals.stream().flatMap(m -> m.getItems().stream())
                .mapToDouble(i -> nz(i.getKcal())).sum();
        int topRounds = topUp(meals, mealBudget);

        // ---- 全天合计（含调味基准）----
        Totals t = totals(meals);

        // ---- 约束核查 + 定点修补（钠 / 脂肪）+ 能量回补 ----
        List<DietPlanVO.Constraint> cons = checkConstraints(diseases, target, t, recFloor);
        int repairs = 0;
        for (int i = 0; i < 4; i++) {
            boolean fixed;
            if (violates(cons, "钠")) {
                fixed = repairNutrient(meals, diseases, candByCat, true);
            } else if (violates(cons, "脂肪供能比")) {
                fixed = repairNutrient(meals, diseases, candByCat, false);
            } else {
                break;
            }
            if (!fixed) {
                break;
            }
            repairs++;
            topUp(meals, mealBudget);
            t = totals(meals);
            cons = checkConstraints(diseases, target, t, recFloor);
        }
        t = totals(meals);
        cons = checkConstraints(diseases, target, t, recFloor);

        // ---- 打分 ----
        double energyDev = Math.abs(t.kcal - target) / (double) target;
        long failed = cons.stream().filter(c -> Boolean.FALSE.equals(c.getPass())).count();
        double violationRate = cons.isEmpty() ? 0 : failed / (double) cons.size();
        double dupRate = dupRate(meals);
        double recRatio = t.items == 0 ? 0 : t.recCount / (double) t.items;
        double recPen = Math.max(0, 0.5 - recRatio) / 0.5;
        double cost = 0.35 * Math.min(1, energyDev / 0.20)
                + 0.35 * violationRate
                + 0.15 * dupRate
                + 0.15 * recPen;
        double score = Math.round(Math.max(0, 100 - cost * 100) * 10) / 10.0;

        // ---- 组装 ----
        DietPlanVO vo = new DietPlanVO();
        vo.setPatientId(patientId);
        vo.setPatientName(patient.getName());
        vo.setTargetKcal(target);
        vo.setDiseaseText(diseases.isEmpty() ? "未登记病种（按通用膳食指南）"
                : diseases.stream().map(d -> DISEASE_NAME.getOrDefault(d, d)).collect(Collectors.joining("、")));
        vo.setMeals(meals);
        vo.setTotals(toMap(t, target));
        vo.setConstraints(cons);
        vo.setViolations(cons.stream().filter(c -> Boolean.FALSE.equals(c.getPass()))
                .map(c -> c.getName() + "：" + c.getActual() + "（要求 " + c.getLimit() + "）")
                .collect(Collectors.toList()));
        vo.setScore(score);
        vo.setAdvice(advice(patientId, diseases, t, target, cons, meals));

        int candSize = candByCat.values().stream().mapToInt(List::size).sum();
        vo.setPool(poolInfo(pool.size(), usable.size(), limited, candSize, t));
        vo.getPool().put("mealBudgetKcal", mealBudget);
        vo.getPool().put("preTopUpKcal", Math.round(preTopUp));
        vo.getPool().put("topUpRounds", topRounds);

        vo.setSolverNote(String.format(
                "清单 %d 条 → 病种剔除 %d 条 → 可选 %d 条 → 每类取前 N 共 %d 条候选；"
                        + "每餐穷举笛卡尔积取最小代价 + 主食份量解析求解；"
                        + "餐次合计 %.0f/%d kcal，能量补齐 %d 轮 → 全天偏差 %.1f%%，"
                        + "约束未通过 %d/%d 项，高钠修补 %d 次；"
                        + "清单判定 推荐 %d / 总量 %d 项，限制 %d 项；调味按 油%d g + 盐%d g 计入",
                pool.size(), limited, usable.size(), candSize,
                preTopUp, mealBudget, topRounds, energyDev * 100, failed, cons.size(), repairs,
                t.recCount, t.items, t.limCount, OIL_G, SALT_G));

        // ---- 落库 ----
        CdDietPlan plan = new CdDietPlan();
        plan.setPatientId(patientId);
        plan.setPlanDate(planDate);
        plan.setTargetKcal(target);
        plan.setDiseaseCodes(String.join(",", diseases));
        plan.setMealsJson(json(meals));
        plan.setTotalsJson(json(vo.getTotals()));
        plan.setConstraintJson(json(cons));
        plan.setScore(BigDecimal.valueOf(score));
        plan.setAdvice(String.join("；", vo.getAdvice()));
        plan.setCreateTime(LocalDateTime.now());
        dietPlanMapper.delete(Wrappers.<CdDietPlan>lambdaQuery()
                .eq(CdDietPlan::getPatientId, patientId).eq(CdDietPlan::getPlanDate, planDate));
        dietPlanMapper.insert(plan);
        vo.setPlanId(plan.getPlanId());
        return vo;
    }

    @Override
    public DietPlanVO latest(Long patientId) {
        CdDietPlan plan = dietPlanMapper.selectOne(Wrappers.<CdDietPlan>lambdaQuery()
                .eq(CdDietPlan::getPatientId, patientId)
                .orderByDesc(CdDietPlan::getCreateTime).last("limit 1"));
        if (plan == null) {
            return recommend(patientId, LocalDate.now(), null);
        }
        DietPlanVO vo = new DietPlanVO();
        vo.setPlanId(plan.getPlanId());
        vo.setPatientId(plan.getPatientId());
        vo.setTargetKcal(plan.getTargetKcal());
        vo.setScore(plan.getScore() == null ? null : plan.getScore().doubleValue());
        vo.setDiseaseText(plan.getDiseaseCodes() == null || plan.getDiseaseCodes().isBlank()
                ? "通用" : Arrays.stream(plan.getDiseaseCodes().split(","))
                .map(d -> DISEASE_NAME.getOrDefault(d, d)).collect(Collectors.joining("、")));
        vo.setSolverNote("（读取 " + plan.getPlanDate() + " 已生成的方案）");
        try {
            vo.setMeals(objectMapper.readValue(plan.getMealsJson(),
                    objectMapper.getTypeFactory().constructCollectionType(List.class, DietPlanVO.Meal.class)));
            vo.setTotals(objectMapper.readValue(plan.getTotalsJson(), Map.class));
            vo.setConstraints(objectMapper.readValue(plan.getConstraintJson(),
                    objectMapper.getTypeFactory().constructCollectionType(List.class, DietPlanVO.Constraint.class)));
        } catch (Exception e) {
            log.warn("膳食方案解析失败，重新生成 planId={}", plan.getPlanId());
            return recommend(patientId, LocalDate.now(), null);
        }
        vo.setViolations(vo.getConstraints().stream().filter(c -> Boolean.FALSE.equals(c.getPass()))
                .map(c -> c.getName() + "：" + c.getActual() + "（要求 " + c.getLimit() + "）")
                .collect(Collectors.toList()));
        CdPatient patient = patientMapper.selectById(patientId);
        vo.setPatientName(patient == null ? null : patient.getName());
        vo.setAdvice(plan.getAdvice() == null || plan.getAdvice().isBlank() ? new ArrayList<>()
                : Arrays.asList(plan.getAdvice().split("；")));
        return vo;
    }

    // =========================================================================
    //  能量目标
    // =========================================================================

    /**
     * 能量目标按性别 + 年龄段取轻体力活动参考值，再按病种微调。
     * 档案无身高体重，无法用 Harris-Benedict 精算，故采用参考摄入量区间内的定值并显式说明。
     */
    private int energyTarget(CdPatient patient, List<String> diseases) {
        int age = patient.getAge() == null ? 60 : patient.getAge();
        boolean male = !"2".equals(patient.getGender());
        int base;
        if (male) {
            base = age < 50 ? 2250 : age < 65 ? 2100 : age < 80 ? 2050 : 1900;
        } else {
            base = age < 50 ? 1800 : age < 65 ? 1750 : age < 80 ? 1700 : 1600;
        }
        // 慢阻肺：呼吸耗能增加、常伴营养不良，能量上调 10%
        if (diseases.contains("4")) {
            base = (int) Math.round(base * 1.10);
        }
        return (int) (Math.round(base / 50.0) * 50);
    }

    // =========================================================================
    //  清单判定
    // =========================================================================

    /** 取该食物在指定病种下的判定（推荐 / 适量 / 限制） */
    private String verdictOf(CdFood f, String code) {
        String v = switch (code) {
            case "1" -> f.getVerdictHtn();
            case "2" -> f.getVerdictDm();
            case "3" -> f.getVerdictChd();
            case "4" -> f.getVerdictCopd();
            default -> null;
        };
        return v == null || v.isBlank() ? "适量" : v;
    }

    private String evidenceOf(CdFood f, String code) {
        String v = switch (code) {
            case "1" -> f.getEvidenceHtn();
            case "2" -> f.getEvidenceDm();
            case "3" -> f.getEvidenceChd();
            case "4" -> f.getEvidenceCopd();
            default -> null;
        };
        return v == null ? "" : v;
    }

    /** 患者多个病种下的"最差判定"：限制 > 适量 > 推荐 */
    private String worstVerdict(CdFood f, List<String> diseases) {
        if (diseases.isEmpty()) {
            return "适量";
        }
        boolean rec = false;
        for (String d : diseases) {
            String v = verdictOf(f, d);
            if ("限制".equals(v)) {
                return "限制";
            }
            if ("推荐".equals(v)) {
                rec = true;
            }
        }
        return rec ? "推荐" : "适量";
    }

    /** 命中最差判定的病种码 */
    private String verdictDisease(CdFood f, List<String> diseases) {
        String worst = worstVerdict(f, diseases);
        for (String d : diseases) {
            if (verdictOf(f, d).equals(worst)) {
                return DISEASE_NAME.getOrDefault(d, d);
            }
        }
        return diseases.isEmpty() ? "通用" : DISEASE_NAME.getOrDefault(diseases.get(0), "通用");
    }

    /** 该食物在患者病种下的依据文本（取最差判定那条，便于界面直接显示） */
    private String verdictBasis(CdFood f, List<String> diseases) {
        String worst = worstVerdict(f, diseases);
        for (String d : diseases) {
            if (verdictOf(f, d).equals(worst)) {
                return DISEASE_NAME.getOrDefault(d, d) + "：" + evidenceOf(f, d);
            }
        }
        return "";
    }

    // =========================================================================
    //  候选排序
    // =========================================================================

    /**
     * 适配度打分：清单判定为主，营养指标按病种加权，最后叠加当日扰动保证多样性。
     */
    private double fit(CdFood f, List<String> diseases, long seed) {
        double s = 0;
        int recNum = 0, cnt = 0;
        for (String d : diseases) {
            String v = verdictOf(f, d);
            cnt++;
            if ("推荐".equals(v)) {
                recNum++;
                s += 1.0;
            }
        }
        if (cnt > 0) {
            s = s / cnt * 3.0;         // 判定权重最高，归一化后最多 +3
        }
        double kcal = val(f.getKcal());
        double protein = val(f.getProtein());
        double fat = val(f.getFat());
        double carb = val(f.getCarb());
        double fiber = val(f.getFiber());
        double sodium = val(f.getSodiumMg());

        if (diseases.contains("1")) {
            s -= sodium / 600.0;                       // 高血压：钠越少越好
            s += val(f.getPotassiumMg()) / 1500.0;     // 高钾有利（清单亦以此为推荐依据）
        }
        if (diseases.contains("2")) {
            s += fiber * 0.15;
            s -= carb * 0.02;
            if (f.getGi() != null && f.getGi() >= 70) {
                s -= 0.6;
            }
        }
        if (diseases.contains("3")) {
            // 冠心病重点是饱和脂肪，不饱和脂肪（鱼、坚果、植物油）不必回避
            s -= val(f.getSatFat()) * 0.06;
            if (f.getName().matches(".*(鱼|核桃|松子|榛子|杏仁).*")) {
                s += 0.4;
            }
        }
        if (diseases.contains("4")) {
            s += Math.min(protein, 22) * 0.05;         // 慢阻肺：高蛋白，但超过 22g/100g 不再加分
            s += Math.min(kcal, 400) / 400.0 * 0.3;    // 与高能量（少量多餐）
        }
        // 生重杂粮/杂豆类蛋白高但能量密度也高，主食里给低 GI 的加分
        if ("主食".equals(f.getCategory()) && f.getGi() != null && f.getGi() > 0 && f.getGi() <= 60) {
            s += 0.3;
        }
        // 膳食纤维对所有病种都有益，给一个通用的小额偏好（否则纤维容易卡在 18 g）
        if (!"蛋白".equals(f.getCategory()) && !"奶类".equals(f.getCategory())) {
            s += fiber * 0.10;
        }
        // 常见家常食材加分 / 内脏加工干制降权
        if (COMMON.matcher(f.getName()).find()) {
            s += 1.2;
        }
        if (PENAL.matcher(f.getName()).find()) {
            s -= 2.0;
        }
        // 当日扰动：同一份数据每天给出不同但可复现的方案
        s += 0.35 * (Math.floorMod(f.getName().hashCode() * 31L + seed, 100) / 100.0);
        return s;
    }

    /** 餐次对主食的偏好：早餐偏馒头面包燕麦粥，正餐别只吃馒头 */
    private double stapleMealBonus(String mealName, CdFood f) {
        if (!"主食".equals(f.getCategory())) {
            return 0;
        }
        String n = f.getName();
        boolean matchesBreakfast = BREAKFAST_STAPLE.matcher(n).find();
        if ("早餐".equals(mealName)) {
            if (matchesBreakfast) {
                return 0.8;
            }
            if (n.matches(".*(豆|年糕|凉粉|热干面|豆皮).*")) {
                return -1.0;
            }
            if (n.matches("^(土豆|山药|芋头|红薯|甘薯).*")) {
                return -0.5;
            }
            return 0;
        }
        // 午晚餐：馒头面包类降权，米面杂粮为主
        return matchesBreakfast ? -0.4 : 0;
    }

    /** 餐次对蛋白的偏好：早餐更适合蛋类与豆制品，畜肉偏正餐 */
    private double proteinMealBonus(String mealName, CdFood f) {
        if (!"蛋白".equals(f.getCategory())) {
            return 0;
        }
        String n = f.getName();
        boolean eggOrSoy = n.matches(".*(鸡蛋|鸭蛋|鹅蛋|鹌鹑蛋|豆浆|豆腐|豆干|腐竹|腐乳|豆花).*");
        boolean redMeat = n.matches(".*(猪|牛|羊|驴|狗|马).*");
        if ("早餐".equals(mealName)) {
            if (eggOrSoy) {
                return 0.8;
            }
            if (redMeat) {
                return -0.8;
            }
        }
        return 0;
    }

    private List<CdFood> pick(List<CdFood> list, List<String> diseases, long seed, int n) {
        return list.stream()
                .sorted(Comparator.comparingDouble((CdFood f) -> fit(f, diseases, seed)).reversed())
                .limit(n)
                .collect(Collectors.toList());
    }

    private List<CdFood> cand(String cat, Map<String, List<CdFood>> cand) {
        return cand.getOrDefault(cat, Collections.emptyList());
    }

    // =========================================================================
    //  逐餐求解
    // =========================================================================

    private DietPlanVO.Meal solve(String name, double share, int budget, List<String> diseases,
                                  List<List<CdFood>> slots, Set<String> used) {
        DietPlanVO.Meal meal = new DietPlanVO.Meal();
        meal.setName(name);
        int mealTarget = (int) Math.round(budget * share);
        meal.setTargetKcal(mealTarget);

        List<List<CdFood>> valid = slots.stream().filter(l -> !l.isEmpty()).collect(Collectors.toList());
        if (valid.isEmpty()) {
            return meal;
        }
        List<List<CdFood>> combos = new ArrayList<>();
        buildCombos(valid, 0, new ArrayList<>(), combos, MAX_COMBOS);

        Sol best = null;
        for (List<CdFood> combo : combos) {
            if (dupNameInMeal(combo)) {
                continue;
            }
            Sol s = evaluate(combo, mealTarget, diseases, used, name);
            if (best == null || s.cost < best.cost) {
                best = s;
            }
        }
        if (best == null) {
            return meal;
        }
        for (int i = 0; i < best.foods.size(); i++) {
            DietPlanVO.Item item = toItem(best.foods.get(i), best.grams[i], diseases);
            meal.getItems().add(item);
            used.add(family(best.foods.get(i)));
        }
        refreshMeal(meal);
        return meal;
    }

    private void buildCombos(List<List<CdFood>> slots, int idx, List<CdFood> cur,
                             List<List<CdFood>> out, int max) {
        if (out.size() >= max) {
            return;
        }
        if (idx == slots.size()) {
            out.add(new ArrayList<>(cur));
            return;
        }
        for (CdFood f : slots.get(idx)) {
            cur.add(f);
            buildCombos(slots, idx + 1, cur, out, max);
            cur.remove(cur.size() - 1);
        }
    }

    private boolean dupNameInMeal(List<CdFood> combo) {
        Set<String> names = new HashSet<>();
        for (CdFood f : combo) {
            if (!names.add(f.getName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 食材族：腐竹/豆腐皮/千张 本质是同一种干货，鱼就是鱼，蛋就是蛋。
     * 跨餐去重按"族"而不是按名字，否则一天三餐都能各自点到腐竹皮的不同写法。
     */
    private String family(CdFood f) {
        String n = f.getName();
        if (n.matches(".*(腐竹|豆腐皮|千张|百页|油豆腐|豆干|豆腐丝|豆腐卷).*")) {
            return "豆制品干货";
        }
        if (n.matches(".*(豆腐|豆花|豆腐脑|豆浆|素鸡|面筋|烤麸).*")) {
            return "豆制品鲜品";
        }
        if (n.matches(".*(鸡蛋|鸭蛋|鹅蛋|鹌鹑蛋|皮蛋|松花蛋).*")) {
            return "蛋类";
        }
        if (n.matches(".*(牛乳|酸奶|奶酪|干酪|奶豆腐|奶皮|炼乳).*")) {
            return "奶类";
        }
        if ("蛋白".equals(f.getCategory())) {
            return "蛋白·" + n.substring(0, Math.min(2, n.length()));
        }
        if ("蔬菜".equals(f.getCategory()) && FUNGI.matcher(n).find()) {
            return "菌藻";
        }
        return n;
    }

    private static class Sol {
        List<CdFood> foods;
        int[] grams;
        double cost;
    }

    /**
     * 单个组合的代价评估。
     * <p>第 0 个槽位是"弹性槽"（主食 / 加餐时的水果或坚果），其份量用解析式解出来；
     * 其余槽位按默认一份固定。</p>
     */
    private Sol evaluate(List<CdFood> combo, int mealTarget, List<String> diseases, Set<String> used,
                         String mealName) {
        int n = combo.size();
        int[] grams = new int[n];
        double fixedKcal = 0, fixedSodium = 0, fixedSat = 0, fixedFat = 0, fixedProtein = 0, fixedCarb = 0;
        for (int i = 1; i < n; i++) {
            CdFood f = combo.get(i);
            grams[i] = serving(f);
            double k = grams[i] / 100.0;
            fixedKcal += val(f.getKcal()) * k;
            fixedSodium += val(f.getSodiumMg()) * k;
            fixedSat += val(f.getSatFat()) * k;
            fixedFat += val(f.getFat()) * k;
            fixedProtein += val(f.getProtein()) * k;
            fixedCarb += val(f.getCarb()) * k;
        }
        CdFood flex = combo.get(0);
        double density = Math.max(1, val(flex.getKcal()));
        int need = (int) Math.round((mealTarget - fixedKcal) / density * 100 / 5.0) * 5;
        grams[0] = Math.max(minGram(flex), Math.min(maxGram(flex), need));

        double k0 = grams[0] / 100.0;
        double kcal = fixedKcal + val(flex.getKcal()) * k0;
        double sodium = fixedSodium + val(flex.getSodiumMg()) * k0;
        double sat = fixedSat + val(flex.getSatFat()) * k0;
        double fat = fixedFat + val(flex.getFat()) * k0;
        double protein = fixedProtein + val(flex.getProtein()) * k0;
        double carb = fixedCarb + val(flex.getCarb()) * k0;

        double cost = Math.abs(kcal - mealTarget) / (double) mealTarget * 2.0;

        // ---- 病种项 ----
        // 单餐钠预算：全日 2000 mg 均摊到 4 餐
        double mealSodiumBudget = 500;
        double sodiumWeight = (diseases.contains("1") || diseases.contains("3")) ? 0.8 : 0.5;
        if (sodium > mealSodiumBudget) {
            cost += (sodium - mealSodiumBudget) / mealSodiumBudget * sodiumWeight;
        }
        if (diseases.contains("2")) {
            // 单餐窗口要比全日 45%~60% 略高：全日还要摊上 25 g 烹调油（零碳水），
            // 单餐 45% 折完全天就只剩 41%，这类"差一点点"全是从这儿来的。
            double cr = carb * 4 / Math.max(1, kcal);
            if (cr < 0.47) {
                cost += (0.47 - cr) * 2.5;
            } else if (cr > 0.63) {
                cost += (cr - 0.63) * 2.5;
            }
        }
        if (diseases.contains("3")) {
            cost += sat * 9 / Math.max(1, kcal) * 1.5;
        }
        if (diseases.contains("4")) {
            cost -= Math.min(0.15, protein / 30.0 * 0.15);
        }

        // ---- 清单判定项：推荐越多越优先 ----
        int rec = 0;
        int fungi = 0;
        double mealBonus = 0;
        for (CdFood f : combo) {
            if ("推荐".equals(worstVerdict(f, diseases))) {
                rec++;
            }
            if ("蔬菜".equals(f.getCategory()) && FUNGI.matcher(f.getName()).find()) {
                fungi++;
            }
            mealBonus += stapleMealBonus(mealName, f) + proteinMealBonus(mealName, f);
        }
        cost -= 0.03 * rec;
        cost -= mealBonus * 0.5;
        if (fungi >= 2) {
            cost += 0.5 * (fungi - 1);      // 一餐两道菌菇不现实
        }

        // ---- 蛋白质不应挤占太多能量（真实膳食 10%~25%）----
        double prCap = diseases.contains("4") ? 0.24 : 0.22;
        double pr = protein * 4 / Math.max(1, kcal);
        if (pr > prCap) {
            cost += (pr - prCap) * 5.0;
        }
        // ---- 脂肪供能比：全日要落在 20%~30%（慢阻肺 35%），扣掉 25g 烹调油后反推单餐上限 ----
        double frCap = diseases.contains("4") ? 0.28 : 0.25;
        double fr = fat * 9 / Math.max(1, kcal);
        if (fr > frCap) {
            cost += (fr - frCap) * 6.0;
        }

        // ---- 跨餐重复 ----
        for (CdFood f : combo) {
            if (used.contains(family(f))) {
                cost += 0.8;
            }
        }

        Sol s = new Sol();
        s.foods = combo;
        s.grams = grams;
        s.cost = cost;
        return s;
    }

    private int serving(CdFood f) {
        return f.getServingG() == null || f.getServingG() <= 0 ? 100 : f.getServingG();
    }

    /** 弹性槽最小份量：主食/水果/坚果可以给得很少，蛋白蔬菜奶类按一份起 */
    private int minGram(CdFood f) {
        String cat = f.getCategory() == null ? "" : f.getCategory();
        return switch (cat) {
            case "主食" -> 40;
            case "水果" -> 60;
            case "坚果" -> 10;
            default -> serving(f);
        };
    }

    private int maxGram(CdFood f) {
        int maxG = f.getMaxG() == null || f.getMaxG() <= 0 ? serving(f) * 2 : f.getMaxG();
        return Math.max(minGram(f), maxG);
    }

    // =========================================================================
    //  能量补齐
    // =========================================================================

    /**
     * 能量补齐：按缺口精确换算克数，而不是盲加 30 g。
     * <p>盲加的问题很直接——燕麦片密度 3.67 kcal/g，缺 15 kcal 也会加 30 g（110 kcal），
     * 直接把早餐从 469 顶到 583。这里改为「缺口 ÷ 能量密度」并按 5 g 取整。</p>
     */
    private int topUp(List<DietPlanVO.Meal> meals, int budget) {
        for (int round = 0; round < 6; round++) {
            double total = meals.stream().flatMap(m -> m.getItems().stream())
                    .mapToDouble(i -> nz(i.getKcal())).sum();
            double gap = budget - total;
            if (gap <= budget * 0.005) {
                return round;
            }
            List<DietPlanVO.Meal> roomy = new ArrayList<>();
            for (DietPlanVO.Meal m : meals) {
                if (m.getItems().isEmpty()) {
                    continue;
                }
                DietPlanVO.Item flex = m.getItems().get(0);
                int maxG = flex.getMaxG() == null ? flex.getServingG() : flex.getMaxG();
                if (flex.getServingG() < maxG) {
                    roomy.add(m);
                }
            }
            if (roomy.isEmpty()) {
                return round;
            }
            double share = gap / roomy.size();
            boolean changed = false;
            for (DietPlanVO.Meal m : roomy) {
                DietPlanVO.Item flex = m.getItems().get(0);
                int maxG = flex.getMaxG() == null ? flex.getServingG() : flex.getMaxG();
                double density = nz(flex.getKcal()) / Math.max(1, flex.getServingG());
                if (density <= 0) {
                    continue;
                }
                int addG = (int) Math.round(share / density / 5.0) * 5;
                addG = Math.min(maxG - flex.getServingG(), Math.max(5, addG));
                if (addG <= 0) {
                    continue;
                }
                scaleItem(flex, flex.getServingG() + addG);
                refreshMeal(m);
                changed = true;
            }
            if (!changed) {
                return round;
            }
        }
        return 6;
    }

    private void scaleItem(DietPlanVO.Item i, int newG) {
        double k = newG / (double) i.getServingG();
        i.setServingG(newG);
        i.setKcal(round(nz(i.getKcal()) * k));
        i.setProtein(round(nz(i.getProtein()) * k));
        i.setCarb(round(nz(i.getCarb()) * k));
        i.setFat(round(nz(i.getFat()) * k));
        i.setSatFat(round(nz(i.getSatFat()) * k));
        i.setSodiumMg(round(nz(i.getSodiumMg()) * k));
        i.setFiber(round(nz(i.getFiber()) * k));
        i.setPotassium(round(nz(i.getPotassium()) * k));
    }

    private void refreshMeal(DietPlanVO.Meal m) {
        m.setKcal((int) Math.round(m.getItems().stream().mapToDouble(i -> nz(i.getKcal())).sum()));
        m.setSodiumMg((int) Math.round(m.getItems().stream().mapToDouble(i -> nz(i.getSodiumMg())).sum()));
    }

    // =========================================================================
    //  合计与约束
    // =========================================================================

    private static class Totals {
        double kcal, protein, fat, satFat, carb, fiber, sodium, potassium;
        int items, recCount, limCount;
    }

    private Totals totals(List<DietPlanVO.Meal> meals) {
        Totals t = new Totals();
        for (DietPlanVO.Meal m : meals) {
            for (DietPlanVO.Item i : m.getItems()) {
                t.kcal += nz(i.getKcal());
                t.protein += nz(i.getProtein());
                t.fat += nz(i.getFat());
                t.satFat += nz(i.getSatFat());
                t.carb += nz(i.getCarb());
                t.fiber += nz(i.getFiber());
                t.sodium += nz(i.getSodiumMg());
                t.potassium += nz(i.getPotassium());
                t.items++;
                if ("推荐".equals(i.getVerdict())) {
                    t.recCount++;
                } else if ("限制".equals(i.getVerdict())) {
                    t.limCount++;
                }
            }
        }
        // 调味基准
        t.kcal += OIL_KCAL;
        t.fat += OIL_FAT;
        t.satFat += OIL_SAT;
        t.sodium += SALT_SODIUM;
        return t;
    }

    private double nz(Double v) {
        return v == null ? 0 : v;
    }

    private Map<String, Object> toMap(Totals t, int target) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("kcal", Math.round(t.kcal));
        m.put("targetKcal", target);
        m.put("proteinG", round(t.protein));
        m.put("fatG", round(t.fat));
        m.put("satFatG", round(t.satFat));
        m.put("carbG", round(t.carb));
        m.put("fiberG", round(t.fiber));
        m.put("sodiumMg", Math.round(t.sodium));
        m.put("potassiumMg", Math.round(t.potassium));
        m.put("carbRatio", t.kcal == 0 ? 0 : round(t.carb * 4 / t.kcal * 100));
        m.put("proteinRatio", t.kcal == 0 ? 0 : round(t.protein * 4 / t.kcal * 100));
        m.put("fatRatio", t.kcal == 0 ? 0 : round(t.fat * 9 / t.kcal * 100));
        m.put("satFatRatio", t.kcal == 0 ? 0 : round(t.satFat * 9 / t.kcal * 100));
        m.put("seasoning", "烹调油 " + OIL_G + " g（" + Math.round(OIL_KCAL) + " kcal） + 食盐 "
                + SALT_G + " g（钠 " + Math.round(SALT_SODIUM) + " mg）");
        return m;
    }

    private List<DietPlanVO.Constraint> checkConstraints(List<String> diseases, int target, Totals t, int recFloor) {
        List<DietPlanVO.Constraint> list = new ArrayList<>();
        int lo = (int) Math.round(target * 0.9), hi = (int) Math.round(target * 1.1);
        list.add(cons("能量", lo + " ~ " + hi + " kcal", Math.round(t.kcal) + " kcal",
                Math.abs(t.kcal - target) <= target * 0.10, "通用"));

        // 限盐对所有慢病人群都成立（WHO/膳食指南 <5 g 盐 ≈ 2000 mg 钠）
        String sodiumWho = diseases.contains("1") && diseases.contains("3") ? "高血压+冠心病"
                : diseases.contains("1") ? "高血压"
                : diseases.contains("3") ? "冠心病" : "通用";
        list.add(cons("钠", "≤ 2000 mg/日（含食盐 " + SALT_G + " g 估算）",
                Math.round(t.sodium) + " mg", t.sodium <= 2000, sodiumWho));
        if (diseases.contains("2")) {
            double cr = t.kcal == 0 ? 0 : t.carb * 4 / t.kcal * 100;
            list.add(cons("碳水供能比", "45% ~ 60%", round(cr) + " %", cr >= 45 && cr <= 60, "2型糖尿病"));
        }
        if (diseases.contains("3")) {
            double sr = t.kcal == 0 ? 0 : t.satFat * 9 / t.kcal * 100;
            list.add(cons("饱和脂肪供能比", "≤ 10%", round(sr) + " %", sr <= 10, "冠心病"));
        }
        if (diseases.contains("4")) {
            list.add(cons("蛋白质", "≥ 75 g/日（约 1.2 g/kg）", round(t.protein) + " g",
                    t.protein >= 75, "慢阻肺"));
        }
        double fr = t.kcal == 0 ? 0 : t.fat * 9 / t.kcal * 100;
        // 慢阻肺放宽到 35%：降低碳水负荷、提高脂肪比例有助于减少 CO2 潴留，
        // 这也是清单「糖类≥75g 且蛋白<10g 判限制」背后的同一个逻辑。
        double fatCap = diseases.contains("4") ? 35 : 30;
        list.add(cons("脂肪供能比", "20% ~ " + Math.round(fatCap) + "%",
                round(fr) + " %", fr >= 20 && fr <= fatCap, "通用"));
        list.add(cons("膳食纤维", "≥ 20 g/日（指南理想 25~30 g）", round(t.fiber) + " g",
                t.fiber >= 20, "通用"));

        double recRatio = t.items == 0 ? 0 : t.recCount * 100.0 / t.items;
        list.add(cons("清单判定", "限制 0 项，推荐 ≥ " + recFloor + "%（按病种池折算）",
                "限制 " + t.limCount + " 项，推荐 " + t.recCount + "/" + t.items + " 项（" + Math.round(recRatio) + "%）",
                t.limCount == 0 && recRatio >= recFloor, "通用"));
        return list;
    }

    private DietPlanVO.Constraint cons(String name, String limit, String actual, boolean pass, String disease) {
        DietPlanVO.Constraint c = new DietPlanVO.Constraint();
        c.setName(name);
        c.setLimit(limit);
        c.setActual(actual);
        c.setPass(pass);
        c.setDisease(disease);
        return c;
    }

    private boolean violates(List<DietPlanVO.Constraint> cons, String name) {
        return cons.stream().anyMatch(c -> c.getName().contains(name) && Boolean.FALSE.equals(c.getPass()));
    }

    /**
     * 定点修补：把某个"最差项"换成同类别里更符合目标的方向。
     * <p>bySodium=true 修钠，false 修脂肪。只换非弹性槽（第 0 位是主食，换掉会破坏能量解）。</p>
     */
    private boolean repairNutrient(List<DietPlanVO.Meal> meals, List<String> diseases,
                                   Map<String, List<CdFood>> cand, boolean bySodium) {
        DietPlanVO.Item worst = null;
        DietPlanVO.Meal worstMeal = null;
        for (DietPlanVO.Meal m : meals) {
            for (int i = 1; i < m.getItems().size(); i++) {
                DietPlanVO.Item it = m.getItems().get(i);
                double v = bySodium ? nz(it.getSodiumMg()) : nz(it.getFat());
                double cur = worst == null ? -1 : (bySodium ? nz(worst.getSodiumMg()) : nz(worst.getFat()));
                if (v > cur) {
                    worst = it;
                    worstMeal = m;
                }
            }
        }
        if (worst == null) {
            return false;
        }
        double worstVal = bySodium ? nz(worst.getSodiumMg()) : nz(worst.getFat());
        if (worstVal < (bySodium ? 120 : 6)) {
            return false;
        }
        Set<String> usedAll = meals.stream().flatMap(m -> m.getItems().stream())
                .map(DietPlanVO.Item::getName).collect(Collectors.toSet());
        double worstDensity = nz(worst.getKcal()) / Math.max(1, worst.getServingG()) * 100;
        CdFood best = null;
        double bestScore = Double.MAX_VALUE;
        for (CdFood c : cand.getOrDefault(worst.getCategory(), Collections.emptyList())) {
            if (usedAll.contains(c.getName()) || "限制".equals(worstVerdict(c, diseases))) {
                continue;
            }
            double v = bySodium ? val(c.getSodiumMg()) : val(c.getFat());
            if (v >= worstVal) {
                continue;
            }
            // 主判据：目标营养更低；次判据：能量密度接近（避免换完能量大幅漂移）
            double score = v / Math.max(1, worstVal) * 10 + Math.abs(val(c.getKcal()) - worstDensity) / 100.0;
            if (score < bestScore) {
                bestScore = score;
                best = c;
            }
        }
        if (best == null) {
            return false;
        }
        DietPlanVO.Item ni = toItem(best, serving(best), diseases);
        worstMeal.getItems().remove(worst);
        worstMeal.getItems().add(ni);
        refreshMeal(worstMeal);
        return true;
    }

    // =========================================================================
    //  提示
    // =========================================================================

    private List<String> advice(Long patientId, List<String> diseases, Totals t, int target,
                                List<DietPlanVO.Constraint> cons, List<DietPlanVO.Meal> meals) {
        List<String> out = new ArrayList<>();
        out.add("能量目标 " + target + " kcal（按性别年龄段轻体力活动参考值"
                + (diseases.contains("4") ? "，慢阻肺已上调 10%" : "") + "），"
                + "其中烹调油 " + OIL_G + " g、食盐 " + SALT_G + " g 已单独计入，剩余 "
                + (5 - SALT_G) + " g 盐额度留给你调味");
        if (diseases.contains("1")) {
            out.add("限盐：全天钠 ≤ 2000 mg（食盐 < 5 g），少用酱油与腌制品");
        }
        if (diseases.contains("2")) {
            out.add("主食选低升糖（GI ≤ 55），定时定量；进食顺序先菜后肉再主食");
        }
        if (diseases.contains("3")) {
            out.add("少油少煎炸，控制饱和脂肪，优先鱼类与豆制品");
        }
        if (diseases.contains("4")) {
            out.add("少量多餐、提高蛋白质比例，餐后避免腹胀影响呼吸");
        }
        boolean hasBean = meals.stream().flatMap(m -> m.getItems().stream())
                .anyMatch(i -> i.getTags() != null && i.getTags().contains("产气注意"));
        if (hasBean && diseases.contains("4")) {
            out.add("方案含豆类（产气），慢阻肺腹胀明显时替换为等量蛋类或瘦肉");
        }
        if (t.fiber < 25) {
            out.add("膳食纤维 " + round(t.fiber) + " g，未达指南理想值 25 g，可再加 100 g 绿叶菜或换杂粮主食");
        }

        // ---- 个体化：结合档案里的饮食习惯 ----
        CdPatientProfile profile = profileMapper.selectOne(Wrappers.<CdPatientProfile>lambdaQuery()
                .eq(CdPatientProfile::getPatientId, patientId).last("limit 1"));
        String habit = profile == null ? null : profile.getDietHabit();
        if (habit != null && !habit.isBlank()) {
            if (habit.matches(".*(咸|腌|酱|盐|腊|熏).*")) {
                out.add("档案记录你口味偏咸（" + brief(habit) + "）：腌菜酱货本期已全部规避，"
                        + "建议用葱姜蒜、花椒、醋提味替代酱油");
            }
            if (habit.matches(".*(油炸|油条|肥肉|红烧|煎炸).*")) {
                out.add("档案提到常吃油炸/红烧类：本期烹调油已控到 " + OIL_G + " g，"
                        + "建议改为蒸、煮、炖、白灼");
            }
            if (habit.matches(".*(酒|饮).*")) {
                out.add("档案提到饮酒：高血压与冠心病均建议戒酒，至少降到每周 ≤ 2 次、每次 ≤ 1 两");
            }
            if (habit.matches(".*(精米|白面|主食).*")) {
                out.add("档案显示主食以精米白面为主：可把 1/3 换成燕麦、荞麦或杂豆饭");
            }
        }
        cons.stream().filter(c -> Boolean.FALSE.equals(c.getPass()))
                .forEach(c -> out.add("⚠ " + c.getName() + " 未达标：" + c.getActual() + "，要求 " + c.getLimit()));
        return out;
    }

    private String brief(String s) {
        String x = s.replaceAll("[；;].*", "").trim();
        return x.length() > 40 ? x.substring(0, 40) + "…" : x;
    }

    private Map<String, Object> poolInfo(int total, int usable, int limited, int candSize, Totals t) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("libraryTotal", total);
        m.put("libraryUsable", usable);
        m.put("excludedByVerdict", limited);
        m.put("candidates", candSize);
        m.put("planItems", t.items);
        m.put("recommended", t.recCount);
        m.put("limited", t.limCount);
        m.put("source", "四种慢病饮食推荐与限制清单.xlsx / 全量食物营养分析");
        return m;
    }

    // =========================================================================
    //  工具
    // =========================================================================

    private DietPlanVO.Item toItem(CdFood f, int grams, List<String> diseases) {
        double k = grams / 100.0;
        DietPlanVO.Item i = new DietPlanVO.Item();
        i.setName(f.getName());
        i.setCategory(f.getCategory());
        i.setServingG(grams);
        i.setMaxG(maxGram(f));
        i.setKcal(round(val(f.getKcal()) * k));
        i.setProtein(round(val(f.getProtein()) * k));
        i.setCarb(round(val(f.getCarb()) * k));
        i.setFat(round(val(f.getFat()) * k));
        i.setSatFat(round(val(f.getSatFat()) * k));
        i.setSodiumMg(round(val(f.getSodiumMg()) * k));
        i.setFiber(round(val(f.getFiber()) * k));
        i.setPotassium(round(val(f.getPotassiumMg()) * k));
        i.setGi(f.getGi());
        i.setTags(f.getTags());
        i.setVerdict(worstVerdict(f, diseases));
        i.setVerdictDisease(verdictDisease(f, diseases));
        i.setVerdictBasis(verdictBasis(f, diseases));
        return i;
    }

    private double dupRate(List<DietPlanVO.Meal> meals) {
        long distinct = meals.stream().flatMap(m -> m.getItems().stream())
                .map(DietPlanVO.Item::getName).distinct().count();
        long total = meals.stream().mapToLong(m -> m.getItems().size()).sum();
        return total == 0 ? 0 : 1 - distinct / (double) total;
    }

    private double val(BigDecimal b) {
        return b == null ? 0 : b.doubleValue();
    }

    private double round(double v) {
        return BigDecimal.valueOf(v).setScale(1, RoundingMode.HALF_UP).doubleValue();
    }

    private String json(Object o) {
        try {
            return objectMapper.writeValueAsString(o);
        } catch (Exception e) {
            return "[]";
        }
    }
}
