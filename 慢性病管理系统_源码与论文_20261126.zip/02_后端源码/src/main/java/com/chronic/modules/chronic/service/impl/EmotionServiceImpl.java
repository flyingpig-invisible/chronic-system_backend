package com.chronic.modules.chronic.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.chronic.modules.chronic.entity.*;
import com.chronic.modules.chronic.mapper.*;
import com.chronic.modules.chronic.service.EmotionService;
import com.chronic.modules.chronic.vo.EmotionResultVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 算法四：多模态情绪感知实现
 * <p>
 * <b>三个模态</b>
 * <ol>
 *   <li>文本：对话文本 + 档案「情绪状态」描述。情绪词典 + 否定词 + 程度副词，得分越高越负面。</li>
 *   <li>生理：近 7 天指标异常占比、未处理预警的最高级别与条数——身体不舒服本身就会推高情绪风险。</li>
 *   <li>行为：近 7 天漏服/迟服率、监测覆盖天数——依从性下滑常是情绪问题的早期信号。</li>
 * </ol>
 * <b>融合</b>：文本 0.45 / 生理 0.30 / 行为 0.25；某模态缺数据时按比例分摊权重，
 * 避免「没测数据」被误判成「情绪平稳」。
 *
 * @author chronic
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmotionServiceImpl implements EmotionService {

    private final CdPatientMapper patientMapper;
    private final CdPatientProfileMapper profileMapper;
    private final CdMeasureMapper measureMapper;
    private final CdWarningMapper warningMapper;
    private final CdRemindLogMapper remindLogMapper;
    private final CdEmotionLogMapper emotionLogMapper;

    /** 情绪词典：词 -> 严重度（1~5），负值为积极词 */
    private static final Map<String, Integer> LEXICON = new LinkedHashMap<>();

    static {
        // 轻中度
        LEXICON.put("担心", 2);
        LEXICON.put("紧张", 2);
        LEXICON.put("焦虑", 3);
        LEXICON.put("睡不好", 2);
        LEXICON.put("失眠", 2);
        LEXICON.put("心慌", 2);
        LEXICON.put("烦躁", 2);
        LEXICON.put("压力大", 2);
        LEXICON.put("不安", 2);
        LEXICON.put("累", 2);
        LEXICON.put("疲惫", 2);
        LEXICON.put("心情不好", 3);
        LEXICON.put("情绪低落", 3);
        // 睡眠与社交回避：抑郁筛查的常见条目，患者通常用口语表述
        LEXICON.put("睡不着", 2);
        LEXICON.put("不想说话", 2);
        LEXICON.put("不想动", 2);
        // 中重度
        LEXICON.put("害怕", 3);
        LEXICON.put("恐慌", 4);
        LEXICON.put("提不起劲", 3);
        LEXICON.put("没意思", 3);
        LEXICON.put("无助", 4);
        LEXICON.put("胸闷", 3);
        LEXICON.put("气短", 2);
        LEXICON.put("撑不住", 4);
        // 高风险
        LEXICON.put("绝望", 5);
        LEXICON.put("不想活", 5);
        LEXICON.put("活着没意思", 5);
        LEXICON.put("没希望", 5);
        LEXICON.put("崩溃", 5);
        // 积极
        LEXICON.put("好多了", -3);
        LEXICON.put("感谢", -2);
        LEXICON.put("有信心", -3);
        LEXICON.put("坚持", -2);
        LEXICON.put("舒服", -2);
        LEXICON.put("稳定", -2);
        LEXICON.put("开心", -2);
        LEXICON.put("不错", -1);
        LEXICON.put("轻松", -2);
        // 日常口语里的轻度正向表述
        LEXICON.put("还行", -1);
        LEXICON.put("挺好", -2);
        LEXICON.put("有精神", -2);
        LEXICON.put("睡得着", -2);
        LEXICON.put("散步", -1);
    }

    private static final List<String> NEGATIONS = List.of("不", "没有", "没", "无", "别", "并不");
    private static final List<String> INTENSIFIERS = List.of("很", "非常", "特别", "太", "极", "十分", "越来越");

    @Override
    public EmotionResultVO analyze(Long patientId, String text, String source) {
        CdPatient patient = patientMapper.selectById(patientId);
        if (patient == null) {
            throw new com.chronic.common.exception.ServiceException("患者不存在");
        }

        EmotionResultVO vo = new EmotionResultVO();
        vo.setPatientId(patientId);
        vo.setPatientName(patient.getName());

        // ---------- 模态一：文本 ----------
        // 当下的表达优先于档案里的历史情绪：档案中的「焦虑、累」是长期背景，
        // 若与本次文本直接拼接，会把「今天状态还行」也判成明显负面，故按 7:3 融合。
        String moodText = null;
        CdPatientProfile profile = profileMapper.selectOne(Wrappers.<CdPatientProfile>lambdaQuery()
                .eq(CdPatientProfile::getPatientId, patientId).last("limit 1"));
        if (profile != null && StringUtils.hasText(profile.getMoodStatus())) {
            moodText = profile.getMoodStatus();
        }
        String combined = text;
        if (moodText != null) {
            combined = (StringUtils.hasText(combined) ? combined + "。" : "") + moodText;
        }

        TextPart tpNow = analyzeText(text);
        TextPart tpMood = analyzeText(moodText);
        TextPart tp;
        if (tpNow.available && tpMood.available) {
            tp = new TextPart();
            tp.available = true;
            tp.score = (int) Math.round(tpNow.score * 0.7 + tpMood.score * 0.3);
            tp.label = labelOf(tp.score);
            tp.hits = tpNow.hits.isEmpty() ? tpMood.hits : tpNow.hits;
        } else if (tpNow.available) {
            tp = tpNow;
        } else {
            tp = tpMood;
        }
        vo.setTextScore(tp.score);
        vo.setTextLabel(tp.label);
        vo.setTextHits(tp.hits);

        // ---------- 模态二：生理 ----------
        PhysioPart pp = analyzePhysio(patientId);
        vo.setPhysioScore(pp.score);
        vo.setPhysioNote(pp.note);

        // ---------- 模态三：行为 ----------
        BehaviorPart bp = analyzeBehavior(patientId);
        vo.setBehaviorScore(bp.score);
        vo.setBehaviorNote(bp.note);

        // ---------- 融合 ----------
        double wt = tp.available ? 0.45 : 0;
        double wp = pp.available ? 0.30 : 0;
        double wb = bp.available ? 0.25 : 0;
        if (wt + wp + wb == 0) {
            // 三个模态都没有数据：给出中性结果，不冒充「平稳」
            vo.setFusedScore(50);
            vo.setLevel("CARE");
            vo.setLevelName("需关注");
            vo.setWeights("无可用模态");
            vo.setAdvice("近 7 天既没有监测数据，也没有对话记录，建议联系患者核实近况。");
            vo.setNeedDoctorAttention(true);
            return save(vo, patientId, combined, source);
        }
        double sum = wt + wp + wb;
        double fused = (wt * nz(tp.score) + wp * nz(pp.score) + wb * nz(bp.score)) / sum;
        int score = (int) Math.round(Math.min(100, Math.max(0, fused)));
        vo.setFusedScore(score);
        vo.setWeights(String.format("文本 %.2f / 生理 %.2f / 行为 %.2f", wt / sum, wp / sum, wb / sum));

        if (score < 35) {
            vo.setLevel("CALM");
            vo.setLevelName("平稳");
        } else if (score <= 65) {
            vo.setLevel("CARE");
            vo.setLevelName("需关注");
        } else {
            vo.setLevel("WARN");
            vo.setLevelName("预警");
        }
        vo.setNeedDoctorAttention(score > 65);
        vo.setAdvice(buildAdvice(vo, tp, pp, bp));
        return save(vo, patientId, combined, source);
    }

    private double nz(Integer v) {
        return v == null ? 0 : v;
    }

    // ============================================================
    //  文本模态
    // ============================================================

    private static class TextPart {
        boolean available;
        int score;
        String label;
        List<String> hits = new ArrayList<>();
    }

    private TextPart analyzeText(String text) {
        TextPart p = new TextPart();
        if (!StringUtils.hasText(text)) {
            p.available = false;
            p.label = "无文本";
            return p;
        }
        p.available = true;
        int base = 15;
        int acc = 0;
        List<String> hits = new ArrayList<>();
        for (Map.Entry<String, Integer> e : LEXICON.entrySet()) {
            String word = e.getKey();
            int idx = text.indexOf(word);
            if (idx < 0) {
                continue;
            }
            double w = e.getValue();
            // 程度副词加强
            String before = text.substring(Math.max(0, idx - 4), idx);
            for (String it : INTENSIFIERS) {
                if (before.contains(it)) {
                    w *= 1.5;
                    break;
                }
            }
            // 否定词削弱（"不担心" 不等于 "担心"）
            String near = text.substring(Math.max(0, idx - 3), idx);
            for (String ng : NEGATIONS) {
                if (near.endsWith(ng)) {
                    w *= 0.3;
                    break;
                }
            }
            acc += (int) Math.round(w * 8);
            hits.add(word + "(" + (w > 0 ? "+" : "") + String.format("%.1f", w) + ")");
        }
        p.score = Math.min(100, Math.max(0, base + acc));
        p.hits = hits;
        p.label = labelOf(p.score);
        return p;
    }

    /** 文本分 → 标签 */
    private String labelOf(int score) {
        if (score < 25) {
            return "平稳";
        } else if (score < 50) {
            return "轻度负面";
        } else if (score < 75) {
            return "明显负面";
        }
        return "高风险表述";
    }

    // ============================================================
    //  生理模态
    // ============================================================

    private static class PhysioPart {
        boolean available;
        int score;
        String note;
    }

    private PhysioPart analyzePhysio(Long patientId) {
        PhysioPart p = new PhysioPart();
        LocalDateTime from = LocalDateTime.now().minusDays(7);
        List<CdMeasure> measures = measureMapper.selectList(Wrappers.<CdMeasure>lambdaQuery()
                .eq(CdMeasure::getPatientId, patientId)
                .ge(CdMeasure::getMeasureTime, from));
        List<CdWarning> warnings = warningMapper.selectList(Wrappers.<CdWarning>lambdaQuery()
                .eq(CdWarning::getPatientId, patientId)
                .eq(CdWarning::getHandleStatus, "0")
                .ge(CdWarning::getTriggerTime, from));

        if (measures.isEmpty() && warnings.isEmpty()) {
            p.available = false;
            p.note = "近 7 天无监测数据";
            return p;
        }
        p.available = true;
        long abnormal = measures.stream().filter(m -> "1".equals(m.getAbnormalFlag())).count();
        double ratio = measures.isEmpty() ? 0 : (double) abnormal / measures.size();
        int maxLevel = warnings.stream().mapToInt(w -> parseInt(w.getWarningLevel())).max().orElse(0);

        int score = (int) Math.round(40 * ratio);
        score += maxLevel >= 3 ? 35 : (maxLevel == 2 ? 20 : 0);
        score += Math.min(15, warnings.size() * 3);
        p.score = Math.min(100, score);
        p.note = String.format("近 7 天监测 %d 条，异常 %d 条（%.0f%%）；未处理预警 %d 条，最高 %s",
                measures.size(), abnormal, ratio * 100, warnings.size(),
                maxLevel == 0 ? "无" : (maxLevel == 3 ? "高危" : maxLevel == 2 ? "中危" : "低危"));
        return p;
    }

    // ============================================================
    //  行为模态
    // ============================================================

    private static class BehaviorPart {
        boolean available;
        int score;
        String note;
    }

    private BehaviorPart analyzeBehavior(Long patientId) {
        BehaviorPart p = new BehaviorPart();
        LocalDate fromDate = LocalDate.now().minusDays(7);
        List<CdRemindLog> logs = remindLogMapper.selectList(Wrappers.<CdRemindLog>lambdaQuery()
                .eq(CdRemindLog::getPatientId, patientId)
                .ge(CdRemindLog::getPlanDate, fromDate));
        List<CdMeasure> measures = measureMapper.selectList(Wrappers.<CdMeasure>lambdaQuery()
                .eq(CdMeasure::getPatientId, patientId)
                .ge(CdMeasure::getMeasureTime, fromDate.atStartOfDay()));

        Set<LocalDate> days = measures.stream()
                .map(m -> m.getMeasureTime() == null ? null : m.getMeasureTime().toLocalDate())
                .filter(Objects::nonNull).collect(Collectors.toSet());
        double coverage = Math.min(1.0, days.size() / 7.0);

        if (logs.isEmpty() && measures.isEmpty()) {
            p.available = false;
            p.note = "近 7 天无打卡与监测记录";
            return p;
        }
        p.available = true;
        long missed = logs.stream().filter(l -> "2".equals(l.getCheckStatus())).count();
        long late = logs.stream().filter(l -> "3".equals(l.getCheckStatus())).count();
        double total = logs.size();
        double missRate = total == 0 ? 0 : missed / total;

        int score = (int) Math.round(60 * missRate + 40 * (1 - coverage));
        // 迟服只算一半严重度
        if (total > 0) {
            score = (int) Math.round(Math.min(100, score + 10.0 * late / total));
        }
        p.score = Math.min(100, Math.max(0, score));
        p.note = String.format("近 7 天用药打卡 %d 次（漏服 %d、迟服 %d），监测覆盖 %d/7 天",
                logs.size(), missed, late, days.size());
        return p;
    }

    // ============================================================
    //  建议与落库
    // ============================================================

    private String buildAdvice(EmotionResultVO vo, TextPart tp, PhysioPart pp, BehaviorPart bp) {
        List<String> parts = new ArrayList<>();
        String lv = vo.getLevel();
        if ("WARN".equals(lv)) {
            parts.add("情绪风险较高，建议 24 小时内主动联系患者，必要时转介心理支持或专科门诊");
        } else if ("CARE".equals(lv)) {
            parts.add("情绪状态需关注，建议下次随访时主动询问睡眠、情绪与家庭支持情况");
        } else {
            parts.add("情绪状态平稳，保持当前随访节奏即可");
        }
        if (tp.available && tp.score >= 50) {
            parts.add("对话中检测到「" + String.join("、", tp.hits) + "」等表述，建议先安抚再谈指标");
        }
        if (pp.available && pp.score >= 50) {
            parts.add("近期指标波动明显，情绪低落可能与身体不适互为因果，建议先控制症状");
        }
        if (bp.available && bp.score >= 50) {
            parts.add("用药打卡与监测出现缺口，建议核实是否有经济、认知或情绪方面的原因");
        }
        return String.join("；", parts) + "。";
    }

    private EmotionResultVO save(EmotionResultVO vo, Long patientId, String text, String source) {
        CdEmotionLog log = new CdEmotionLog();
        log.setPatientId(patientId);
        log.setSource(source == null ? "MANUAL" : source);
        log.setTextContent(text == null ? null : (text.length() > 480 ? text.substring(0, 480) : text));
        log.setTextScore(vo.getTextScore());
        log.setTextLabel(vo.getTextLabel());
        log.setTextHits(vo.getTextHits() == null ? null : String.join(",", vo.getTextHits()));
        log.setPhysioScore(vo.getPhysioScore());
        log.setPhysioNote(vo.getPhysioNote());
        log.setBehaviorScore(vo.getBehaviorScore());
        log.setBehaviorNote(vo.getBehaviorNote());
        log.setFusedScore(vo.getFusedScore());
        log.setEmotionLevel(vo.getLevel());
        log.setAdvice(vo.getAdvice());
        log.setCreateTime(LocalDateTime.now());
        emotionLogMapper.insert(log);
        vo.setLogId(log.getLogId());
        return vo;
    }

    @Override
    public List<CdEmotionLog> recent(Long patientId, int limit) {
        return emotionLogMapper.selectList(Wrappers.<CdEmotionLog>lambdaQuery()
                .eq(CdEmotionLog::getPatientId, patientId)
                .orderByDesc(CdEmotionLog::getCreateTime)
                .last("limit " + Math.max(1, Math.min(limit, 50))));
    }

    private int parseInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            return 0;
        }
    }
}
