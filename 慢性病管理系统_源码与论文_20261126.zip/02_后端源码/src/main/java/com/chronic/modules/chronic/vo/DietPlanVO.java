package com.chronic.modules.chronic.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 膳食推荐结果（算法五：病种感知的约束优化）
 *
 * @author chronic
 */
@Data
@Schema(description = "膳食推荐结果")
public class DietPlanVO {

    private Long planId;
    private Long patientId;
    private String patientName;

    @Schema(description = "能量目标 kcal")
    private Integer targetKcal;

    @Schema(description = "参与约束的病种")
    private String diseaseText;

    @Schema(description = "方案得分 0-100")
    private Double score;

    private List<Meal> meals = new ArrayList<>();

    @Schema(description = "全天营养合计")
    private Map<String, Object> totals = new LinkedHashMap<>();

    @Schema(description = "每条约束的满足情况")
    private List<Constraint> constraints = new ArrayList<>();

    @Schema(description = "超标/未达标说明")
    private List<String> violations = new ArrayList<>();

    @Schema(description = "个体化提示")
    private List<String> advice = new ArrayList<>();

    @Schema(description = "求解说明（迭代次数与最终偏差）")
    private String solverNote;

    @Schema(description = "候选池与判定统计")
    private Map<String, Object> pool = new LinkedHashMap<>();

    @Data
    public static class Meal {
        private String name;
        private Integer targetKcal;
        private Integer kcal;
        private Integer sodiumMg;
        private List<Item> items = new ArrayList<>();
    }

    @Data
    public static class Item {
        private String name;
        private String category;
        private Integer servingG;
        private Integer maxG;
        private Double kcal;
        private Double protein;
        private Double carb;
        private Double fat;
        private Double satFat;
        private Double sodiumMg;
        private Double fiber;
        private Double potassium;
        private Integer gi;
        private String tags;
        @Schema(description = "本患者病种下最差判定：推荐/适量/限制")
        private String verdict;
        @Schema(description = "判定依据（来自清单原文）")
        private String verdictBasis;
        @Schema(description = "命中的病种，如 高血压")
        private String verdictDisease;
    }

    @Data
    public static class Constraint {
        private String name;
        private String limit;
        private String actual;
        private Boolean pass;
        private String disease;
    }
}
