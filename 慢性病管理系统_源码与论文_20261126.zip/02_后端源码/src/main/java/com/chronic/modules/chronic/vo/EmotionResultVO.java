package com.chronic.modules.chronic.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * 情绪感知结果（算法四）
 *
 * @author chronic
 */
@Data
@Schema(description = "情绪感知结果")
public class EmotionResultVO {

    private Long patientId;

    private String patientName;

    @Schema(description = "融合风险分 0-100，越大越负面")
    private Integer fusedScore;

    @Schema(description = "CALM 平稳 / CARE 需关注 / WARN 预警")
    private String level;

    private String levelName;

    // ---------- 文本模态 ----------
    private Integer textScore;
    private String textLabel;
    private List<String> textHits = new ArrayList<>();

    // ---------- 生理模态 ----------
    private Integer physioScore;
    private String physioNote;

    // ---------- 行为模态 ----------
    private Integer behaviorScore;
    private String behaviorNote;

    @Schema(description = "各模态权重（缺模态时按比例重分配）")
    private String weights;

    private String advice;

    @Schema(description = "是否需要医生介入")
    private Boolean needDoctorAttention;

    private Long logId;
}
