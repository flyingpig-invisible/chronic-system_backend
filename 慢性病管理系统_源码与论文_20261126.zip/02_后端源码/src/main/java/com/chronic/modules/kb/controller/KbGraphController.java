package com.chronic.modules.kb.controller;

import com.chronic.common.result.Result;
import com.chronic.modules.kb.service.impl.GraphRagService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * GraphRAG 知识图谱（算法三）
 * <p>
 * 与普通检索的区别：返回的是「实体—关系→实体」的路径，每条边都能追到指南文档与章节。
 *
 * @author chronic
 */
@Tag(name = "27-知识图谱检索（GraphRAG）", description = "实体链接 + 多跳扩展，结果可追溯到指南章节")
@RestController
@RequestMapping("/chronic/kb/graph")
@RequiredArgsConstructor
public class KbGraphController {

    private final GraphRagService graphRagService;

    @Operation(summary = "图谱检索：返回命中实体、跳数、三元组与来源")
    @PreAuthorize("@ss.hasPermi('chronic:ai:list')")
    @GetMapping("/search")
    public Result<GraphRagService.GraphResult> search(@RequestParam(required = false) String diseaseCode,
                                                      @RequestParam(required = false) String question,
                                                      @RequestParam(required = false, defaultValue = "12") Integer topK) {
        List<String> codes = codes(diseaseCode);
        return Result.success(graphRagService.retrieve(codes, question, topK == null ? 12 : topK));
    }

    @Operation(summary = "图谱概况：三元组总数、按病种与来源分布")
    @PreAuthorize("@ss.hasPermi('chronic:ai:list')")
    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        List<com.chronic.modules.kb.entity.KbTriple> all = graphRagService.allTriples();
        Map<String, Integer> byDisease = new LinkedHashMap<>();
        Map<String, Integer> byOrigin = new LinkedHashMap<>();
        for (com.chronic.modules.kb.entity.KbTriple t : all) {
            String d = GraphRagService.DISEASE_NAME.getOrDefault(
                    t.getDiseaseCode() == null ? "0" : t.getDiseaseCode(), "其他");
            byDisease.merge(d, 1, Integer::sum);
            byOrigin.merge(t.getOrigin() == null ? "SEED" : t.getOrigin(), 1, Integer::sum);
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("total", all.size());
        m.put("byDisease", byDisease);
        m.put("byOrigin", byOrigin);
        return Result.success(m);
    }

    @Operation(summary = "图谱全部三元组（演示台铺图用，最多 300 条）")
    @PreAuthorize("@ss.hasPermi('chronic:ai:list')")
    @GetMapping("/all")
    public Result<List<com.chronic.modules.kb.entity.KbTriple>> all() {
        List<com.chronic.modules.kb.entity.KbTriple> all = graphRagService.allTriples();
        return Result.success(all.size() > 300 ? all.subList(0, 300) : all);
    }

    @Operation(summary = "从指南正文重新抽取三元组（幂等，已存在的不重复插入）")
    @PreAuthorize("@ss.hasPermi('chronic:kb:edit')")
    @PostMapping("/rebuild")
    public Result<Map<String, Object>> rebuild() {
        int added = graphRagService.rebuildAuto();
        return Result.success(Map.of("added", added, "total", graphRagService.count()));
    }

    private List<String> codes(String diseaseCode) {
        return diseaseCode == null || diseaseCode.isBlank()
                ? Collections.emptyList() : Arrays.asList(diseaseCode.split(","));
    }
}
