package com.chronic.modules.kb.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * GraphRAG 三元组（指南知识图谱的一条边）
 *
 * @author chronic
 */
@Data
@TableName("kb_triple")
@Schema(description = "知识图谱三元组")
public class KbTriple implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long tripleId;

    @Schema(description = "头实体")
    private String headEntity;

    @Schema(description = "关系")
    private String relation;

    @Schema(description = "尾实体")
    private String tailEntity;

    @Schema(description = "病种：1高血压 2糖尿病 3冠心病 4慢阻肺 0通用")
    private String diseaseCode;

    @Schema(description = "来源文档ID")
    private Long docId;

    @Schema(description = "来源文档标题")
    private String sourceTitle;

    @Schema(description = "来源章节")
    private String sourceSection;

    @Schema(description = "来源类型：SEED 人工整理 / AUTO 规则抽取")
    private String origin;

    private BigDecimal weight;

    private LocalDateTime createTime;
}
