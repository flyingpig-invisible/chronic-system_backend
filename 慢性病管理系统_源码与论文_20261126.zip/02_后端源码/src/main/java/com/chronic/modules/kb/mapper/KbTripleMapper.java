package com.chronic.modules.kb.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chronic.modules.kb.entity.KbTriple;
import org.apache.ibatis.annotations.Mapper;

/**
 * 知识图谱三元组 Mapper
 *
 * @author chronic
 */
@Mapper
public interface KbTripleMapper extends BaseMapper<KbTriple> {
}
