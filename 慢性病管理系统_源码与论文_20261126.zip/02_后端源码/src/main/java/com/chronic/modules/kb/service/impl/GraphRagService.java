package com.chronic.modules.kb.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.chronic.modules.kb.entity.KbDocument;
import com.chronic.modules.kb.entity.KbTriple;
import com.chronic.modules.kb.mapper.KbDocumentMapper;
import com.chronic.modules.kb.mapper.KbTripleMapper;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * GraphRAG 检索服务
 * <p>
 * 与关键词检索的区别：先在「实体」上做链接，再沿三元组多跳扩展，
 * 命中的每条边都带来源文档与章节，因此答案可以追溯到指南的具体位置。
 *
 * @author chronic
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class GraphRagService {

    private final KbTripleMapper tripleMapper;
    private final KbDocumentMapper documentMapper;

    /** 最多扩展跳数 */
    private static final int MAX_HOPS = 2;
    /** 单次检索最多带回的三元组条数 */
    private static final int MAX_TRIPLES = 12;

    public static final Map<String, String> DISEASE_NAME = Map.of(
            "1", "高血压", "2", "2型糖尿病", "3", "冠心病", "4", "慢阻肺", "0", "通用");

    /** 实体别名：口语/指标名 → 图谱里的标准实体 */
    private static final Map<String, String> ALIAS = new LinkedHashMap<>();

    /** 关系词：问题里的说法 → 图谱里的关系名 */
    private static final Map<String, String> REL_WORDS = new LinkedHashMap<>();

    static {
        ALIAS.put("高血压", "高血压");
        ALIAS.put("血压", "高血压");
        ALIAS.put("降压", "高血压");
        ALIAS.put("收缩压", "高血压");
        ALIAS.put("舒张压", "高血压");
        ALIAS.put("限盐", "高血压");
        ALIAS.put("盐", "高血压");

        ALIAS.put("糖尿病", "2型糖尿病");
        ALIAS.put("血糖", "2型糖尿病");
        ALIAS.put("降糖", "2型糖尿病");
        ALIAS.put("糖化", "2型糖尿病");
        ALIAS.put("低血糖", "2型糖尿病");

        ALIAS.put("冠心病", "冠心病");
        ALIAS.put("心绞痛", "冠心病");
        ALIAS.put("心梗", "冠心病");
        ALIAS.put("心肌梗死", "冠心病");
        ALIAS.put("胸痛", "冠心病");
        ALIAS.put("心脏", "冠心病");

        ALIAS.put("慢阻肺", "慢阻肺");
        ALIAS.put("copd", "慢阻肺");
        ALIAS.put("肺功能", "慢阻肺");
        ALIAS.put("呼吸困难", "慢阻肺");
        ALIAS.put("喘", "慢阻肺");

        REL_WORDS.put("目标", "目标");
        REL_WORDS.put("多少", "目标");
        REL_WORDS.put("控制到", "目标");
        REL_WORDS.put("降到", "目标");
        REL_WORDS.put("盐", "限钠");
        REL_WORDS.put("钠", "限钠");
        REL_WORDS.put("吃", "推荐");
        REL_WORDS.put("饮食", "推荐");
        REL_WORDS.put("忌口", "限制");
        REL_WORDS.put("不能", "限制");
        REL_WORDS.put("运动", "运动");
        REL_WORDS.put("锻炼", "运动");
        REL_WORDS.put("急救", "急救");
        REL_WORDS.put("急诊", "急救");
        REL_WORDS.put("120", "急救");
        REL_WORDS.put("戒烟", "戒烟");
        REL_WORDS.put("抽烟", "戒烟");
        REL_WORDS.put("疫苗", "疫苗");
        REL_WORDS.put("诊断", "诊断标准");
        REL_WORDS.put("标准", "诊断标准");
        REL_WORDS.put("营养", "营养");
        REL_WORDS.put("蛋白", "营养");
    }

    /** 检索命中的一条边 */
    @Data
    public static class TripleHit {
        private Long tripleId;
        private String head;
        private String relation;
        private String tail;
        private String diseaseCode;
        private String sourceTitle;
        private String sourceSection;
        private String origin;
        /** 第几跳命中：0 = 实体直接命中，1/2 = 图扩展 */
        private Integer hop;
        private Double score;

        /** 给模型看的可追溯写法 */
        public String cite() {
            String sec = StringUtils.hasText(sourceSection) ? " · " + sourceSection : "";
            return String.format("【T%d】%s —%s→ %s（来源：%s%s）",
                    tripleId == null ? 0 : tripleId, head, relation, tail,
                    sourceTitle == null ? "知识库" : sourceTitle, sec);
        }
    }

    /** 一次检索的完整结果，供接口与演示台展示 */
    @Data
    public static class GraphResult {
        private List<String> linkedEntities = new ArrayList<>();
        private List<TripleHit> hits = new ArrayList<>();
        private String context;
        private Integer totalTriples;
        private Integer hop1;
        private Integer hop2;
    }

    /** 全量三元组（数据量小，直接内存计算，避免逐跳查库） */
    public List<KbTriple> allTriples() {
        return tripleMapper.selectList(Wrappers.<KbTriple>lambdaQuery()
                .orderByDesc(KbTriple::getWeight));
    }

    public int count() {
        Long n = tripleMapper.selectCount(Wrappers.<KbTriple>lambdaQuery());
        return n == null ? 0 : n.intValue();
    }

    /**
     * 实体链接 + 多跳扩展。
     *
     * @param diseaseCodes 当前患者确诊病种，可为空
     * @param question     医生/患者问题
     * @param topK         返回条数
     */
    public GraphResult retrieve(List<String> diseaseCodes, String question, int topK) {
        GraphResult result = new GraphResult();
        List<KbTriple> all = allTriples();
        result.setTotalTriples(all.size());
        if (all.isEmpty() || !StringUtils.hasText(question)) {
            result.setContext("");
            result.setHits(new ArrayList<>());
            result.setHop1(0);
            result.setHop2(0);
            return result;
        }

        Set<String> diseaseSet = diseaseCodes == null ? Collections.emptySet() : new HashSet<>(diseaseCodes);
        String q = question.toLowerCase(Locale.ROOT);

        // ---------- 第 0 跳：实体链接 ----------
        // 三路命中：①问题里出现实体别名（血压→高血压）②出现实体原词 ③出现尾实体片段或关键数值
        Set<String> seedEntities = new LinkedHashSet<>();
        for (Map.Entry<String, String> e : ALIAS.entrySet()) {
            if (q.contains(e.getKey())) {
                seedEntities.add(e.getValue());
            }
        }
        Set<String> relPrefs = new LinkedHashSet<>();
        for (Map.Entry<String, String> e : REL_WORDS.entrySet()) {
            if (q.contains(e.getKey())) {
                relPrefs.add(e.getValue());
            }
        }

        Map<Long, TripleHit> scored = new LinkedHashMap<>();
        Set<String> entities = new LinkedHashSet<>();
        for (KbTriple t : all) {
            boolean headHit = hit(q, t.getHeadEntity()) || seedEntities.contains(t.getHeadEntity());
            // 「问什么答什么」：问题里显式点到的病种实体，即使患者未确诊也放行；
            // 只有依赖尾实体/关系词间接命中的才按患者病种收窄，避免把无关病种全部拉进来。
            if (!headHit && !diseaseAllowed(t, diseaseSet)) {
                continue;
            }
            boolean tailHit = anyPhraseHit(q, t.getTailEntity());
            boolean relHit = relPrefs.stream().anyMatch(r -> contains(t.getRelation(), r));
            if (!headHit && !tailHit && !relHit) {
                continue;
            }
            double s = 0;
            if (headHit) {
                s += 3.0;
            }
            if (tailHit) {
                s += 1.6;
            }
            if (relHit) {
                s += 1.2;
            }
            TripleHit h = toHit(t, 0);
            h.setScore(s + weight(t) + diseaseBonus(t, diseaseSet));
            scored.put(t.getTripleId(), h);
            // 只有头实体真的被命中才算"链接到的实体"；尾实体片段命中不算，
            // 否则「吃盐有什么限制」会把「家庭血压监测」也列成链接实体
            if (headHit) {
                entities.add(t.getHeadEntity());
            }
        }
        result.setLinkedEntities(new ArrayList<>(entities));

        // ---------- 第 1~2 跳：沿实体扩展 ----------
        Set<String> frontier = new HashSet<>(entities);
        // 病种桥梁：图谱里存在「冠心病 —危险因素→ 高血压…」这类跨病种边，
        // 把尾实体中出现的其它病种也当作实体加入前沿，下一跳才能取回该病种的条款。
        // 例如冠心病患者问「血压要控制到多少」，可经由「危险因素」取回高血压的降压目标。
        Set<String> bridgeDiseases = new LinkedHashSet<>();
        for (TripleHit h : scored.values()) {
            if (!StringUtils.hasText(h.getTail())) {
                continue;
            }
            for (Map.Entry<String, String> e : DISEASE_NAME.entrySet()) {
                String name = e.getValue();
                if ("通用".equals(name) || name.equals(h.getHead())) {
                    continue;
                }
                if (h.getTail().contains(name)) {
                    bridgeDiseases.add(e.getKey());
                }
            }
        }
        frontier.addAll(bridgeDiseases.stream().map(DISEASE_NAME::get).collect(Collectors.toSet()));
        // 桥梁病种的三元组在扩展阶段要放行，否则会被病种过滤挡掉
        Set<String> expandSet = new HashSet<>(diseaseSet);
        expandSet.addAll(bridgeDiseases);

        int hop1 = 0, hop2 = 0;
        for (int hop = 1; hop <= MAX_HOPS && !frontier.isEmpty(); hop++) {
            Set<String> next = new LinkedHashSet<>();
            for (KbTriple t : all) {
                if (scored.containsKey(t.getTripleId()) || !diseaseAllowed(t, expandSet)) {
                    continue;
                }
                boolean linked = frontier.contains(t.getHeadEntity()) || frontier.contains(t.getTailEntity());
                if (!linked) {
                    continue;
                }
                TripleHit h = toHit(t, hop);
                h.setScore(2.6 / (hop + 1) + weight(t) + diseaseBonus(t, diseaseSet));
                scored.put(t.getTripleId(), h);
                next.add(t.getHeadEntity());
                if (hop == 1) {
                    hop1++;
                } else {
                    hop2++;
                }
            }
            frontier = next;
        }

        List<TripleHit> hits = new ArrayList<>(scored.values());
        hits.sort(Comparator.comparingDouble((TripleHit h) -> h.getScore() == null ? 0 : h.getScore()).reversed());
        int limit = Math.min(topK <= 0 ? MAX_TRIPLES : topK, hits.size());
        hits = new ArrayList<>(hits.subList(0, limit));

        result.setHits(hits);
        result.setHop1(hop1);
        result.setHop2(hop2);
        result.setContext(buildContext(hits));
        return result;
    }

    /** 只要文本摘要，用于拼提示词 */
    public String buildContext(List<String> diseaseCodes, String question) {
        GraphResult r = retrieve(diseaseCodes, question, MAX_TRIPLES);
        return r.getContext();
    }

    public int countHits(List<String> diseaseCodes, String question) {
        return retrieve(diseaseCodes, question, MAX_TRIPLES).getHits().size();
    }

    private String buildContext(List<TripleHit> hits) {
        if (hits.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("以下是本次回答依据的指南知识图谱（三元组，均已标注来源，引用时请保留来源章节）：\n");
        for (TripleHit h : hits) {
            sb.append("- ").append(h.cite()).append('\n');
        }
        return sb.toString();
    }

    private TripleHit toHit(KbTriple t, int hop) {
        TripleHit h = new TripleHit();
        h.setTripleId(t.getTripleId());
        h.setHead(t.getHeadEntity());
        h.setRelation(t.getRelation());
        h.setTail(t.getTailEntity());
        h.setDiseaseCode(t.getDiseaseCode());
        h.setSourceTitle(t.getSourceTitle());
        h.setSourceSection(t.getSourceSection());
        h.setOrigin(t.getOrigin());
        h.setHop(hop);
        return h;
    }

    private double weight(KbTriple t) {
        if (t.getWeight() == null) {
            return 0.5;
        }
        return t.getWeight().doubleValue();
    }

    private double diseaseBonus(KbTriple t, Set<String> diseaseSet) {
        if (diseaseSet.isEmpty() || t.getDiseaseCode() == null) {
            return 0;
        }
        return diseaseSet.contains(t.getDiseaseCode()) ? 0.8 : 0;
    }

    private boolean diseaseAllowed(KbTriple t, Set<String> diseaseSet) {
        // 通用知识（0）始终允许；否则只在患者相关病种内检索
        if (diseaseSet.isEmpty()) {
            return true;
        }
        return "0".equals(t.getDiseaseCode()) || t.getDiseaseCode() == null
                || diseaseSet.contains(t.getDiseaseCode());
    }

    private boolean hit(String q, String text) {
        if (!StringUtils.hasText(text) || text.length() < 2) {
            return false;
        }
        return q.contains(text.toLowerCase(Locale.ROOT));
    }

    /** 关系词匹配：问题里的说法与图谱关系名互相包含即可 */
    private boolean contains(String relation, String pref) {
        if (relation == null || pref == null) {
            return false;
        }
        return relation.contains(pref) || pref.contains(relation);
    }

    /** 尾实体常是一长串（如「每日食盐<5g，减少酱油…」），按标点拆开后任一片段命中即可 */
    private boolean anyPhraseHit(String q, String tail) {
        if (!StringUtils.hasText(tail)) {
            return false;
        }
        for (String p : tail.split("[，,、；;。：:/（）()]")) {
            String s = p.trim();
            if (s.length() >= 3 && q.contains(s.toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        // 关键数值型命中：问题里出现「140/90」这类数字
        Matcher m = Pattern.compile("\\d{2,3}/\\d{2,3}").matcher(tail);
        while (m.find()) {
            if (q.contains(m.group())) {
                return true;
            }
        }
        return false;
    }

    // ============================================================
    //  自动抽取：从指南正文补三元组（origin=AUTO，权重低于人工整理）
    // ============================================================

    private static final Pattern P_TARGET = Pattern.compile("(?:目标为|降至|控制(?:在|于))([＜<≤]?\\s*\\d+(?:\\.\\d+)?(?:/\\d+)?\\s*(?:mmHg|mmol/L|kg/m²|次/分|%))");
    private static final Pattern P_LIMIT = Pattern.compile("(?:限制|避免|减少|禁忌|禁用)([^。；;]{2,40})");
    private static final Pattern P_RECOMMEND = Pattern.compile("(?:优先选择|推荐|建议)([^。；;]{2,40})");
    private static final Pattern P_SODIUM = Pattern.compile("(?:食盐|钠盐)[^。；;]{0,12}?([＜<≤]\\s*\\d+(?:\\.\\d+)?\\s*g)");

    /**
     * 重建自动三元组：按文档正文的表述规律抽取，已存在的不重复插入。
     *
     * @return 新增条数
     */
    public int rebuildAuto() {
        List<KbDocument> docs = documentMapper.selectList(Wrappers.<KbDocument>lambdaQuery()
                .eq(KbDocument::getStatus, "1"));
        int added = 0;
        for (KbDocument doc : docs) {
            if (!StringUtils.hasText(doc.getContent())) {
                continue;
            }
            String subject = DISEASE_NAME.getOrDefault(doc.getDiseaseCode(), "慢病管理");
            for (String sentence : doc.getContent().split("[。；;\\n]")) {
                String s = sentence.trim();
                if (s.length() < 6) {
                    continue;
                }
                added += tryAdd(subject, "目标", firstGroup(P_TARGET, s), doc);
                added += tryAdd(subject, "限制", firstGroup(P_LIMIT, s), doc);
                added += tryAdd(subject, "推荐", firstGroup(P_RECOMMEND, s), doc);
                added += tryAdd(subject, "限钠", firstGroup(P_SODIUM, s), doc);
            }
        }
        log.info("知识图谱自动抽取完成，新增 {} 条", added);
        return added;
    }

    private String firstGroup(Pattern p, String s) {
        Matcher m = p.matcher(s);
        return m.find() ? m.group(1).trim() : null;
    }

    private int tryAdd(String subject, String relation, String tail, KbDocument doc) {
        if (!StringUtils.hasText(tail) || tail.length() < 2 || tail.length() > 120) {
            return 0;
        }
        Long exists = tripleMapper.selectCount(Wrappers.<KbTriple>lambdaQuery()
                .eq(KbTriple::getHeadEntity, subject)
                .eq(KbTriple::getRelation, relation)
                .eq(KbTriple::getTailEntity, tail));
        if (exists != null && exists > 0) {
            return 0;
        }
        KbTriple t = new KbTriple();
        t.setHeadEntity(subject);
        t.setRelation(relation);
        t.setTailEntity(tail);
        t.setDiseaseCode(doc.getDiseaseCode());
        t.setDocId(doc.getDocId());
        t.setSourceTitle(doc.getTitle());
        t.setSourceSection(doc.getSourceLocation());
        t.setOrigin("AUTO");
        t.setWeight(new BigDecimal("0.60"));
        t.setCreateTime(LocalDateTime.now());
        try {
            tripleMapper.insert(t);
            return 1;
        } catch (Exception e) {
            // 唯一键冲突说明已存在，忽略
            return 0;
        }
    }
}
