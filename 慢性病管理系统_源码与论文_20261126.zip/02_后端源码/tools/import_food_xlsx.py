# -*- coding: utf-8 -*-
"""
算法五数据底座：把《四种慢病饮食推荐与限制清单(1).xlsx》的「全量食物营养分析」
（1725 条 × 每 100g 营养 + 四病种判定 + 判定依据）导入 cd_food。

设计要点
--------
1. 营养值与判定结论逐字照搬源表，不做任何"美化"，保证可回溯。
2. 四病种判定列（推荐 / 适量 / 限制）与依据文本一并入库。算法五直接读判定，
   不再自己造阈值——阈值逻辑已经写在源表的依据文本里。
3. 源表是"食材表"，没有餐次分类。这里按名称规则推断 category；
   凡不适合进配餐的（酒、调味、纯油脂、糖、生粮粉、糕点零食）标 status='0'，
   仍留在库里可查，只是不参与配餐组合。
4. 主食池只收"熟制/可直接入口"形态，避免生米 346kcal 与米饭 117kcal 混在一个池里
   导致份量失真；生粮粉单独归"其他"。
5. max_g：单项每餐上限，按能量密度反推（约 350kcal 一道菜），再加类别物理上限。
6. 饱和脂肪源表没有，按类别/名称系数估算写入 sat_fat。
7. GI 源表没有，仅对常见主食给经验值，其余 0 = 未收录。

用法：python import_food_xlsx.py [--dry]
"""
import re
import sys

import openpyxl

XLSX = r"D:/weixin_data/xwechat_files/wxid_6ua3gamosw9n22_ab80/msg/file/2026-09/四种慢病饮食推荐与限制清单(1).xlsx"
SHEET = "全量食物营养分析"

DB = dict(host="127.0.0.1", port=3306, user="root", password="123456",
          database="chronic_db", charset="utf8mb4")

SOURCE = "四种慢病饮食推荐与限制清单(1).xlsx/全量食物营养分析"

# ---------------------------------------------------------------------------
# 1. 完全匹配即剔除（单字/易混的调料、香辛料、药食同源）
# ---------------------------------------------------------------------------
EXACT_DROP = {
    "姜", "姜(干)", "姜(精)", "盐", "盐(土盐)", "味精", "醋", "水芥", "水疙瘩",
    "八角", "大料", "花椒", "五香粉", "胡椒粉", "辣椒粉", "辣椒糊", "芥末",
    "肉桂", "肉豆蔻", "砂仁", "甘草", "陈皮", "茯苓", "枸杞", "红花", "菊花",
    "人参", "天麻", "白芷", "薄荷", "藿香", "高良姜", "小茴香", "茴香(籽)",
    "茴香籽", "丁香", "胡麻", "薏米", "意米", "莱菔子", "枳实", "郁李仁",
    "桃仁", "杏仁(苦)", "茶汤", "茶水",
}

# ---------------------------------------------------------------------------
# 2. 主食白名单：只收熟制或可直接入口的形态（生米 / 生面粉 / 干粉一律不进池）
# ---------------------------------------------------------------------------
STAPLE_ALLOW = {
    "米饭(蒸,粳米)", "米饭(蒸,籼米)", "米粥(粳米)", "小米粥",
    "馒头(蒸,标准粉)", "馒头(蒸,富强粉)", "花卷", "烙饼(标准粉)", "烧饼",
    "面条(煮,富强粉)", "年糕", "面包", "煎饼", "热干面", "三鲜豆皮", "凉粉",
    "甘薯(白心)", "红薯", "土豆", "山药", "芋头", "玉米(鲜)",
    "稞麦(熟品)（糌粑）",
    # 干重杂粮 / 杂豆：按生重计，单餐 50~100g，属膳食指南常规表述
    "燕麦片", "荞麦", "小米", "黄米", "高粱米", "大黄米（黍）",
    "黑米（稻米(紫)）", "血糯米（糯米(紫红)）",
    "赤豆", "绿豆", "红小豆", "芸豆(白)", "芸豆(红)", "蚕豆", "豌豆(干)",
}

# 收成"主食"类别但不进池（生粮、生粉、糕点）
STAPLE_LIKE = r"稻米|大米|糯米|粳米|籼米|高粱|糜子|青稞|荞麦|燕麦|莜麦|小麦|大麦|面粉|标准粉|富强粉|精粉|玉米面|绿豆面|甘薯粉|土豆粉|米粉|挂面|粉丝|粉条|粉皮|藕粉|淀粉|饼干|蛋糕|糕点|月饼|酥|麻花|江米条|焦圈|面窝|驴打滚|豌豆黄|碗糕|金糕|蜜三刀|开口笑|麻团|炸糕|春卷|馄饨|饺子|包子|汤包|烧麦|粽子|元宵|汤圆|年糕|糌粑|锅巴|馕|糕"

# ---------------------------------------------------------------------------
# 3. 名称规则（顺序短路）
# ---------------------------------------------------------------------------
RULES = [
    # ---- 3.1 酒类 / 饮料 / 茶 / 冷饮：不参与配餐 ----
    (r"啤酒|白酒|黄酒|葡萄酒|大曲|二曲|特曲|头曲|香槟|酒酿|江米酒|蜜酒|善酿|酒|"
     r"青稞酒|糯香酒|汉酒|小麦酒|精制小麦酒|三粮|五酿|景泰|宁河|酒泉|楚天|"
     r"五星啤酒|武汉啤酒|秦海|美雪|麦饭石|维尔康|喜得乐|喜乐|可乐|汽水|"
     r"橙珍|桔子饮料|鲜桔晶|橘子晶|沙棘果汁|甘蔗汁|红果汁|橘汁|柠檬汁|果汁|"
     r"杏仁露|茶水|茶汤|茶叶|咖啡|冰棍|雪糕|冰淇淋|冰砖|棒冰|胶姆|泡泡糖|果冻",
     "其他"),
    # ---- 3.2 纯糖 ----
    (r"白砂糖|绵白糖|^白糖$|红糖|冰糖|砂糖|水晶糖|彩球糖|棉花糖|酸三色糖|"
     r"马蹄软糖|鲜桃果汁糖|奶糖|酥糖|麻糖|糖耳朵|芝麻南糖|^糖$", "其他"),
    # ---- 3.3 调味酱料 / 腌渍 / 发酵调味 ----
    (r"酱油|^醋|醋\(|大酱|黄酱|甜面酱|豆瓣酱|辣酱|辣椒酱|辣椒油|番茄酱|苹果酱|"
     r"桃酱|果酱|草莓酱|花生酱|芝麻酱|虾脑酱|酱汁|^酱|腐乳|冬菜|榨菜|酸菜|"
     r"腌雪里蕻|雪里蕻\(腌\)|芥菜\(酸\)|芥菜头\(腌|韭菜花\(腌\)|蒜头\(糖\)|"
     r"蒜头\(酱\)|萝卜\(酱\)|萝卜条\(辣\)|萝卜干|黄瓜\(酱\)|黄瓜\(甜辣\)|"
     r"菜瓜\(酱\)|甜萝卜|脆萝卜|八宝菜|合锦菜|什锦菜|酱包瓜|酱瓜|酱黄瓜|"
     r"甘露\(酱\)|大头菜|莴笋\(酱\)|苤蓝丝\(酱\)|龙须菜\(腌制\)|蕨菜\(腌\)|"
     r"咸菜|酱豆腐|豆腐乳|味精|鸡精|酵母|碱|明矾|卤",
     "调味"),
    # ---- 3.4 纯油脂 ----
    (r"油$|^猪油|^牛油|^羊油|^黄油|^大油|^豆油|^菜籽油|^菜子油|^花生油|"
     r"^葵花籽油|^玉米油|^棉籽油|^棕榈油|^色拉油|^香油|^胡麻油|^米糠油|^茶油|"
     r"^辣椒油|^鸭油|^混合油|^白脱|^奶油|黄油渣|板油", "油脂"),
    # ---- 3.5 糕点零食 / 甜点（含糖油面，不进配餐）----
    (r"饼干|蛋糕|糕点|月饼|薄脆|酥$|酥\)|桃酥|麻花|江米条|焦圈|面窝|驴打滚|"
     r"豌豆黄|碗糕|金糕|蜜三刀|三刀蜜|开口笑|麻团|炸糕|春卷|馄饨|饺子|"
     r"汤包|烧麦|粽子|元宵|汤圆|锅巴|蜜麻花|糖耳朵|果丹皮|果脯|海棠脯|"
     r"杏脯|苹果脯|南瓜果脯|青梅果脯|西瓜脯|桃酱|果料酸奶|雪糕", "其他"),
    # ---- 3.6 豆制品（必须早于"蔬菜/调味"，否则 酱油干、菜干会跑偏）----
    (r"^豆腐|^豆干|^腐竹|^千张|^百页|^素鸡|^面筋|^烤麸|^豆浆|^豆奶|^豆花|"
     r"^豆腐脑|豆制品", "蛋白"),
    # ---- 3.7 豆芽 / 豆苗（早于主食，否则 绿豆芽 被"绿豆"吃掉）----
    (r"豆芽|豆苗|豌豆苗", "蔬菜"),
    # ---- 3.8 奶类 ----
    (r"牛乳|羊乳|人乳|母乳|奶粉|乳粉|酸奶|奶酪|干酪|奶酷|炼乳|奶皮|奶豆腐|"
     r"奶疙瘩|奶片|酸酪蛋|奶渣", "奶类"),
    # ---- 3.9 坚果 / 籽实 ----
    (r"核桃|胡桃|花生|落花生|长生果|瓜子|葵花子|西瓜子|南瓜子|松子|榛子|榧|"
     r"杏仁|白果|银杏|莲子|芝麻|栗子|板粟|腰果|开心果|夏威夷果|鲍鱼果", "坚果"),
    # ---- 3.10 水果（先精确例外，再关键词）----
    (r"^(白金瓜|白兰瓜|蛤蜜瓜|黄河蜜瓜|灵蜜瓜|甘露|菜瓜)$", "水果"),
    (r"苹果|梨|桃|杏|李|梅|樱桃|葡萄|草莓|蓝莓|猕猴桃|中华猕猴桃|枣|柑|桔|橘|"
     r"橙|柚|柠檬|香蕉|芭蕉|牙蕉|板蕉|菠萝|凤梨|芒果|木瓜|西瓜|甜瓜|香瓜|"
     r"蜜瓜|哈密瓜|石榴|柿|枇杷|荔枝|龙眼|桂圆|杨梅|桑葚|无花果|罗汉果|沙棘|"
     r"山楂|红果|山里红|金桔|金枣|黄皮|番石榴|番桃|椰子|橄榄|油甘子|余甘子|"
     r"酸枣|软枣|乌梅|人参果|杨桃|羊桃|赖葡萄|吊蛋|鸡矢果|望果|抹猛果|五眼果|"
     r"西番莲|百香果", "水果"),
    # ---- 3.11 蔬菜（含菌藻、鲜豆、瓜茄、块茎）----
    (r"菜|菠菜|油菜|芹菜|韭菜|葱|蒜|茄|椒|萝卜|胡萝卜|冬瓜|南瓜|黄瓜|丝瓜|苦瓜|"
     r"佛手瓜|西葫芦|蛇瓜|生瓜|白瓜|毛瓜|节瓜|方瓜|金瓜|笋瓜|越瓜|葫芦|瓠|长瓜|"
     r"棒瓜|茶瓜|笋|芦笋|莴苣|莴笋|生菜|香菜|芫荽|茼蒿|空心菜|苋菜|芥蓝|雪里蕻|"
     r"塌棵菜|苤蓝|甘蓝|卷心菜|圆白菜|西兰花|绿菜花|菜花|番茄|西红柿|番柿|豆角|"
     r"豇豆|四季豆|扁豆|毛豆|荷兰豆|龙豆|刀豆|蛇豆|玉豆|羊角豆|木耳|云耳|香菇|香蕈|"
     r"蘑|菇|菌|侧耳|银耳|紫菜|海带|昆布|发菜|石花菜|琼脂|苔菜|冻菜|莼菜|西洋菜|"
     r"豆瓣菜|水田芥|藕|荸荠|茭白|菱角|百合|洋葱|葱头|香椿|马兰|蕨菜|地衣|金针|"
     r"黄花菜|仙人掌|辣根|根达菜|苦苦菜|苦菜|荠菜|荞菜|马齿苋|蕹菜", "蔬菜"),
    # ---- 3.12 蛋白（畜 / 禽 / 水产 / 蛋 / 内脏 / 加工肉）----
    (r"猪|牛|羊|鸡|鸭|鹅|兔|驴|狗|马肉|蛇|鸽|鹌鹑|青蛙|田鸡|蛹|蝎|"
     r"鱼|鲩|鲢|鲂|鳊|鳙|鲈|鲑|鳟|鲳|鲅|鲐|鲍|鲨|鳐|鲻|鲷|鳕|鳗|鳝|鲇|鲶|鲤|鲫|"
     r"鲮|鳜|鳢|鲋|鲦|鲥|鲱|鳓|鲚|鲹|鲆|鲽|鳎|鲀|虾|蟹|贝|蛤|蚝|蚬|蛏|蚌|螺|鱿|"
     r"墨鱼|章鱼|海参|海蜇|淡菜|干贝|肉|肝|心|肺|肾|肚|肠|蹄|膀|骨|血|蛋|猪耳|牛耳|羊耳|豆干|"
     r"腐竹|千张|百页|素鸡|面筋|烤麸|小肚|灌肠|叉烧|腊|火腿|培根|午餐肉|方腿|"
     r"圆腿|肉松|肉干|肉脯|肫|胰|脑|舌|尾|筋|掌|翅|爪|排骨|里脊|肘|五花|"
     r"肋条|脖|颈|腩|口条", "蛋白"),
]

# 分类后仍需剔除（代餐粉、婴儿食品、饲料、下脚料）
DROP_AFTER = r"健儿粉|婴儿|乳儿糕|营养乳儿糕|婴宝|宝宝福|神力宝|智力菇|多维奶粉|高蛋白豆米粉|钙质糕粉|干粮|豆粕|豆渣|豆腐渣|麸皮|米糠|饲料|母乳化"

CAT_SERVING = {"主食": 100, "蛋白": 100, "蔬菜": 150, "水果": 150, "奶类": 250, "坚果": 15}
CAT_MAX_G = {"主食": 400, "蛋白": 180, "蔬菜": 350, "水果": 300, "奶类": 300, "坚果": 40}

# 常见主食 GI 经验值（源表未收录 GI）
GI_HINT = {
    "米饭(蒸,粳米)": 83, "米饭(蒸,籼米)": 82, "米粥(粳米)": 69, "小米粥": 61,
    "馒头(蒸,标准粉)": 88, "馒头(蒸,富强粉)": 88, "花卷": 85, "烙饼(标准粉)": 80,
    "烧饼": 82, "面条(煮,富强粉)": 82, "通心粉": 65, "年糕": 87, "面包": 88,
    "玉米(鲜)": 55, "甘薯(白心)": 77, "红薯": 77, "土豆": 62, "山药": 51,
    "芋头": 48, "燕麦片": 55, "荞麦": 54, "小米": 71, "黄米": 71, "高粱米": 70,
    "黑米（稻米(紫)）": 55, "赤豆": 26, "绿豆": 27, "红小豆": 26, "芸豆(白)": 27,
    "芸豆(红)": 27, "蚕豆": 35, "豌豆(干)": 32, "凉粉": 30, "大黄米（黍）": 71,
    "血糯米（糯米(紫红)）": 87,
}

SAT_COEF = {"主食": 0.25, "蔬菜": 0.20, "水果": 0.20, "奶类": 0.62,
            "坚果": 0.13, "油脂": 0.10, "蛋白": 0.30, "调味": 0.30, "其他": 0.30}

# 名称里带肉/鱼/蛋字样但其实不是菜的零食、生粉、药膳半成品
JUNK = {
    "全料蒸肉粉", "肉香饼", "空心果", "栗羊羹", "蛋麻脆", "鹅油卷", "脑豆",
    "豆肝尖", "鸡头米", "牛楔乙只", "面包(法式牛角)", "面包(法式配餐)",
    "面条(虾蓉面)", "通心粉", "菠萝豆", "巧克力豆奶", "面蛋",
}

# 干货 / 脱水 / 罐头：源表按每 100 g 干重给值，若按"一份蔬菜 150 g"配餐会把
# 纤维与蛋白放大 5~10 倍（如 松蘑 纤维 47.8 g/100g）。这类一律不进配餐池。
DRY_PAT = r"\(干\)|（干）|干$|干\)|干）|脱水|干品"
HIGH_KCAL_VEG = 150      # 蔬菜鲜品能量密度上限，超过即为干货
HIGH_FIBER_VEG = 12      # 蔬菜鲜品纤维上限，超过即为干货
HIGH_KCAL_FRUIT = 150    # 水果鲜品能量密度上限，超过即为果干

# 调味类"蔬菜"：按 150 g 当一道菜配餐不现实（150 g 干辣椒 / 150 g 大蒜），降级为仅入库
AROMATIC = {
    "大葱(鲜)", "小葱", "红皮葱", "蒜", "大蒜", "大蒜(紫皮)", "大蒜(脱水)",
    "青蒜", "蒜黄", "香菜", "芫荽", "芫荽(脱水)", "辣椒(红小)", "咸沙葱",
}

# 薯类能量密度低，按 350 kcal 反推会得到 400 g 土豆，物理上不现实，单独压到 250 g
TUBER = r"^(土豆|山药|芋头|红薯|甘薯|凉粉)"

# 面制品/米制品：主食形态，但不在白名单里就只入库不配餐
PASTRY_HEAD = r"^面包|^面条|^挂面|^通心粉|^米粉|^年糕|^馒头|^花卷|^烧饼|^烙饼|^煎饼|^稻米|^大米|^糯米|^江米"


def classify(name):
    """返回 (category, selectable)。selectable=False 表示只入库、不参与配餐。"""
    n = str(name).strip()
    if n in EXACT_DROP or n in JUNK:
        return "其他", False
    if n in STAPLE_ALLOW:
        return "主食", True
    if re.search(PASTRY_HEAD, n):
        return "主食", False
    for pat, cat in RULES:
        if re.search(pat, n):
            if re.search(DROP_AFTER, n):
                return cat, False
            if cat in ("其他", "调味", "油脂"):
                return cat, False
            return cat, True
    # 兜底：像主食但不在白名单里的（生粮 / 生粉 / 糕点）
    if re.search(STAPLE_LIKE, n):
        return "主食", False
    return "其他", False


def sat_coef(name, cat):
    if cat == "蛋白":
        if re.search(r"鱼|鲩|鲢|虾|蟹|贝|蛤|蚝|蚬|蛏|蚌|螺|鱿|墨鱼|章鱼|海参|海蜇|鲍|鸡|鸭|鹅|兔|蛇|鸽|鹌鹑", name):
            return 0.28
        if re.search(r"蛋", name):
            return 0.32
        if re.search(r"豆腐|豆干|腐竹|千张|百页|素鸡|面筋|豆浆|豆奶", name):
            return 0.15
        return 0.40
    return SAT_COEF.get(cat, 0.30)


def max_grams(cat, kcal, name=""):
    """单项每餐上限：约 350kcal 一道菜，再受类别物理上限约束。"""
    cap = CAT_MAX_G.get(cat, 300)
    if cat == "主食" and re.search(TUBER, name):
        cap = 250
    if kcal <= 0:
        return cap
    by_energy = int(round(350.0 / (kcal / 100.0) / 10.0) * 10)
    return max(50, min(cap, by_energy))


def num(v):
    if v is None or v == "":
        return 0.0
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def read_rows():
    wb = openpyxl.load_workbook(XLSX, data_only=True)
    ws = wb[SHEET]
    out = []
    seen = set()
    for r in range(4, ws.max_row + 1):
        name = ws.cell(r, 2).value
        if not name or not str(name).strip():
            continue
        key = str(name).strip()
        if key in seen:
            continue          # 源表存在同名重复行（如 比目鱼/蛏子/蛇），保留首条
        seen.add(key)
        out.append(dict(
            name=key,
            kcal=num(ws.cell(r, 3).value),
            protein=num(ws.cell(r, 4).value),
            carb=num(ws.cell(r, 5).value),
            fat=num(ws.cell(r, 6).value),
            fiber=num(ws.cell(r, 7).value),
            potassium=num(ws.cell(r, 8).value),
            sodium=num(ws.cell(r, 9).value),
            v_htn=ws.cell(r, 10).value, e_htn=ws.cell(r, 11).value,
            v_dm=ws.cell(r, 12).value, e_dm=ws.cell(r, 13).value,
            v_chd=ws.cell(r, 14).value, e_chd=ws.cell(r, 15).value,
            v_copd=ws.cell(r, 16).value, e_copd=ws.cell(r, 17).value,
        ))
    return out


def main():
    dry = "--dry" in sys.argv
    rows = read_rows()
    print(f"读入 {len(rows)} 条")

    dropped_dry = 0
    for f in rows:
        cat, sel = classify(f["name"])
        if sel and cat in ("蔬菜", "水果"):
            if f["name"] in AROMATIC or (re.search(DRY_PAT, f["name"])
                    or f["kcal"] >= (HIGH_KCAL_VEG if cat == "蔬菜" else HIGH_KCAL_FRUIT)
                    or (cat == "蔬菜" and f["fiber"] >= HIGH_FIBER_VEG)):
                sel = False
                dropped_dry += 1
        if sel and cat in ("蛋白", "奶类") and re.search(r"粉$|乳粉|奶粉", f["name"]):
            sel = False
            dropped_dry += 1
        # 干制水产 / 油炸豆制品 / 蛋黄蛋清：钠或脂高得离谱，或本身不是一道菜
        if sel and cat == "蛋白" and re.search(
                r"\(干\)|\(干|干$|干贝|虾米|虾皮|海米|淡菜|鱼子|鱼片|蛏干|干狼肚|"
                r"蛋黄|蛋清|鸡蛋白|鹅蛋白|鸭蛋白|\(油\)|油豆腐|油炸", f["name"]):
            sel = False
            dropped_dry += 1
        # 栗子/板粟/白果/莲子 是淀粉类，不提供坚果应有的不饱和脂肪，放进来会让脂肪供能比掉到 19%
        if sel and cat == "坚果" and re.search(r"话梅|南糖|杏仁露|栗子|板粟|白果|银杏|莲子", f["name"]):
            sel = False
            dropped_dry += 1
        f["category"], f["selectable"] = cat, sel
    print(f"干货/脱水/高密度 → 降级为仅入库：{dropped_dry} 条")

    stat = {}
    for f in rows:
        stat[(f["category"], f["selectable"])] = stat.get((f["category"], f["selectable"]), 0) + 1
    print("\n分类分布：")
    for (cat, sel), c in sorted(stat.items(), key=lambda x: -x[1]):
        print(f"  {cat:4s}({'可选池' if sel else '仅入库'}) : {c}")

    for cat in ["主食", "蛋白", "蔬菜", "水果", "奶类", "坚果"]:
        names = [f["name"] for f in rows if f["category"] == cat and f["selectable"]]
        print(f"\n[{cat}] {len(names)} 条")
        for i in range(0, len(names), 8):
            print("   " + " | ".join(names[i:i + 8]))

    if dry:
        return

    import pymysql
    conn = pymysql.connect(**DB)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM cd_food")
    print(f"\n导入前 cd_food 行数 = {cur.fetchone()[0]}")

    cur.execute("DELETE FROM cd_food")
    cur.execute("ALTER TABLE cd_food AUTO_INCREMENT = 1")
    sql = ("INSERT INTO cd_food(name,category,serving_g,max_g,kcal,protein,fat,sat_fat,carb,fiber,"
           "sodium_mg,potassium_mg,gi,tags,status,verdict_htn,evidence_htn,verdict_dm,evidence_dm,"
           "verdict_chd,evidence_chd,verdict_copd,evidence_copd,source) "
           "VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)")
    batch = []
    for f in rows:
        cat, sel = f["category"], f["selectable"]
        gi = GI_HINT.get(f["name"], 0)
        serving = CAT_SERVING.get(cat, 100)
        if cat == "蛋白" and f["kcal"] >= 300:
            serving = 40          # 腐竹/虾米/肉松等干制品，一份 40g
        if cat == "奶类":
            serving = 250 if f["kcal"] <= 120 else (100 if f["kcal"] <= 350 else 40)
        sat = round(f["fat"] * sat_coef(f["name"], cat), 1)
        tags = []
        if f["sodium"] <= 120:
            tags.append("低钠")
        if f["potassium"] > 200:
            tags.append("高钾")
        if f["protein"] >= 15:
            tags.append("高蛋白")
        if f["fiber"] >= 3:
            tags.append("高纤维")
        if any(v == "推荐" for v in (f["v_htn"], f["v_dm"], f["v_chd"], f["v_copd"])):
            tags.append("清单推荐")
        if re.search(r"豆", f["name"]) and cat != "蔬菜":
            tags.append("产气注意")
        batch.append((
            f["name"][:50], cat, serving, max_grams(cat, f["kcal"], f["name"]),
            f["kcal"], f["protein"], f["fat"], sat, f["carb"], f["fiber"],
            f["sodium"], f["potassium"], gi, ",".join(dict.fromkeys(tags))[:80],
            "1" if sel else "0",
            f["v_htn"], (f["e_htn"] or "")[:160],
            f["v_dm"], (f["e_dm"] or "")[:160],
            f["v_chd"], (f["e_chd"] or "")[:160],
            f["v_copd"], (f["e_copd"] or "")[:160], SOURCE,
        ))
    cur.executemany(sql, batch)
    conn.commit()

    cur.execute("SELECT COUNT(*), SUM(status='1') FROM cd_food")
    total, usable = cur.fetchone()
    print(f"导入后 cd_food 行数 = {total}，其中可选池 = {usable}")
    cur.execute("SELECT category, COUNT(*) FROM cd_food WHERE status='1' GROUP BY category ORDER BY 2 DESC")
    print("可选池分布:", cur.fetchall())
    for code, col in [("高血压", "verdict_htn"), ("糖尿病", "verdict_dm"),
                      ("冠心病", "verdict_chd"), ("慢阻肺", "verdict_copd")]:
        cur.execute(f"SELECT {col}, COUNT(*) FROM cd_food WHERE status='1' GROUP BY {col}")
        print(f"  {code}（可选池）:", dict(cur.fetchall()))
    conn.close()


if __name__ == "__main__":
    main()
