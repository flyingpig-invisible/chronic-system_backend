import pymysql

c = pymysql.connect(host="127.0.0.1", user="root", password="123456", database="chronic_db", charset="utf8mb4")
cur = c.cursor()


def dump(title, sql):
    print("\n=== %s ===" % title)
    cur.execute(sql)
    cols = [d[0] for d in cur.description]
    print(" | ".join(cols))
    for r in cur.fetchall():
        print(" | ".join("" if v is None else str(v) for v in r))


dump("本方案涉及", """select name,category,serving_g,max_g,kcal,protein,fat,carb
    from cd_food where name in ('干酸奶','豆腐皮','百页','毛豆(青豆)','豌豆(干)','素鸡丝卷','榛子(干)','燕麦片','荞麦')
    order by category,kcal desc""")

dump("蛋白类 kcal>=180", """select name,serving_g,max_g,kcal,protein,fat from cd_food
    where category='蛋白' and status='1' and kcal>=180 order by kcal desc limit 12""")

dump("奶类 蛋白 top8", """select name,serving_g,max_g,kcal,protein,fat from cd_food
    where category='奶类' and status='1' order by protein desc limit 8""")

dump("蔬菜 蛋白 top8", """select name,serving_g,max_g,kcal,protein,carb from cd_food
    where category='蔬菜' and status='1' order by protein desc limit 8""")

dump("主食 蛋白 top8", """select name,serving_g,max_g,kcal,protein,carb from cd_food
    where category='主食' and status='1' order by protein desc limit 8""")
