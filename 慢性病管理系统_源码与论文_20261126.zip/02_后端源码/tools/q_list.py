import json, urllib.request
BASE="http://localhost:8080"
def post(p,b):
    r=urllib.request.Request(BASE+p,data=json.dumps(b).encode(),method="POST")
    r.add_header("Content-Type","application/json")
    return json.load(urllib.request.urlopen(r))
tk=post("/auth/login",{"username":"doctor","password":"123456"})["data"]["token"]
r=urllib.request.Request(BASE+"/chronic/patient/list?pageNum=1&pageSize=3")
r.add_header("Authorization","Bearer "+tk)
d=json.load(urllib.request.urlopen(r))
rows=d["data"]["rows"]
for x in rows:
    print({k:v for k,v in x.items() if k in ("patientId","name","diseaseCodes","diseaseNames","healthScore","riskLevel","riskLevelName")})
