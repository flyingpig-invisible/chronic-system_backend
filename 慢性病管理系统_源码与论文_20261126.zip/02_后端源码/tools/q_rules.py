import pymysql

c = pymysql.connect(host="127.0.0.1", user="root", password="123456", database="chronic_db", charset="utf8mb4")
cur = c.cursor()


def dump(title, sql):
    print("\n=== %s ===" % title)
    cur.execute(sql)
    cols = [d[0] for d in cur.description]
    print(" | ".join(cols))
    for r in cur.fetchall():
        print(" | ".join("" if v is None else str(v) for v in r))


dump("measures p10", "select measure_id,indicator_code,indicator_name,value,unit,measure_time,abnormal_flag,data_source from cd_measure where patient_id=10 order by measure_id")
dump("warnings p10", "select warning_id,indicator_code,indicator_name,indicator_value,warning_level,critical_flag,escalate_type from cd_warning where patient_id=10 order by warning_id")
