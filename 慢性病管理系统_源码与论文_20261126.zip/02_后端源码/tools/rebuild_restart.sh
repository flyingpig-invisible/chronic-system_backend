#!/usr/bin/env bash
# 后端「改代码 → 打包 → 重启」一键脚本
#
# 背景（踩过的坑，别重复踩）：
#   1. Git Bash 里直接调 mvn 会报 ClassNotFoundException: classworlds.Launcher
#      —— 路径含中文（罗佳昊）导致 boot 目录解析失败，必须走 PowerShell 调 mvn.cmd。
#   2. jar 被运行中的 java 进程锁住时，mvn repackage 会报
#      "Unable to rename .jar to .jar.original"，必须先按端口停进程。
#   3. 当前 shell 环境里有 SERVER__PORT=2901（被别的程序占用），Spring relaxed binding
#      会把它当成 server.port 覆盖 application.yml，导致启动失败。启动时必须 env -u 掉。
set -u
cd "$(dirname "$0")/.." || exit 1
ROOT=$(pwd)
WIN_ROOT=$(cygpath -w "$ROOT" 2>/dev/null || echo "$ROOT")
MVN='C:\Users\罗佳昊\.m2\wrapper\dists\apache-maven-3.9.16\0daed3be3ebd1c706f0e69e8b07c6b73f5cc4ea3dfce72a8d0ec2e849ca2ddb0\bin\mvn.cmd'

echo "[1/3] 停止占用 8080 的进程"
powershell -NoProfile -Command '
$p = (Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue).OwningProcess | Select-Object -Unique
if ($p) { foreach ($x in $p) { Stop-Process -Id $x -Force -ErrorAction SilentlyContinue } }
Start-Sleep -Seconds 2
'

echo "[2/3] 打包（离线）"
powershell -NoProfile -Command "Set-Location -LiteralPath '$WIN_ROOT'; & '$MVN' -o package -DskipTests 2>&1 | Select-String -Pattern 'ERROR|BUILD SUCCESS|BUILD FAILURE' | Select-Object -Last 15"

echo "[3/3] 启动"
env -u SERVER__PORT -u SERVER__HOST nohup java -jar target/chronic-backend.jar \
  > "logs/run-$(date +%m%d-%H%M).log" 2>&1 &
for i in $(seq 1 40); do
  if netstat -ano | grep -q ":8080.*LISTENING"; then
    echo "已就绪 (${i}s)"; exit 0
  fi
  sleep 1
done
echo "启动超时，请查看 logs/ 下最新日志"; exit 1
