# -*- coding: utf-8 -*-
"""算法五结果格式化打印：python show_diet.py <patientId> [date]"""
import json
import sys
import urllib.request

BASE = "http://localhost:8080"


def post(path, body=None, token=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    return json.load(urllib.request.urlopen(req))


def get(path, token):
    req = urllib.request.Request(BASE + path)
    req.add_header("Authorization", "Bearer " + token)
    return json.load(urllib.request.urlopen(req))


def main():
    pid = sys.argv[1] if len(sys.argv) > 1 else "1"
    date = sys.argv[2] if len(sys.argv) > 2 else None
    tk = post("/auth/login", {"username": "doctor", "password": "123456"})["data"]["token"]
    url = f"/chronic/diet/recommend?patientId={pid}" + (f"&date={date}" if date else "")
    d = post(url, None, tk)
    if d.get("code") != 200:
        print(json.dumps(d, ensure_ascii=False)[:900])
        return
    r = d["data"]
    print(f"患者 {r['patientName']} | 病种 {r['diseaseText']} | 能量目标 {r['targetKcal']} kcal | 得分 {r['score']}")
    print("候选池:", json.dumps(r["pool"], ensure_ascii=False))
    print()
    for m in r["meals"]:
        print(f"[{m['name']}] 目标 {m['targetKcal']} / 实际 {m['kcal']} kcal / 钠 {m['sodiumMg']} mg")
        for it in m["items"]:
            print(f"    {it['name']:<24}{it['servingG']:>4}g {it['kcal']:>6.1f}kcal "
                  f"蛋白{it['protein']:>5.1f}g 钠{it['sodiumMg']:>6.1f}mg  {it['verdict']:<2} [{it['category']}]")
    print()
    print("合计:", json.dumps(r["totals"], ensure_ascii=False))
    print()
    for c in r["constraints"]:
        print(("  [OK]   " if c["pass"] else "  [FAIL] ") +
              f"{c['name']:<10} 限 {c['limit']:<34} 实际 {c['actual']}")
    print()
    print("求解说明:", r["solverNote"])
    print()
    for a in r["advice"]:
        print("  ·", a)


if __name__ == "__main__":
    main()
