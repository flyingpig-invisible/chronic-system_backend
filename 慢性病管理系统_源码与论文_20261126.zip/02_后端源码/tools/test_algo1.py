# -*- coding: utf-8 -*-
"""算法一·危急重症预警 端到端验证

覆盖三条路径：
  1) 危急值短路（critical_flag=1，不与常规规则比大小、不参与升级）
  2) COMBO 组合升级（同病种 24h 内 >=2 个不同指标异常，且均达中危及以上）
  3) PERSIST 持续升级（同指标 24h 内累计异常 >=3 次）
另含反向用例：1 级预警不应被组合规则拉成高危。

用法：python test_algo1.py
"""
import datetime
import json
import urllib.request
import pymysql

BASE = "http://localhost:8080"
PATIENT_ID = 10  # 张凯博，仅高血压，初始无预警，适合做干净基线

DB = dict(host="127.0.0.1", user="root", password="123456", database="chronic_db", charset="utf8mb4")


def post(path, body=None, token=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(req) as r:
        return json.load(r)


def get(path, token):
    req = urllib.request.Request(BASE + path)
    req.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(req) as r:
        return json.load(r)


def clean(cid):
    cur = cid.cursor()
    cur.execute("delete from cd_warning where patient_id=%s", (PATIENT_ID,))
    cur.execute("delete from cd_measure where patient_id=%s and data_source='2'", (PATIENT_ID,))
    cur.execute("update cd_patient set pending_warning_count=0 where patient_id=%s", (PATIENT_ID,))
    cid.commit()


def last_warning(cid):
    cur = cid.cursor(pymysql.cursors.DictCursor)
    cur.execute("""select warning_id,indicator_code,indicator_name,indicator_value,warning_level,
                          critical_flag,escalate_type,escalate_reason,origin_level,threshold_desc
                   from cd_warning where patient_id=%s order by warning_id desc limit 1""", (PATIENT_ID,))
    return cur.fetchone()


CASES = [
    # (标签, indicatorCode, value, unit, 预期)
    ("危急值 · 收缩压 205", "sbp", 205, "mmHg",
     dict(level="3", critical="1", escalate=None)),
    ("反向 · 睡眠不足 5h（1级，邻床已存在3级血压）", "sleep", 5, "h",
     dict(level="1", critical="0", escalate=None)),
    ("常规 · 收缩压 168（2级，与1级睡眠不构成组合）", "sbp", 168, "mmHg",
     dict(level="2", critical="0", escalate=None)),
    ("组合升级 · 舒张压 104（2级，叠加收缩压2级）", "dbp", 104, "mmHg",
     dict(level="3", critical="0", escalate="COMBO")),
    ("持续 · 睡眠不足 5h 第2次", "sleep", 5, "h",
     dict(level="1", critical="0", escalate=None)),
    ("持续升级 · 睡眠不足 5h 第3次", "sleep", 5, "h",
     dict(level="3", critical="0", escalate="PERSIST")),
]


def main():
    tk = post("/auth/login", {"username": "doctor", "password": "123456"})["data"]["token"]
    cid = pymysql.connect(**DB, autocommit=True)  # 必须 autocommit，否则 REPEATABLE READ 会读到旧快照
    clean(cid)

    print("=" * 96)
    print("算法一 · 危急重症预警 端到端验证    患者 %d（张凯博，高血压）" % PATIENT_ID)
    print("=" * 96)

    ok = fail = 0
    base = datetime.datetime.now().replace(microsecond=0) - datetime.timedelta(minutes=len(CASES) + 5)
    for i, (label, code, value, unit, exp) in enumerate(CASES):
        # cd_measure 在 (患者,指标,秒级时间) 上有唯一键，必须给每条记录不同的测量时间
        mt = (base + datetime.timedelta(minutes=i)).strftime("%Y-%m-%d %H:%M:%S")
        res = post("/chronic/measure", {
            "patientId": PATIENT_ID, "indicatorCode": code, "value": value, "unit": unit,
            "dataSource": "2", "measureTime": mt,
        }, tk)
        if res.get("code") != 200:
            print("[录入失败] %s -> %s" % (label, json.dumps(res, ensure_ascii=False)[:200]))
            fail += 1
            continue
        w = last_warning(cid)
        marks = []
        marks.append("等级 %s%s" % (w["warning_level"], "" if w["warning_level"] == exp["level"] else " ✗期望" + exp["level"]))
        marks.append("危急值 %s%s" % (w["critical_flag"], "" if w["critical_flag"] == exp["critical"] else " ✗期望" + exp["critical"]))
        esc = w["escalate_type"] or "—"
        marks.append("升级 %s%s" % (esc, "" if esc == (exp["escalate"] or "—") else " ✗期望" + str(exp["escalate"])))
        passed = (w["warning_level"] == exp["level"] and w["critical_flag"] == exp["critical"]
                  and esc == (exp["escalate"] or "—"))
        ok += 1 if passed else 0
        fail += 0 if passed else 1
        print(("\n[OK]   " if passed else "\n[FAIL] ") + label)
        print("        " + " | ".join(marks))
        print("        阈值: " + str(w["threshold_desc"]))
        if w["escalate_reason"]:
            print("        原因: " + w["escalate_reason"])
        if w["origin_level"]:
            print("        原级: " + w["origin_level"])

    print("\n" + "-" * 96)
    print("用例通过 %d / %d" % (ok, ok + fail))

    # 接口侧校验：预警列表 + 分级统计
    lst = get("/chronic/warning/list?patientId=%d&pageNum=1&pageSize=20" % PATIENT_ID, tk)
    rows = lst["data"]["rows"] if lst.get("data") else []
    print("预警列表接口返回 %d 条（高危优先）" % len(rows))
    for w in rows:
        print("    #%-5s %-6s %-6s %s %s %s" % (
            w["warningId"], w["indicatorName"], str(w["indicatorValue"]) + (w.get("unit") or ""),
            "高危" if w["warningLevel"] == "3" else ("中危" if w["warningLevel"] == "2" else "低危"),
            "危急值" if w.get("criticalFlag") == "1" else "      ",
            (w.get("escalateType") or "")))

    stat = get("/chronic/warning/stat/level?patientId=%d" % PATIENT_ID, tk)
    print("分级统计:", json.dumps(stat["data"], ensure_ascii=False))
    pat = get("/chronic/patient/%d" % PATIENT_ID, tk)
    print("患者待处理预警数:", pat["data"]["pendingWarningCount"], "| 风险等级:", pat["data"]["riskLevel"],
          "| 风险评分:", pat["data"]["riskScore"])

    # 急救联动：对危急值预警发起 120 联动
    crit = [w for w in rows if w.get("criticalFlag") == "1"]
    if crit:
        wid = crit[0]["warningId"]
        r = post("/chronic/warning/%d/emergency" % wid,
                 {"channel": "120", "receiver": "急救中心", "linkResult": "1",
                  "remark": "算法一验证：危急值自动联动"}, tk)
        cur = cid.cursor()
        cur.execute("select emergency_linked from cd_warning where warning_id=%s", (wid,))
        linked = cur.fetchone()[0]
        cur.execute("select channel,receiver,link_result from cd_emergency_link where warning_id=%s", (wid,))
        links = cur.fetchall()
        print("急救联动 #%d -> code=%s, emergency_linked=%s, 联动记录=%s"
              % (wid, r.get("code"), linked, links))
    cid.close()


if __name__ == "__main__":
    main()
