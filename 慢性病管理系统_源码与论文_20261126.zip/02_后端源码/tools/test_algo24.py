# -*- coding: utf-8 -*-
"""算法二（健康评分）+ 算法四（多模态情绪感知）验证

用法：python test_algo24.py [patientId]
"""
import json
import sys
import urllib.parse
import urllib.request

BASE = "http://localhost:8080"


def post(path, body=None, token=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(req) as r:
        return json.load(r)


def get(path, token):
    req = urllib.request.Request(BASE + path)
    req.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(req) as r:
        return json.load(r)


def j(v):
    return json.dumps(v, ensure_ascii=False)


def main():
    pid = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    tk = post("/auth/login", {"username": "doctor", "password": "123456"})["data"]["token"]

    print("=" * 96)
    print("算法二 · 健康评分（近 7 天窗口，w1~w4 加权，分数越高越健康）")
    print("=" * 96)
    r = post("/chronic/score/calc/%d" % pid, None, tk)
    d = r.get("data") or {}
    if r.get("code") != 200:
        print("计算失败:", j(r))
    else:
        for k in ("healthScore", "healthLevel", "healthLevelName", "dailyScore", "windowStart", "windowEnd",
                  "indicatorRate", "indicatorMeasured", "indicatorTotal",
                  "medicationRate", "medicationOnTime", "medicationLate", "medicationMissed",
                  "alertDensity", "alertDays", "measuredDays"):
            if k in d:
                print("  %-18s %s" % (k, d[k]))
        if "weights" in d:
            print("  %-18s %s" % ("weights", j(d["weights"])))
        items = d.get("indicatorItems")
        if isinstance(items, list) and items:
            print("  指标明细（前 8 项）:")
            for it in items[:8]:
                print("     ", j(it))
        elif items:
            print("  指标明细:", j(items)[:400])

    w = get("/chronic/score/weight/%d" % pid, tk)
    print("  权重配置:", j(w.get("data")))
    tr = get("/chronic/score/trend/%d" % pid, tk)
    print("  趋势点数:", len(tr.get("data") or []))

    print()
    print("=" * 96)
    print("算法四 · 多模态情绪感知（文本 + 生理 + 行为，缺模态按比例重分配权重）")
    print("=" * 96)
    lv = get("/chronic/emotion/levels", tk)
    print("  等级口径:", j(lv.get("data")))

    cases = [
        ("仅生理+行为（无文本）", {"patientId": pid, "source": "MANUAL"}),
        ("附负面文本", {"patientId": pid, "text": "最近总是睡不着，心里很烦，什么都不想做，也不想跟人说话", "source": "MANUAL"}),
        ("附平稳文本", {"patientId": pid, "text": "今天状态还行，按时吃药了，晚饭后出去散了会儿步", "source": "MANUAL"}),
    ]
    for label, body in cases:
        r = post("/chronic/emotion/analyze", body, tk)
        if r.get("code") != 200:
            print("\n  [FAIL] %s -> %s" % (label, j(r)[:300]))
            continue
        d = r["data"]
        print("\n  %s" % label)
        print("     融合 %s（%s / %s）| 需医生介入 %s | 权重 %s"
              % (d.get("fusedScore"), d.get("level"), d.get("levelName"),
                 d.get("needDoctorAttention"), d.get("weights")))
        print("     文本 %s（%s）命中=%s" % (d.get("textScore"), d.get("textLabel"), j(d.get("textHits"))))
        print("     生理 %s（%s）" % (d.get("physioScore"), d.get("physioNote")))
        print("     行为 %s（%s）" % (d.get("behaviorScore"), d.get("behaviorNote")))
        print("     建议 %s" % d.get("advice"))

    h = get("/chronic/emotion/history?patientId=%d&limit=5" % pid, tk)
    print("\n  历史记录 %d 条" % len(h.get("data") or []))


if __name__ == "__main__":
    main()
