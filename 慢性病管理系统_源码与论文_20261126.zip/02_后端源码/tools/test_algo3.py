# -*- coding: utf-8 -*-
"""算法三·GraphRAG 检索验证：实体链接 → 多跳扩展 → 可追溯来源

用法：python test_algo3.py
"""
import json
import urllib.parse
import urllib.request

BASE = "http://localhost:8080"

QUESTIONS = [
    ("1", "血压要控制到多少"),
    ("1", "吃盐有什么限制"),
    ("2", "血糖控制目标是多少"),
    ("2", "低血糖怎么急救"),
    ("3", "冠心病患者能运动吗"),
    ("3", "冠心病患者血压要控制到多少"),  # 跨病种：冠心病—危险因素→高血压，走桥梁实体
    ("4", "慢阻肺急性加重怎么做急救"),
    ("4", "慢阻肺要打疫苗吗"),
    ("1,2", "血压高又血糖高，饮食上要注意什么"),
    ("1", "今天天气怎么样"),  # 反向用例：应无命中
]


def post(path, body=None, token=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(req) as r:
        return json.load(r)


def get(path, token):
    req = urllib.request.Request(BASE + path)
    req.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(req) as r:
        return json.load(r)


def main():
    tk = post("/auth/login", {"username": "doctor", "password": "123456"})["data"]["token"]

    st = get("/chronic/kb/graph/stats", tk)
    print("=" * 100)
    print("图谱概况:", json.dumps(st["data"], ensure_ascii=False))
    print("=" * 100)

    ok = fail = 0
    for dis, q in QUESTIONS:
        url = "/chronic/kb/graph/search?topK=6&question=" + urllib.parse.quote(q)
        if dis:
            url += "&diseaseCode=" + dis
        d = get(url, tk)
        r = d.get("data") or {}
        hits = r.get("hits") or []
        ents = r.get("linkedEntities") or []
        expect_empty = q == "今天天气怎么样"
        good = (len(hits) == 0) if expect_empty else (len(hits) > 0 and len(ents) > 0)
        # 可追溯性：除 SEED 外每条命中都应有来源文档
        no_src = [h for h in hits if not h.get("sourceTitle")]
        ok += 1 if good and not no_src else 0
        fail += 0 if good and not no_src else 1
        print("\n%s 病种[%s] 问：%s" % ("[OK]  " if good and not no_src else "[FAIL]", dis or "-", q))
        print("   链接实体(%d): %s" % (len(ents), "、".join(ents[:10])))
        print("   命中 %d 条 | 第1跳 %s | 第2跳 %s | 图谱总量 %s"
              % (len(hits), r.get("hop1"), r.get("hop2"), r.get("totalTriples")))
        for h in hits:
            print("     [T%s]%s —%s→ %s  (跳%s, 分%.2f, %s%s)"
                  % (h.get("tripleId"), h.get("head"), h.get("relation"), h.get("tail"),
                     h.get("hop"), h.get("score") or 0, h.get("sourceTitle") or "无来源",
                     (" · " + h["sourceSection"]) if h.get("sourceSection") else ""))
        if no_src:
            print("   !! 有 %d 条命中缺少来源文档" % len(no_src))

    print("\n" + "-" * 100)
    print("用例通过 %d / %d" % (ok, ok + fail))

    allt = get("/chronic/kb/graph/all", tk)
    print("全量三元组接口返回 %d 条（上限 300）" % len(allt["data"]))


if __name__ == "__main__":
    main()
