<template>
  <div class="app-root">
    <router-view />
  </div>
</template>

<script setup>
</script>

<style>
.app-root {
  min-height: 100vh;
  background: #f5f7fa;
}
</style>
