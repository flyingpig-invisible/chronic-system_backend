import request from '@/utils/request'

/** 分页查询设备 */
export function pageDevice(params) {
  return request({ url: '/device/page', method: 'get', params })
}

/** 设备数据导入历史 */
export function listImportLogs(params) {
  return request({ url: '/device/import/logs', method: 'get', params })
}

/** 某台设备的监测数据 */
export function listDeviceMeasures(deviceId, params) {
  return request({ url: `/device/${deviceId}/measures`, method: 'get', params })
}

/** 强制解绑（设备绑在错误患者下时使用） */
export function forceUnbindDevice(deviceId) {
  return request({ url: `/device/${deviceId}/force-unbind`, method: 'post' })
}
