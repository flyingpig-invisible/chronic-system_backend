import request from '@/utils/request'

/**
 * 生成患者健康报告
 * 报告为实时计算，不落库；每次调用都基于当前监测/预警/评分数据重新生成
 * @param {number|string} patientId 患者ID
 * @param {number} days 统计窗口天数，默认 30
 */
export function getHealthReport(patientId, days = 30) {
  return request({
    url: `/chronic/report/${patientId}`,
    method: 'get',
    params: { days }
  })
}
