import request from '@/utils/request'

/** 按病种统计慢性病控制率 */
export function getDiseaseControl(days = 30) {
  return request({ url: '/chronic/stat/control', method: 'get', params: { days } })
}
