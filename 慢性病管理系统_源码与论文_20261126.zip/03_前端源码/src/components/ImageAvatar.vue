<template>
  <div class="ia-wrap" :class="{ speaking }">
    <!-- 主形象：加载失败自动尝试下一个候选文件名，全部失败才降级为文字头像 -->
    <img
      v-if="!exhausted"
      :key="current"
      :src="current"
      class="ia-img"
      alt=""
      draggable="false"
      @error="tryNext"
    />
    <div v-else class="ia-fallback">{{ (name || 'AI').slice(0, 1) }}</div>

    <div class="ia-shadow" />
    <div class="ia-nameplate" v-if="showName">
      <span class="dot" :class="{ live: speaking }" />
      {{ name }}
      <span class="state">{{ speaking ? '回复中' : '待机中' }}</span>
    </div>
  </div>
</template>

<script setup>
/**
 * 2D 形象组件
 *
 * 设计取向：用一个 <img> 取代原来的 three.js 画布。
 * 好处是不用加载 2.3MB 的 three 包和 38MB 的 VRM 模型，首屏更快；
 * 你换形象只要换图片文件，不用碰代码。
 *
 * 图片放置位置（二者皆可，先命中先用）：
 *   web/models/avatar.png         （线上直接生效，无需重新打包）
 *   frontend/public/models/avatar.png（重新打包时会被复制过去，长期保留）
 *
 * 候选顺序见 defaultCandidates，支持 png / jpg / jpeg / webp。
 */
import { computed, ref } from 'vue'

const props = defineProps({
  // 显式指定图片地址；不传则按候选列表依次探测
  src: { type: String, default: '' },
  name: { type: String, default: 'AI 健康助手' },
  speaking: { type: Boolean, default: false },
  emotion: { type: String, default: 'neutral' },
  showName: { type: Boolean, default: true }
})

const defaultCandidates = [
  '/models/avatar.png',
  '/models/avatar.jpg',
  '/models/avatar.jpeg',
  '/models/avatar.webp'
]

const candidates = computed(() =>
  props.src ? [props.src, ...defaultCandidates] : defaultCandidates
)
const idx = ref(0)
const current = computed(() => candidates.value[Math.min(idx.value, candidates.value.length - 1)])
const exhausted = ref(false)

const tryNext = () => {
  if (idx.value < candidates.value.length - 1) {
    idx.value += 1
  } else {
    exhausted.value = true
  }
}
</script>

<style scoped>
.ia-wrap {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  padding-bottom: 30px;
  box-sizing: border-box;
}

/* 形象本体：静息时缓慢呼吸起伏。图片已去底，直接浮在面板渐变上 */
.ia-img {
  max-height: 100%;
  max-width: 94%;
  object-fit: contain;
  user-select: none;
  filter: drop-shadow(0 8px 14px rgba(31, 52, 84, 0.16));
  animation: ia-breathe 4s ease-in-out infinite;
  transform-origin: 50% 100%;
  transition: max-width 0.3s ease;
}

/* 说话时节奏变快、幅度略大，像是在应答 */
.speaking .ia-img {
  animation: ia-talk 1.1s ease-in-out infinite;
}

@keyframes ia-breathe {
  0%, 100% { transform: translateY(0) scale(1); }
  50% { transform: translateY(-5px) scale(1.008); }
}

@keyframes ia-talk {
  0%, 100% { transform: translateY(0) scale(1); }
  35% { transform: translateY(-4px) scale(1.012); }
  70% { transform: translateY(-2px) scale(1.004); }
}

/* 脚下投影，避免形象“飘”在背景上 */
.ia-shadow {
  position: absolute;
  bottom: 26px;
  left: 50%;
  width: 132px;
  height: 16px;
  transform: translateX(-50%);
  background: radial-gradient(50% 50% at 50% 50%, rgba(31, 52, 84, 0.22), transparent 72%);
  pointer-events: none;
}

.ia-nameplate {
  position: absolute;
  left: 50%;
  bottom: 2px;
  transform: translateX(-50%);
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 12px;
  font-size: 12px;
  color: #33507a;
  background: rgba(255, 255, 255, 0.92);
  border: 1px solid rgba(64, 158, 255, 0.28);
  border-radius: 999px;
  white-space: nowrap;
  box-shadow: 0 4px 12px rgba(31, 52, 84, 0.1);
}
.ia-nameplate .dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #67c23a;
}
.ia-nameplate .dot.live {
  background: var(--c-primary);
  animation: ia-blink 1s ease-in-out infinite;
}
.ia-nameplate .state {
  color: #8fa3bd;
}
@keyframes ia-blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.25; }
}

/* 图片全都加载不出来时的兜底：首字头像，保证不空白 */
.ia-fallback {
  width: 96px;
  height: 96px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 40px;
  font-weight: 600;
  color: #fff;
  background: linear-gradient(135deg, #6fb1ff, var(--c-primary));
  box-shadow: 0 10px 22px rgba(64, 158, 255, 0.3);
  animation: ia-breathe 4s ease-in-out infinite;
}

@media (max-height: 720px) {
  .ia-wrap { padding-bottom: 28px; }
  .ia-img { max-width: 56%; }
}
</style>
