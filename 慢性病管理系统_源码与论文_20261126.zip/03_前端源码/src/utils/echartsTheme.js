import * as echarts from 'echarts'

/**
 * 浅色主题 ECharts 主题
 * 用法：echarts.init(dom, 'cdms')
 */
export const CDMS_THEME = 'cdms'

/**
 * 读取当前品牌主色。
 * ECharts 的配置是纯 JS 对象，读不到 CSS 变量，必须在这里解析成实际色值；
 * 解析失败（例如样式表还没注入）时回落到默认青绿，保证图表不会变成黑色。
 */
export const brandColor = (fallback = '#00a0b0') => {
  if (typeof document === 'undefined' || !document.documentElement) return fallback
  const v = getComputedStyle(document.documentElement).getPropertyValue('--c-primary').trim()
  return v || fallback
}

const axisLine = { lineStyle: { color: '#dcdfe6' } }
const axisLabel = { color: '#606266', fontSize: 12 }
const splitLine = { lineStyle: { color: '#ebeef5', type: 'dashed' } }

const theme = {
  color: [brandColor(), '#67c23a', '#e6a23c', '#f56c6c', '#909399', '#337ecc', '#6b7fd7'],
  backgroundColor: 'transparent',
  textStyle: { color: '#606266', fontFamily: 'Helvetica Neue, PingFang SC, Microsoft YaHei, sans-serif' },
  title: {
    textStyle: { color: '#303133', fontSize: 15, fontWeight: 600 },
    subtextStyle: { color: '#909399' }
  },
  legend: { textStyle: { color: '#606266' } },
  tooltip: {
    backgroundColor: '#ffffff',
    borderColor: '#e4e7ed',
    borderWidth: 1,
    textStyle: { color: '#303133', fontSize: 12 },
    extraCssText: 'border-radius: 8px; box-shadow: 0 6px 18px rgba(0,0,0,0.1);'
  },
  categoryAxis: {
    axisLine,
    axisTick: { show: false },
    axisLabel,
    splitLine: { show: false }
  },
  valueAxis: {
    axisLine: { show: false },
    axisTick: { show: false },
    axisLabel,
    splitLine,
    nameTextStyle: { color: '#909399' }
  },
  line: {
    smooth: true,
    symbol: 'circle',
    symbolSize: 7,
    lineStyle: { width: 2 },
    itemStyle: { borderWidth: 2, borderColor: '#ffffff' }
  },
  bar: {
    itemStyle: { borderRadius: [4, 4, 0, 0] },
    barMaxWidth: 34
  },
  pie: {
    itemStyle: { borderColor: '#ffffff', borderWidth: 2 },
    label: { color: '#606266' },
    labelLine: { lineStyle: { color: '#dcdfe6' } }
  },
  radar: {
    axisLine: { lineStyle: { color: '#e4e7ed' } },
    splitLine: { lineStyle: { color: '#ebeef5' } },
    splitArea: { areaStyle: { color: ['#ffffff', '#f5f7fa'] } },
    axisName: { color: '#606266' }
  },
  gauge: {
    axisLine: { lineStyle: { color: [[1, '#ebeef5']] } },
    splitLine: { lineStyle: { color: '#dcdfe6' } },
    axisLabel: { color: '#909399' },
    detail: { color: '#409eff' },
    title: { color: '#606266' }
  }
}

let registered = false
export function registerCdmsTheme() {
  if (registered) return
  echarts.registerTheme(CDMS_THEME, theme)
  registered = true
}

export default theme
