<template>
  <div class="diet-page">
    <iframe class="diet-frame" src="/diet.html" title="饮食推荐"></iframe>
  </div>
</template>

<script setup>
// 饮食推荐：内容为独立静态页 /diet.html（放在 web/ 目录，由后端静态资源直接提供）。
// 用 iframe 承载，既能嵌进后台菜单，也能单独打开给患者/评审看。
</script>

<style scoped>
.diet-page {
  height: calc(100vh - 100px);
  min-height: 640px;
}
.diet-frame {
  width: 100%;
  height: 100%;
  border: 0;
  border-radius: 10px;
  background: #f4f7fb;
  display: block;
}
</style>
