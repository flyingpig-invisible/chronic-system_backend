<template>
  <div class="login-page">
    <!-- 顶部细导航：呼应参考稿那种"logo 在左、信息在右"的极简顶栏 -->
    <header class="topbar">
      <div class="topbar-brand">
        <div class="brand-mark"><el-icon :size="17"><FirstAidKit /></el-icon></div>
        <span class="topbar-name">慢性病管理系统</span>
        <span class="topbar-en">CHRONIC DISEASE MANAGEMENT</span>
      </div>
      <div class="topbar-right">
        <span>医生工作站</span>
        <span class="topbar-sep"></span>
        <span>v1.0</span>
      </div>
    </header>

    <main class="login-main">
      <section class="brand-side">
        <div class="eyebrow"><span class="eyebrow-bar"></span>UNIQUE CLINICAL WORKFLOW</div>
        <h1 class="brand-name">慢性病管理系统</h1>
        <p class="brand-sub">Chronic Disease Management Platform</p>
        <p class="brand-desc">全周期健康监测 · 智能风险预警 · 医患协同干预</p>
        <ul class="brand-points">
          <li><span class="dot"></span>实时采集 7 项体征指标</li>
          <li><span class="dot"></span>规则引擎自动分级预警</li>
          <li><span class="dot"></span>AI 健康助手辅助临床决策</li>
          <li><span class="dot"></span>医学知识库沉淀诊疗经验</li>
        </ul>
      </section>

    <div class="login-box">
      <div class="box-line"></div>
      <div class="box-head">
        <div class="box-icon"><el-icon :size="20"><Lock /></el-icon></div>
        <div>
          <h2>医生端登录</h2>
          <p>Doctor Console Access</p>
        </div>
      </div>

      <el-form ref="formRef" :model="form" :rules="rules" size="large" @keyup.enter="handleLogin">
        <el-form-item prop="username">
          <el-input v-model="form.username" placeholder="请输入用户名" :prefix-icon="User" clearable />
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            v-model="form.password"
            type="password"
            placeholder="请输入密码"
            :prefix-icon="Key"
            show-password
          />
        </el-form-item>
        <el-form-item>
          <el-button class="login-btn" type="primary" :loading="loading" @click="handleLogin">
            <span v-if="!loading">进 入 系 统</span>
            <span v-else>登 录 中…</span>
          </el-button>
        </el-form-item>
      </el-form>

      <div class="login-tip">
        <span class="tip-key">admin</span> / <span class="tip-key">123456</span> 管理员
        <span class="tip-sep">·</span>
        <span class="tip-key">doctor</span> / <span class="tip-key">123456</span> 医生
      </div>
    </div>
    </main>

    <div class="foot-note">Chronic Disease Management System v1.0 · Spring Boot 3 + Vue 3</div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { User, Lock, Key } from '@element-plus/icons-vue'
import { useUserStore } from '@/store/user'

const router = useRouter()
const userStore = useUserStore()
const formRef = ref()
const loading = ref(false)
// 演示环境默认账号密码（与数据库 sys_user 一致），改密码时这里要同步改
const form = reactive({ username: 'admin', password: '123456' })
const rules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
}

const handleLogin = () => {
  formRef.value.validate((valid) => {
    if (!valid) return
    loading.value = true
    userStore
      .login(form)
      .then(() => userStore.getInfo())
      .then(() => {
        ElMessage.success('登录成功')
        router.push('/map/overview')
      })
      .finally(() => {
        loading.value = false
      })
  })
}
</script>

<style scoped>
.login-page {
  position: relative;
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--bg-root);
}

/* ---------- 顶部细导航 ---------- */
.topbar {
  height: 64px;
  flex: none;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 48px;
  background: #ffffff;
  border-bottom: 1px solid var(--line);
}
.topbar-brand {
  display: flex;
  align-items: center;
  gap: 12px;
}
.brand-mark {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  background: var(--c-primary);
}
.topbar-name {
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 1.2px;
  color: var(--t-main);
}
.topbar-en {
  font-size: 10px;
  letter-spacing: 1.6px;
  color: var(--t-dim);
  padding-left: 12px;
  border-left: 1px solid var(--line);
}
.topbar-right {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 12px;
  letter-spacing: 1px;
  color: var(--t-dim);
}
.topbar-sep {
  width: 1px;
  height: 12px;
  background: var(--line-strong);
}

/* ---------- 主体两栏 ---------- */
.login-main {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 110px;
  padding: 0 48px 20px;
  min-height: 0;
}

/* 左侧品牌区 */
.brand-side {
  width: 470px;
}
.eyebrow {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 11px;
  letter-spacing: 2.2px;
  color: var(--c-primary);
  margin-bottom: 18px;
}
.eyebrow-bar {
  width: 22px;
  height: 2px;
  background: var(--c-primary);
}
.brand-name {
  margin: 0;
  font-size: 44px;
  font-weight: 600;
  letter-spacing: 2px;
  line-height: 1.2;
  color: var(--t-main);
}
.brand-sub {
  margin: 14px 0 20px;
  font-size: 11px;
  letter-spacing: 3px;
  text-transform: uppercase;
  color: var(--t-dim);
}
.brand-desc {
  font-size: 15px;
  color: var(--t-sub);
  letter-spacing: 0.6px;
}
.brand-points {
  margin: 34px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
}
.brand-points li {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 14px;
  color: var(--t-sub);
  padding: 11px 0;
  border-top: 1px solid var(--line);
}
.brand-points li:last-child {
  border-bottom: 1px solid var(--line);
}
.brand-points .dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--c-primary);
  flex: none;
}

/* ---------- 登录卡片 ---------- */
.login-box {
  position: relative;
  z-index: 2;
  width: 400px;
  padding: 40px 38px 28px;
  border-radius: 6px;
  background: #ffffff;
  border: 1px solid var(--line);
  box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04), 0 12px 32px rgba(16, 24, 40, 0.05);
}
.box-line {
  display: none;
}
.box-head {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 30px;
}
.box-icon {
  width: 42px;
  height: 42px;
  flex: none;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  color: var(--c-primary);
  background: color-mix(in srgb, var(--c-primary) 8%, #ffffff);
  border: 1px solid color-mix(in srgb, var(--c-primary) 22%, #ffffff);
}
.box-head h2 {
  margin: 0;
  font-size: 19px;
  letter-spacing: 1.4px;
  color: var(--t-main);
}
.box-head p {
  margin: 4px 0 0;
  font-size: 10px;
  letter-spacing: 1.8px;
  text-transform: uppercase;
  color: var(--t-dim);
}

.login-box :deep(.el-form-item) {
  margin-bottom: 20px;
}
.login-box :deep(.el-input__wrapper) {
  border-radius: 4px;
  padding: 4px 14px;
  box-shadow: 0 0 0 1px var(--line-strong) inset;
}
.login-box :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 1px var(--c-primary) inset;
}
.login-box :deep(.el-input__inner) {
  color: var(--t-main);
  letter-spacing: 0.5px;
}
.login-box :deep(.el-input__inner::placeholder) {
  color: var(--t-dim);
}

.login-btn {
  width: 100%;
  height: 46px;
  font-size: 14px;
  letter-spacing: 4px;
  border: none;
  border-radius: 4px;
  color: #ffffff;
  font-weight: 600;
  background: var(--c-primary);
  transition: background 0.2s;
}
.login-btn:hover {
  background: var(--c-primary-2);
}
.login-btn:active {
  background: var(--c-primary-deep);
}

.login-tip {
  margin-top: 8px;
  text-align: center;
  font-size: 12px;
  color: var(--t-dim);
  letter-spacing: 0.4px;
}
.tip-key {
  color: var(--c-primary);
  font-family: Consolas, Monaco, monospace;
}
.tip-sep {
  margin: 0 8px;
  color: var(--line-strong);
}

.foot-note {
  flex: none;
  text-align: center;
  padding: 0 0 20px;
  font-size: 11px;
  letter-spacing: 1.2px;
  color: var(--t-dim);
}

@media (max-width: 1120px) {
  .brand-side {
    display: none;
  }
  .login-main {
    gap: 0;
  }
  .topbar {
    padding: 0 24px;
  }
  .topbar-en {
    display: none;
  }
}
</style>
