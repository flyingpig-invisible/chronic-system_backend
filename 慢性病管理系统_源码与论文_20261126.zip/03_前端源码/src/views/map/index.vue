<template>
  <div class="screen">
    <!-- 顶部标题条 -->
    <header class="screen-head">
      <div class="head-left">
        <h1>贵州省慢性病管理态势</h1>
        <span class="head-sub">GUIZHOU CHRONIC DISEASE SITUATION</span>
      </div>
      <div class="head-right">
        <span class="demo-badge">演示数据</span>
        <span class="head-item">在管医院 {{ hospitals.length }} 家</span>
        <span class="head-sep"></span>
        <span class="head-item">{{ nowText }}</span>
      </div>
    </header>

    <div class="screen-body">
      <!-- 左侧：地市分布 + 医院等级 -->
      <aside class="col">
        <section class="card">
          <div class="card-title">
            <span class="bar"></span>
            <el-icon class="ct-icon"><Histogram /></el-icon>各市州在管患者
          </div>
          <ul class="rank-list">
            <li v-for="c in cityRank" :key="c.name">
              <span class="rank-name">{{ c.short }}</span>
              <span class="rank-track"><i :style="{ width: c.pct + '%' }" /></span>
              <span class="rank-val">{{ c.patients }}</span>
            </li>
          </ul>
        </section>

        <section class="card">
          <div class="card-title">
            <span class="bar"></span>
            <el-icon class="ct-icon"><OfficeBuilding /></el-icon>医院与设备构成
          </div>
          <ul class="metric-list">
            <li v-for="l in levelStats" :key="l.name">
              <span class="metric-name">{{ l.name }}</span>
              <b>{{ l.count }}</b>
              <span class="metric-unit">家</span>
            </li>
          </ul>
          <div class="divider"></div>
          <ul class="metric-list">
            <li v-for="s in statusStats" :key="s.name">
              <span class="metric-name">{{ s.name }}</span>
              <b :class="s.tone">{{ s.count }}</b>
              <span class="metric-unit">台</span>
            </li>
          </ul>
        </section>
      </aside>

      <!-- 中间：地图 -->
      <main class="map-wrap">
        <div ref="mapRef" class="map-canvas"></div>
        <div class="map-tip">地图上的圆点代表医院，大小对应在管患者数；悬停看名称，点击看详情</div>
      </main>

      <!-- 右侧：选中医院 + 预警 -->
      <aside class="col">
        <section class="card sel-card" v-if="selected">
          <div class="card-title">
            <span class="bar"></span>
            <el-icon class="ct-icon"><FirstAidKit /></el-icon>{{ selected.name }}
          </div>
          <p class="sel-meta">{{ selected.city }} · {{ selected.level }}</p>
          <ul class="sel-stats">
            <li><span>在管患者</span><b>{{ selected.patients }}</b></li>
            <li><span>待处理预警</span><b class="danger">{{ selected.warnings }}</b></li>
            <li><span>在线设备</span><b>{{ selected.devices }}<em>/{{ selected.devices + selected.offline }}</em></b></li>
          </ul>
        </section>

        <section class="card">
          <div class="card-title">
            <span class="bar"></span>
            <el-icon class="ct-icon"><AlarmClock /></el-icon>全省待处理预警
          </div>
          <ul class="alert-list">
            <li v-for="a in topAlerts" :key="a.name">
              <span class="dot" :class="a.level === 3 ? 'hot' : 'mid'"></span>
              <span class="alert-name">{{ a.name }}</span>
              <span class="alert-count">{{ a.count }}</span>
            </li>
          </ul>
        </section>
      </aside>
    </div>

    <!-- 底部 KPI -->
    <footer class="kpi-row">
      <div class="kpi" v-for="k in kpis" :key="k.label">
        <div class="ring" :style="{ '--v': k.value + '%', '--c': k.color }">
          <span>{{ k.value }}%</span>
        </div>
        <div class="kpi-text">
          <b>{{ k.label }}</b>
          <span>{{ k.desc }}</span>
        </div>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, shallowRef } from 'vue'
import * as echarts from 'echarts'
import guizhou from '@/assets/geo/guizhou.json'
import { CDMS_THEME, brandColor } from '@/utils/echartsTheme'

/* ---------------------------------------------------------------
   演示数据：9 个市州、12 家医院。
   坐标用各个市州的实际中心点附近（GCJ-02），仅用于大屏展示，
   不用于导航定位。接入真实数据时替换 hospitals 即可。
   --------------------------------------------------------------- */
const hospitals = ref([
  { name: '贵州省人民医院', city: '贵阳市', level: '三级甲等', lng: 106.7245, lat: 26.5845, patients: 2860, warnings: 42, devices: 186, offline: 9 },
  { name: '贵阳市第一人民医院', city: '贵阳市', level: '三级甲等', lng: 106.6302, lat: 26.6470, patients: 2180, warnings: 31, devices: 142, offline: 6 },
  { name: '遵义医科大学附属医院', city: '遵义市', level: '三级甲等', lng: 106.9270, lat: 27.7250, patients: 1960, warnings: 28, devices: 128, offline: 5 },
  { name: '遵义市第一人民医院', city: '遵义市', level: '三级甲等', lng: 106.9169, lat: 27.6712, patients: 1240, warnings: 17, devices: 86, offline: 4 },
  { name: '六盘水市人民医院', city: '六盘水市', level: '三级甲等', lng: 104.8467, lat: 26.5846, patients: 980, warnings: 14, devices: 64, offline: 3 },
  { name: '安顺市人民医院', city: '安顺市', level: '三级甲等', lng: 105.9322, lat: 26.2455, patients: 870, warnings: 12, devices: 58, offline: 2 },
  { name: '毕节市第一人民医院', city: '毕节市', level: '三级甲等', lng: 105.2850, lat: 27.3017, patients: 1120, warnings: 19, devices: 72, offline: 5 },
  { name: '铜仁市人民医院', city: '铜仁市', level: '三级甲等', lng: 109.1916, lat: 27.7183, patients: 760, warnings: 11, devices: 48, offline: 3 },
  { name: '黔西南州人民医院', city: '黔西南布依族苗族自治州', level: '三级甲等', lng: 104.8979, lat: 25.0881, patients: 690, warnings: 9, devices: 44, offline: 2 },
  { name: '黔东南州人民医院', city: '黔东南苗族侗族自治州', level: '三级甲等', lng: 107.9775, lat: 26.5834, patients: 820, warnings: 13, devices: 52, offline: 4 },
  { name: '黔南州人民医院', city: '黔南布依族苗族自治州', level: '三级甲等', lng: 107.5172, lat: 26.2582, patients: 740, warnings: 10, devices: 46, offline: 2 },
  { name: '贵阳市公共卫生救治中心', city: '贵阳市', level: '三级乙等', lng: 106.6800, lat: 26.5600, patients: 460, warnings: 6, devices: 28, offline: 1 }
])

const selected = ref(hospitals.value[0])
const nowText = ref('')
let timer = null
const pad = (n) => String(n).padStart(2, '0')
const tick = () => {
  const d = new Date()
  nowText.value = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

/* 市州聚合（名称过长时取简称） */
const cityRank = computed(() => {
  const map = new Map()
  hospitals.value.forEach((h) => {
    const short = h.city.replace(/布依族苗族自治州|苗族侗族自治州|布依族苗族自治州/, '').replace(/市$/, '')
    const cur = map.get(short) || { name: h.city, short, patients: 0 }
    cur.patients += h.patients
    map.set(short, cur)
  })
  const list = [...map.values()].sort((a, b) => b.patients - a.patients)
  const max = list[0] ? list[0].patients : 1
  return list.map((c) => ({ ...c, pct: Math.round((c.patients / max) * 100) }))
})

const levelStats = computed(() => {
  const map = new Map()
  hospitals.value.forEach((h) => map.set(h.level, (map.get(h.level) || 0) + 1))
  return [...map.entries()].map(([name, count]) => ({ name, count }))
})

const statusStats = computed(() => {
  const online = hospitals.value.reduce((s, h) => s + h.devices, 0)
  const offline = hospitals.value.reduce((s, h) => s + h.offline, 0)
  return [
    { name: '在线设备', count: online, tone: 'ok' },
    { name: '离线设备', count: offline, tone: 'warn' }
  ]
})

const topAlerts = computed(() =>
  [...hospitals.value].sort((a, b) => b.warnings - a.warnings).slice(0, 6)
    .map((h) => ({ name: h.name, count: h.warnings, level: h.warnings > 25 ? 3 : 2 }))
)

const kpis = [
  { label: '血压达标率', value: 76, desc: '近 7 日有监测记录人群', color: '#00a8a0' },
  { label: '血糖达标率', value: 68, desc: '空腹血糖 < 7.0 mmol/L', color: '#4fa96a' },
  { label: '预警处置率', value: 83, desc: '24 小时内闭环', color: '#e09a3c' },
  { label: '随访完成率', value: 91, desc: '计划内随访完成', color: '#6b7fd7' }
]

/* ------------------------- 地图 ------------------------- */
const mapRef = ref()
const chart = shallowRef(null)

const buildOption = () => {
  const main = brandColor()
  return {
    tooltip: {
      trigger: 'item',
      confine: true,
      backgroundColor: 'rgba(255,255,255,0.96)',
      borderColor: 'rgba(0,168,160,0.3)',
      borderWidth: 1,
      padding: [8, 12],
      textStyle: { color: '#26303a', fontSize: 12 },
      extraCssText: 'box-shadow: 0 8px 24px rgba(16,24,40,.12); border-radius: 6px;',
      formatter: (p) => {
        if (p.seriesType === 'effectScatter') {
          const h = p.data.raw
          return `<b style="font-size:13px">${h.name}</b><br/>
            <span style="color:#93a1ae">${h.city} · ${h.level}</span><br/>
            在管患者 <b>${h.patients}</b> · 待处理预警 <b style="color:#e5645f">${h.warnings}</b>`
        }
        return `<b>${p.name}</b><br/>在管患者 ${(p.value || 0).toLocaleString()}`
      }
    },
    geo: {
      map: 'guizhou',
      roam: false,
      zoom: 1.16,
      layoutCenter: ['50%', '50%'],
      layoutSize: '92%',
      label: {
        show: true,
        fontSize: 10,
        color: '#7d8f9c',
        formatter: (p) => p.name.replace(/布依族苗族自治州|苗族侗族自治州/, '').replace(/市$/, '')
      },
      itemStyle: {
        areaColor: '#eff8f7',
        borderColor: '#a8dcd7',
        borderWidth: 1,
        shadowColor: 'rgba(0,168,160,0.16)',
        shadowBlur: 16,
        shadowOffsetY: 4
      },
      emphasis: {
        label: { show: true, color: '#0b6b66', fontWeight: 600 },
        itemStyle: { areaColor: '#d7efec', borderColor: main, borderWidth: 1.4 }
      },
      select: { itemStyle: { areaColor: '#cdeae6' }, label: { color: '#0b6b66' } }
    },
    series: [
      {
        // 市州填充（用于显示各市在管患者，让地图不是纯色块）
        type: 'map',
        geoIndex: 0,
        name: '市州',
        data: []
      },
      {
        type: 'effectScatter',
        coordinateSystem: 'geo',
        geoIndex: 0,
        // 不设 zlevel：zlevel 会让 ECharts 单独开一层 canvas，
        // 交互命中与层叠顺序都更容易出问题。同层靠后绘制即可压在图形上。
        z: 10,
        symbolSize: (v) => Math.max(9, Math.min(24, Math.sqrt(v[2]) / 2.2)),
        rippleEffect: { brushType: 'stroke', scale: 2.8, period: 3.6 },
        itemStyle: {
          color: main,
          shadowBlur: 12,
          shadowColor: 'rgba(0,168,160,0.55)'
        },
        emphasis: {
          scale: 1.25,
          label: {
            show: true,
            position: 'right',
            formatter: (p) => p.data.raw.name,
            color: '#0b6b66',
            fontSize: 11,
            fontWeight: 600
          }
        },
        data: hospitals.value.map((h) => ({
          name: h.name,
          value: [h.lng, h.lat, h.patients],
          raw: h
        }))
      }
    ]
  }
}

const renderMap = () => {
  if (!mapRef.value) return
  if (!chart.value) chart.value = echarts.init(mapRef.value, CDMS_THEME)
  // 市州数值：聚合到市州名，供 tooltip 与配色使用
  const cityPie = {}
  hospitals.value.forEach((h) => {
    cityPie[h.city] = (cityPie[h.city] || 0) + h.patients
  })
  const opt = buildOption()
  opt.series[0].data = Object.entries(cityPie).map(([name, value]) => ({ name, value }))
  chart.value.setOption(opt, true)
}

const handleClick = (params) => {
  if (params.seriesType === 'effectScatter' && params.data?.raw) {
    selected.value = params.data.raw
  } else if (params.seriesType === 'map' && params.name) {
    const hit = hospitals.value.filter((h) => h.city === params.name)
    if (hit.length) selected.value = hit[0]
  }
}

const onResize = () => chart.value && chart.value.resize()

onMounted(() => {
  echarts.registerMap('guizhou', guizhou)
  renderMap()
  chart.value.on('click', handleClick)
  tick()
  timer = setInterval(tick, 30000)
  window.addEventListener('resize', onResize)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', onResize)
  if (timer) clearInterval(timer)
  if (chart.value) {
    chart.value.dispose()
    chart.value = null
  }
})
</script>

<style scoped>
.screen {
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 14px 16px 16px;
  box-sizing: border-box;
  background:
    radial-gradient(1200px 400px at 50% -10%, rgba(0, 168, 160, 0.08), transparent 70%),
    var(--bg-root);
}

/* 顶部标题条 */
.screen-head {
  flex: none;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 4px;
}
.head-left {
  display: flex;
  align-items: baseline;
  gap: 12px;
}
.head-left h1 {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
  letter-spacing: 1.6px;
  color: var(--t-main);
}
.head-sub {
  font-size: 10px;
  letter-spacing: 2px;
  color: var(--t-dim);
}
.head-right {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 12px;
  color: var(--t-sub);
}
.demo-badge {
  padding: 2px 8px;
  font-size: 11px;
  color: #b26a00;
  background: #fff7e8;
  border: 1px solid #ffe0b2;
  border-radius: 10px;
}
.head-sep {
  width: 1px;
  height: 12px;
  background: var(--line-strong);
}

/* 三栏主体 */
.screen-body {
  flex: 1;
  min-height: 0;
  display: grid;
  grid-template-columns: 258px minmax(0, 1fr) 288px;
  grid-template-rows: minmax(0, 1fr);
  gap: 12px;
}
.col {
  min-height: 0;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.card {
  background: #fff;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 14px 16px;
  box-shadow: 0 1px 2px rgba(16, 24, 40, 0.03);
  overflow: hidden;
}
.card:nth-child(2) {
  flex: 1;
  min-height: 0;
}
.card-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.6px;
  color: var(--t-main);
  margin-bottom: 12px;
}
.card-title .bar {
  width: 3px;
  height: 12px;
  border-radius: 2px;
  background: var(--c-primary);
}
.ct-icon {
  font-size: 14px;
  color: var(--c-primary);
  opacity: 0.85;
}

/* 排行条 */
.rank-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 9px;
}
.rank-list li {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--t-sub);
}
.rank-name {
  width: 52px;
  flex: none;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.rank-track {
  flex: 1;
  height: 6px;
  border-radius: 3px;
  background: #eef2f5;
  overflow: hidden;
}
.rank-track i {
  display: block;
  height: 100%;
  border-radius: 3px;
  background: linear-gradient(90deg, color-mix(in srgb, var(--c-primary) 55%, #fff), var(--c-primary));
}
.rank-val {
  width: 40px;
  flex: none;
  text-align: right;
  font-variant-numeric: tabular-nums;
  color: var(--t-main);
}

/* 指标列表 */
.metric-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.metric-list li {
  display: flex;
  align-items: baseline;
  gap: 8px;
  font-size: 12px;
  color: var(--t-sub);
}
.metric-name {
  flex: 1;
}
.metric-list b {
  font-size: 17px;
  font-weight: 600;
  color: var(--t-main);
  font-variant-numeric: tabular-nums;
}
.metric-list b.ok {
  color: var(--c-success);
}
.metric-list b.warn {
  color: var(--c-warning);
}
.metric-list b.danger {
  color: var(--c-danger);
}
.metric-unit {
  font-size: 11px;
  color: var(--t-dim);
}
.divider {
  height: 1px;
  background: var(--line);
  margin: 12px 0;
}

/* 地图 */
.map-wrap {
  position: relative;
  min-width: 0;
  border-radius: 8px;
  background: #fff;
  border: 1px solid var(--line);
  overflow: hidden;
}
.map-canvas {
  width: 100%;
  height: 100%;
  min-height: 320px;
}
.map-tip {
  position: absolute;
  right: 16px;
  bottom: 12px;
  font-size: 11px;
  color: var(--t-dim);
  pointer-events: none;
}

/* 选中医院 */
.sel-card .sel-meta {
  margin: -4px 0 12px;
  font-size: 12px;
  color: var(--t-dim);
}
.sel-stats {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 9px;
}
.sel-stats li {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  font-size: 12px;
  color: var(--t-sub);
}
.sel-stats b {
  font-size: 16px;
  font-weight: 600;
  color: var(--t-main);
  font-variant-numeric: tabular-nums;
}
.sel-stats b em {
  font-style: normal;
  font-size: 11px;
  color: var(--t-dim);
}
.sel-stats b.danger {
  color: var(--c-danger);
}

/* 预警列表 */
.alert-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.alert-list li {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--t-sub);
}
.alert-list .dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  flex: none;
}
.dot.hot {
  background: var(--c-danger);
}
.dot.mid {
  background: var(--c-warning);
}
.alert-name {
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.alert-count {
  font-variant-numeric: tabular-nums;
  color: var(--t-main);
}

/* 底部 KPI */
.kpi-row {
  flex: none;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
}
.kpi {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 12px 18px;
  background: #fff;
  border: 1px solid var(--line);
  border-radius: 8px;
}
.ring {
  --v: 0;
  --c: var(--c-primary);
  width: 46px;
  height: 46px;
  flex: none;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: conic-gradient(var(--c) calc(var(--v) * 1%), #eef2f5 0);
  position: relative;
}
.ring::after {
  content: '';
  position: absolute;
  inset: 5px;
  border-radius: 50%;
  background: #fff;
}
.ring span {
  position: relative;
  z-index: 1;
  font-size: 12px;
  font-weight: 600;
  color: var(--t-main);
  font-variant-numeric: tabular-nums;
}
.kpi-text {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}
.kpi-text b {
  font-size: 13px;
  font-weight: 600;
  color: var(--t-main);
}
.kpi-text span {
  font-size: 11px;
  color: var(--t-dim);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

@media (max-width: 1360px) {
  .screen-body {
    grid-template-columns: 220px minmax(0, 1fr) 240px;
  }
}
</style>
