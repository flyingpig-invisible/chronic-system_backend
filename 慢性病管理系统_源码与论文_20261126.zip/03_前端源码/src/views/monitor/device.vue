<template>
  <div class="page-container">
    <div class="search-bar">
      <el-form :model="query" inline>
        <el-form-item label="设备">
          <el-input v-model="query.keyword" placeholder="设备编号 / 别名 / 型号" clearable
            style="width:200px" @keyup.enter="handleQuery" />
        </el-form-item>
        <el-form-item label="绑定患者">
          <PatientSelect v-model="query.patientId" width="200px" style="display:inline-block" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :icon="Search" @click="handleQuery">搜索</el-button>
          <el-button :icon="Refresh" @click="resetQuery">重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <div class="stat-row">
      <div class="stat-item">
        <span class="stat-label">在管设备</span>
        <span class="stat-value">{{ total }}</span>
      </div>
      <div class="stat-item">
        <span class="stat-label">数据导入记录</span>
        <span class="stat-value">{{ importTotal }}</span>
      </div>
      <div class="stat-item" style="margin-left:auto">
        <el-button :icon="Tickets" @click="openImportLogs">导入历史</el-button>
      </div>
    </div>

    <div class="table-card">
      <el-table v-loading="loading" :data="list" border stripe>
        <el-table-column prop="btName" label="设备编号" min-width="160" />
        <el-table-column label="设备" width="120">
          <template #default="{ row }">{{ row.alias || row.displayName || '-' }}</template>
        </el-table-column>
        <el-table-column prop="modelName" label="型号" min-width="170" show-overflow-tooltip />
        <el-table-column prop="vendor" label="厂商" width="90" />
        <el-table-column label="绑定患者" width="110">
          <template #default="{ row }">
            <span v-if="row.patientName">{{ row.patientName }}</span>
            <span v-else style="color:#c0c4cc">未绑定</span>
          </template>
        </el-table-column>
        <el-table-column label="在线" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="row.onlineStatus === '1' ? 'success' : 'info'" size="small">
              {{ row.onlineStatus === '1' ? '在线' : '离线' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="电量" width="90" align="center">
          <template #default="{ row }">
            <span :style="{ color: row.battery != null && row.battery < 20 ? '#f56c6c' : '' }">
              {{ row.battery != null ? row.battery + '%' : '-' }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="lastSyncTime" label="最近同步" width="160" />
        <el-table-column label="操作" width="170" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="openMeasures(row)">采集数据</el-button>
            <el-button v-if="row.patientId" type="danger" link size="small" @click="handleUnbind(row)">强制解绑</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination">
        <el-pagination v-model:current-page="query.pageNum" v-model:page-size="query.pageSize"
          :page-sizes="[10, 20, 50]" :total="total" layout="total, sizes, prev, pager, next, jumper"
          @size-change="loadList" @current-change="loadList" />
      </div>
    </div>

    <!-- 设备采集数据 -->
    <el-drawer v-model="measureVisible" :title="`采集数据 · ${currentDevice.alias || currentDevice.btName || ''}`" size="560px">
      <el-table v-loading="measureLoading" :data="measures" size="small" border max-height="600">
        <el-table-column prop="indicatorName" label="指标" width="110" />
        <el-table-column prop="value" label="数值" width="90" />
        <el-table-column prop="unit" label="单位" width="80" />
        <el-table-column prop="measureTime" label="采集时间" min-width="150" />
      </el-table>
      <el-empty v-if="!measureLoading && !measures.length" description="该设备暂无采集数据" :image-size="70" />
    </el-drawer>

    <!-- 导入历史 -->
    <el-dialog v-model="importVisible" title="设备数据导入历史" width="860px">
      <el-table v-loading="importLoading" :data="importLogs" size="small" border max-height="480">
        <el-table-column prop="patientName" label="患者" width="90" />
        <el-table-column prop="fileName" label="文件" min-width="150" show-overflow-tooltip />
        <el-table-column prop="fileType" label="类型" width="70" />
        <el-table-column prop="totalRows" label="总行数" width="90" align="right" />
        <el-table-column prop="parsedPoints" label="解析点数" width="100" align="right" />
        <el-table-column prop="skipDupRows" label="去重" width="80" align="right" />
        <el-table-column prop="failedRows" label="失败" width="80" align="right" />
        <el-table-column prop="successRows" label="成功" width="80" align="right" />
      </el-table>
      <el-empty v-if="!importLoading && !importLogs.length" description="暂无导入记录" :image-size="70" />
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Refresh, Tickets } from '@element-plus/icons-vue'
import { pageDevice, listDeviceMeasures, forceUnbindDevice, listImportLogs } from '@/api/device'

const loading = ref(false)
const list = ref([])
const total = ref(0)
const boundTotal = ref(0)
const importTotal = ref(0)

const query = reactive({ pageNum: 1, pageSize: 10, keyword: '', patientId: null })

const measureVisible = ref(false)
const measureLoading = ref(false)
const measures = ref([])
const currentDevice = ref({})

const importVisible = ref(false)
const importLoading = ref(false)
const importLogs = ref([])

const loadList = async () => {
  loading.value = true
  try {
    const res = await pageDevice(query)
    const d = res.data || {}
    list.value = d.rows || []
    total.value = d.total || 0
    boundTotal.value = list.value.filter((i) => i.patientId).length
  } finally {
    loading.value = false
  }
}

const loadImportTotal = async () => {
  try {
    const res = await listImportLogs({ pageNum: 1, pageSize: 1 })
    importTotal.value = res.data?.total || 0
  } catch (e) {
    importTotal.value = 0
  }
}

const handleQuery = () => {
  query.pageNum = 1
  loadList()
}

const resetQuery = () => {
  Object.assign(query, { pageNum: 1, pageSize: 10, keyword: '', patientId: null })
  loadList()
}

const openMeasures = async (row) => {
  currentDevice.value = row
  measureVisible.value = true
  measureLoading.value = true
  measures.value = []
  try {
    // 后端该接口只支持 limit，没有分页
    const res = await listDeviceMeasures(row.deviceId, { limit: 100 })
    const d = res.data
    measures.value = Array.isArray(d) ? d : (d?.rows || [])
  } finally {
    measureLoading.value = false
  }
}

const handleUnbind = async (row) => {
  try {
    await ElMessageBox.confirm(
      `确定将设备「${row.alias || row.btName}」从患者「${row.patientName}」解绑吗？解绑后设备可重新分配给其他患者。`,
      '强制解绑',
      { type: 'warning', confirmButtonText: '确定解绑', cancelButtonText: '取消' }
    )
  } catch (e) {
    return
  }
  const res = await forceUnbindDevice(row.deviceId)
  if (res.code === 200) {
    ElMessage.success('已解绑')
    loadList()
  } else {
    ElMessage.error(res.msg || '解绑失败')
  }
}

const openImportLogs = async () => {
  importVisible.value = true
  importLoading.value = true
  importLogs.value = []
  try {
    const res = await listImportLogs({ pageNum: 1, pageSize: 50 })
    const d = res.data
    importLogs.value = Array.isArray(d) ? d : (d?.rows || [])
  } finally {
    importLoading.value = false
  }
}

onMounted(() => {
  loadList()
  loadImportTotal()
})
</script>

<style scoped>
.stat-row {
  display: flex;
  align-items: center;
  gap: 32px;
  background: #fff;
  border-radius: 8px;
  padding: 14px 20px;
  margin-bottom: 12px;
}
.stat-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.stat-label {
  font-size: 12px;
  color: #909399;
}
.stat-value {
  font-size: 22px;
  font-weight: 600;
  color: #303133;
}
.stat-value.bound {
  color: var(--c-primary);
}
.pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}
</style>
