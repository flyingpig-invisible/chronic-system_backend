<template>
  <div class="report-page">
    <!-- ============ 工具条（打印时隐藏） ============ -->
    <div class="rp-toolbar no-print">
      <div class="tb-left">
        <el-select
          v-model="patientId"
          filterable
          clearable
          placeholder="选择患者"
          style="width: 200px"
          @change="onPatientChange"
        >
          <el-option
            v-for="p in patients"
            :key="p.patientId"
            :label="`${p.name}（${p.patientNo || p.patientId}）`"
            :value="p.patientId"
          />
        </el-select>

        <el-select v-model="days" style="width: 120px" @change="generate">
          <el-option label="近 7 天" :value="7" />
          <el-option label="近 30 天" :value="30" />
          <el-option label="近 90 天" :value="90" />
          <el-option label="近 180 天" :value="180" />
        </el-select>

        <el-button type="primary" :loading="loading" :disabled="!patientId" @click="generate">
          <el-icon><MagicStick /></el-icon>生成报告
        </el-button>

        <span class="tb-sep"></span>

        <el-switch v-model="editMode" active-text="编辑模式" :disabled="!report" />
        <el-button v-if="report" text @click="resetEdits">
          <el-icon><RefreshLeft /></el-icon>恢复生成内容
        </el-button>
      </div>

      <div class="tb-right">
        <el-button :disabled="!report" @click="exportPdf">
          <el-icon><Printer /></el-icon>导出 PDF
        </el-button>
      </div>
    </div>

    <div v-if="report" class="rp-hint no-print">
      导出方式：点击「导出 PDF」后在打印窗口的「目标打印机」中选择 <b>另存为 PDF</b>，
      纸张 A4、边距默认即可。这样导出的 PDF 文字可选可搜索，不是图片。
    </div>

    <!-- ============ 纸张 ============ -->
    <div class="rp-stage">
      <article v-if="report" class="paper">
        <!-- 报头（公文式） -->
        <header class="paper-head">
          <p class="org-line">慢性病管理系统 · 健康管理中心</p>
          <div class="org-rule"></div>
          <h1 :contenteditable="editMode" class="doc-title" @blur="onEdit($event, null, 'title')">
            {{ title }}
          </h1>
          <p class="doc-meta">
            报告编号 {{ report.reportNo }}　｜　统计窗口 {{ report.period.start }} 至
            {{ report.period.end }}（{{ report.period.days }} 天）　｜　生成时间 {{ report.generatedAt }}
          </p>
        </header>

        <!-- 患者信息：公文抬头称呼 -->
        <p class="salutation">
          {{ report.patient.name }}（{{ report.patient.genderName }}，{{ report.patient.age }} 岁）
          <span class="sal-sub">
            档案号 {{ report.patient.patientNo || '-' }}｜联系电话 {{ report.patient.phone || '-' }}｜主管医生
            {{ report.patient.doctorName || '-' }}｜科室 {{ report.patient.deptName || '-' }}
          </span>：
        </p>
        <p class="body-p">依据系统预警规则与统计窗口内的监测记录，现对该患者慢病管理情况评估如下。已登记诊断病种：<b v-if="report.patient.diseases.length">{{ report.patient.diseases.map((d) => d.name).join('、') }}</b><span v-else>未登记</span>。</p>

        <!-- 摘要 -->
        <section class="sec">
          <h2><span class="sec-no">一</span>评估摘要</h2>
          <p class="body-p">统计窗口内共采集监测记录 <b>{{ report.summary.measureCount }}</b> 条，覆盖 <b>{{ report.summary.indicatorCount }}</b> 项指标；按系统评分模型计算，健康评分 <b>{{ report.score ? report.score.healthScore : '-' }}</b> 分，健康等级为<b>{{ report.summary.healthLevelName }}</b>。本次评估级别为<b>{{ report.summary.assessName }}</b>，<b>{{ report.summary.abnormalIndicatorCount }}</b> 项指标超出参考范围；期间触发预警 <b>{{ report.summary.warningCount }}</b> 条，其中待处理 <b>{{ report.summary.pendingWarningCount }}</b> 条。</p>
          <p class="body-p">数据完整度：最后一条监测记录为 <b>{{ report.summary.lastMeasureTime || '无' }}</b><i v-if="report.summary.lastMeasureTime && !report.summary.lastMeasureInWindow">（该记录在统计窗口之外，窗口内无数据）</i>；达标判定依据系统启用的 <b>{{ report.summary.ruleCount }}</b> 条预警规则，全部原始依据见「八、依据清单」。</p>
        </section>

        <!-- 结论 -->
        <section class="sec">
          <h2><span class="sec-no">二</span>主要结论</h2>
          <p class="sec-tip no-print" v-if="editMode">可直接点击结论文字修改，改完点空白处生效。</p>
          <ol class="concl-list">
            <li v-for="c in report.conclusions" :key="c.no" class="concl">
              <p class="cc-head">
                <b class="cc-title" :contenteditable="editMode" @blur="onEdit($event, c, 'title')">{{
                  c.title
                }}</b>
                <span v-if="!String(c.title).includes(c.badge || c.levelName)" class="cc-badge">（{{ c.badge || c.levelName }}）</span>
              </p>
              <p class="cc-text" :contenteditable="editMode" @blur="onEdit($event, c, 'text')">
                {{ c.text }}
              </p>
              <p class="cc-ev">
                判断依据：<span
                  v-for="e in c.evidenceNos"
                  :key="e"
                  class="ev-chip"
                  :title="evText(e)"
                  >{{ e }}</span
                >
              </p>
            </li>
          </ol>
        </section>

        <!-- 指标明细 -->
        <section class="sec">
          <h2><span class="sec-no">三</span>指标明细</h2>
          <table class="data-table">
            <thead>
              <tr>
                <th style="width: 15%">指标</th>
                <th style="width: 10%">采集次数</th>
                <th style="width: 10%">均值</th>
                <th style="width: 20%">最低 ～ 最高</th>
                <th style="width: 23%">参考范围（规则推导）</th>
                <th style="width: 11%">达标率</th>
                <th style="width: 11%">判定</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="i in report.indicators" :key="i.code" :class="i.count ? '' : 'row-empty'">
                <td>{{ i.name }}<i class="unit" v-if="i.unit">（{{ i.unit }}）</i></td>
                <td>{{ i.count }}</td>
                <td>{{ i.count ? i.avg : '-' }}</td>
                <td>{{ i.count ? (i.min === i.max ? i.min : `${i.min} ～ ${i.max}`) : '-' }}</td>
                <td>{{ i.targetText }}</td>
                <td>{{ i.rate === null ? '-' : i.rate + '%' }}</td>
                <td>
                  <span class="st" :class="'lv' + i.level">{{ i.status }}</span>
                </td>
              </tr>
            </tbody>
          </table>
        </section>

        <!-- 超标记录 -->
        <section class="sec" v-if="abnormalRows.length">
          <h2><span class="sec-no">四</span>超标记录明细</h2>
          <p class="sec-desc">
            以下记录是「二、主要结论」的原始出处：每条记录都注明了命中的规则编号与阈值描述，可逐条核对。
          </p>
          <table class="data-table">
            <thead>
              <tr>
                <th style="width: 22%">测量时间</th>
                <th>指标</th>
                <th>数值</th>
                <th style="width: 34%">命中规则</th>
                <th>级别</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(r, idx) in abnormalRows" :key="idx">
                <td>{{ r.time }}</td>
                <td>{{ r.indicator }}</td>
                <td>{{ r.value }} {{ r.unit }}</td>
                <td>#{{ r.ruleId }}《{{ r.ruleName }}》{{ r.thresholdDesc }}</td>
                <td><span class="st" :class="'lv' + r.level">{{ lvName(r.level) }}</span></td>
              </tr>
            </tbody>
          </table>
        </section>

        <!-- 预警 -->
        <section class="sec">
          <h2><span class="sec-no">五</span>预警与处置</h2>
          <template v-if="report.warnings.total">
            <p class="sec-desc">
              窗口内共触发 <b>{{ report.warnings.total }}</b> 条预警：高危
              <b>{{ report.warnings.highRisk }}</b>、中危
              <b>{{ report.warnings.midRisk }}</b>、低危
              <b>{{ report.warnings.lowRisk }}</b>；处置状态为待处理
              <b>{{ report.warnings.pending }}</b>、处理中
              <b>{{ report.warnings.handling }}</b>、已处理
              <b>{{ report.warnings.handled }}</b>。
            </p>
            <p class="sec-actions no-print">
              <el-button
                v-if="report.warnings.pending"
                link
                type="primary"
                size="small"
                @click="goWarnings({ handleStatus: '0' })"
              >去处理这 {{ report.warnings.pending }} 条待处理预警 →</el-button>
              <el-button
                v-if="report.warnings.highRisk"
                link
                type="primary"
                size="small"
                @click="goWarnings({ warningLevel: '3' })"
              >查看全部高危预警 →</el-button>
              <el-button link size="small" @click="goWarnings({})">查看该患者全部预警 →</el-button>
            </p>
            <table class="data-table">
              <thead>
                <tr>
                  <th style="width: 22%">触发时间</th>
                  <th>指标 / 数值</th>
                  <th style="width: 30%">触发条件</th>
                  <th>级别</th>
                  <th>处置状态</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="w in report.warnings.items" :key="w.warningId">
                  <td>{{ w.triggerTime }}</td>
                  <td>{{ w.indicatorName }} {{ w.value }} {{ w.unit }}</td>
                  <td>{{ w.thresholdDesc }}</td>
                  <td><span class="st" :class="'lv' + w.level">{{ lvName(w.level) }}</span></td>
                  <td>{{ w.handleStatusName }}</td>
                </tr>
              </tbody>
            </table>
            <p class="sec-foot" v-if="report.warnings.total > report.warnings.items.length">
              仅列出最近 {{ report.warnings.items.length }} 条，完整记录见系统预警中心。
            </p>
          </template>
          <p v-else class="sec-desc">窗口期内未触发预警。</p>
        </section>

        <!-- 评分构成 -->
        <section class="sec" v-if="report.score">
          <h2><span class="sec-no">六</span>健康评分构成</h2>
          <p class="sec-desc">
            评分时间 {{ report.score.calcTime }}（{{ report.score.triggerName }}），
            综合得分 <b>{{ report.score.healthScore }}</b> 分，健康等级 <b>{{ report.score.healthLevelName }}</b>。
          </p>
          <table class="data-table">
            <thead>
              <tr>
                <th style="width: 22%">评分项</th>
                <th>公式</th>
                <th>得分</th>
                <th>权重</th>
                <th>贡献</th>
                <th style="width: 32%">计算说明</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(it, idx) in report.score.items" :key="idx">
                <td>{{ it.name }}</td>
                <td>{{ it.formula }}</td>
                <td>{{ it.value }}</td>
                <td>{{ it.weight }}</td>
                <td>{{ it.contribution }}</td>
                <td class="desc-cell">{{ it.desc }}</td>
              </tr>
            </tbody>
          </table>
        </section>

        <!-- 建议 -->
        <section class="sec">
          <h2><span class="sec-no">七</span>管理建议</h2>
          <ol class="sug-list">
            <li v-for="(s, idx) in report.suggestions" :key="idx">
              <span class="sug-text" :contenteditable="editMode" @blur="onEdit($event, s, 'text')">
                {{ s.text }}
              </span>
              <span class="sug-basis">依据：{{ s.basis }}</span>
            </li>
          </ol>
        </section>

        <!-- 依据清单 -->
        <section class="sec">
          <h2><span class="sec-no">八</span>依据清单</h2>
          <p class="sec-desc">
            下表逐条列出报告中引用的全部原始依据，编号与正文中的上标一一对应。
            来源为「预警记录」的行可直接点「去核对」，跳到预警列表定位到该条记录。
          </p>
          <table class="data-table ev-table">
            <thead>
              <tr>
                <th style="width: 8%">编号</th>
                <th style="width: 15%">来源</th>
                <th>内容</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="e in report.evidence" :key="e.no">
                <td><b>{{ e.no }}</b></td>
                <td>{{ e.source }}</td>
                <td class="desc-cell">
                  {{ e.detail
                  }}<el-button
                    v-if="e.refWarningId"
                    class="ev-locate no-print"
                    link
                    type="primary"
                    size="small"
                    @click="goWarningItem(e.refWarningId)"
                  >去核对 →</el-button>
                  <el-button
                    v-else-if="e.source === '监测记录'"
                    class="ev-locate no-print"
                    link
                    type="primary"
                    size="small"
                    @click="goMeasures(e.refIndicator)"
                  >查记录 →</el-button>
                </td>
              </tr>
            </tbody>
          </table>
        </section>

        <!-- 医师意见 -->
        <section class="sec">
          <h2><span class="sec-no">九</span>医师意见</h2>
          <div
            class="doctor-note"
            :class="{ editing: editMode }"
            :contenteditable="editMode"
            @blur="onEdit($event, null, 'doctorNote')"
          >{{ doctorNote }}</div>
          <p class="sec-tip no-print" v-if="editMode">开启编辑模式后可直接在此处书写，内容会一起导出。</p>
          <p class="sec-tip no-print" v-else-if="noteIsDefault">
            以上意见由报告结论自动预填，开启编辑模式核改后再导出。
          </p>
        </section>

        <!-- 声明与签名 -->
        <section class="sec notes">
          <h2><span class="sec-no">十</span>报告说明</h2>
          <ul class="note-list">
            <li v-for="(n, i) in report.notes" :key="i">{{ n }}</li>
          </ul>
        </section>

        <footer class="paper-foot">
          <p class="sign-org">慢性病管理系统 · 健康管理中心</p>
          <p class="sign-date">{{ report.generatedAt }}</p>
        </footer>
      </article>

      <el-empty v-if="!report" description="请选择患者后生成健康报告" />
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { listPatient } from '@/api/patient'
import { getHealthReport } from '@/api/report'

const route = useRoute()
const router = useRouter()
const patients = ref([])
const patientId = ref(null)
const days = ref(30)
const loading = ref(false)
const editMode = ref(false)
const report = ref(null)
const title = ref('患者健康状况评估报告')
const doctorNote = ref('')

/** 生成时的原始内容快照，用于「恢复生成内容」 */
let snapshot = null
/** 系统预填的医师意见，用于「恢复生成内容」时还原 */
let defaultNote = ''

const noteIsDefault = computed(() => !!doctorNote.value && doctorNote.value === defaultNote)

const lvName = (lv) => (lv >= 3 ? '高危' : lv === 2 ? '中危' : lv === 1 ? '低危' : '正常')

const evText = (no) => {
  const e = (report.value?.evidence || []).find((x) => x.no === no)
  return e ? `【${e.source}】${e.detail}` : ''
}

/** 把各指标的越界样本拍平，按级别+时间排序，最多 12 条 */
const abnormalRows = computed(() => {
  if (!report.value) return []
  const rows = []
  report.value.indicators.forEach((i) => {
    ;(i.samples || []).forEach((s) => {
      const top = (s.rules || [])[s.rules.length - 1]
      if (!top) return
      rows.push({
        time: s.time,
        indicator: i.name,
        value: s.value,
        unit: i.unit,
        level: s.level,
        ruleId: top.ruleId,
        ruleName: top.ruleName,
        thresholdDesc: top.thresholdDesc
      })
    })
  })
  rows.sort((a, b) => b.level - a.level || String(b.time).localeCompare(String(a.time)))
  return rows.slice(0, 12)
})

const loadPatients = async () => {
  try {
    const res = await listPatient({ pageNum: 1, pageSize: 200 })
    patients.value = res.rows || res.data?.rows || res.data || []
  } catch (e) {
    patients.value = []
  }
}

/**
 * 按报告结论预填一段医师意见，医生在此基础改。
 * 依据都来自报告自身的 suggestions（本身就是规则动作 + 严重度排序），
 * 所以预填内容与前面的结论是同源的，不会出现"上面说高危、下面写一切正常"。
 */
const splitAction = (text) => {
  const t = String(text || '')
  const i = t.indexOf('：')
  return i > 0 ? [t.slice(0, i), t.slice(i + 1)] : [t, '']
}

/** 同一句处置动作合并主语，避免"心率：联系急救；舒张压：联系急救"这种重复 */
const groupByAction = (list) => {
  const map = new Map()
  list.forEach((s) => {
    const [name, act] = splitAction(s.text)
    const key = act || name
    if (!map.has(key)) map.set(key, { names: [], act })
    if (act) map.get(key).names.push(name)
  })
  return [...map.values()].map((g) => (g.act ? `${g.names.join('、')}：${g.act}` : g.names.join('、')))
}

const buildDoctorNote = (data) => {
  if (!data) return ''
  const sugs = data.suggestions || []
  const acts = sugs.filter((s) => !String(s.text).startsWith('复评安排'))
  const isLoop = (s) => String(s.text).startsWith('预警闭环')
  const high = groupByAction(acts.filter((s) => Number(s.priority) >= 3 && !isLoop(s)))
  const loop = acts.filter(isLoop).map((s) => s.text)
  const rest = groupByAction(acts.filter((s) => Number(s.priority) < 3))
  const period = sugs.find((s) => String(s.text).startsWith('复评安排'))

  const parts = []
  if (high.length) {
    parts.push(`${high.join('；')}。已电话核实并安排当日复诊`)
  }
  if (loop.length) {
    parts.push(loop.join('；'))
  }
  if (rest.length) {
    parts.push(`${rest.join('；')}。予饮食与作息指导，纳入常规随访`)
  }
  if (!parts.length) {
    if (!data.summary || data.summary.measureCount === 0) {
      parts.push('本次统计窗口内无监测数据，无法评估病情，请先联系患者恢复数据上传')
    } else {
      parts.push('本次评估未见指标超出参考范围，维持现有方案，按期随访')
    }
  }
  if (period) {
    parts.push(period.text.replace(/^复评安排：建议\s*/, '建议 '))
  }
  // 每条独立成行（公文式分条），用全角空格做首行缩进，不再靠 CSS text-indent
  return parts.map((p, i) => `　　${i + 1}）${p.replace(/。$/, '')}。`).join('\n')
}

const generate = async () => {
  if (!patientId.value) return
  loading.value = true
  try {
    const res = await getHealthReport(patientId.value, days.value)
    const data = res.data || res
    report.value = data
    title.value = '患者健康状况评估报告'
    defaultNote = buildDoctorNote(data)
    doctorNote.value = defaultNote
    snapshot = JSON.parse(JSON.stringify(data))
    ElMessage.success(`报告已生成：${data.conclusions.length} 条结论、${data.evidence.length} 条依据`)
  } catch (e) {
    ElMessage.error('报告生成失败，请确认该患者有权限访问')
  } finally {
    loading.value = false
  }
}

const onPatientChange = () => {
  report.value = null
  generate()
}

/** 从报告跳到预警列表并带上筛选条件，形成"看结论 → 去处置"的闭环 */
const goWarnings = (extra = {}) => {
  router.push({
    path: '/warning/list',
    query: { patientId: patientId.value, ...extra }
  })
}

/** 依据清单里「去核对」：跳到预警列表并定位到引用那一条 */
const goWarningItem = (warningId) => {
  router.push({
    path: '/warning/list',
    query: { patientId: patientId.value, warningId }
  })
}

/** 依据清单里「查记录」：跳到监测数据页，带上该指标则只看这一项，否则看该患者全部记录 */
const goMeasures = (indicatorCode) => {
  const query = { patientId: patientId.value }
  if (indicatorCode) query.indicatorCode = indicatorCode
  router.push({ path: '/monitor/measure', query })
}

/** contenteditable 失焦回写 */
const onEdit = (e, target, field) => {
  if (!editMode.value) return
  const val = (e.target.innerText || '').trim()
  if (field === 'title') {
    title.value = val || '患者健康状况评估报告'
  } else if (field === 'doctorNote') {
    doctorNote.value = val
  } else if (target && field) {
    target[field] = val
  }
}

const resetEdits = () => {
  if (!snapshot) return
  report.value = JSON.parse(JSON.stringify(snapshot))
  title.value = '患者健康状况评估报告'
  doctorNote.value = defaultNote
  ElMessage.info('已恢复为系统生成内容')
}

const exportPdf = () => {
  if (!report.value) return
  ElMessage({
    message: '在打印窗口的「目标打印机」中选择「另存为 PDF」即可保存',
    type: 'success',
    duration: 3500
  })
  setTimeout(() => window.print(), 260)
}

onMounted(async () => {
  await loadPatients()
  const qp = route.query.patientId
  if (qp) {
    patientId.value = Number(qp)
    generate()
  } else if (patients.value.length) {
    patientId.value = patients.value[0].patientId
    generate()
  }
})
</script>

<style scoped>
/* ===================================================================
   公文式报告版式：白底黑字、宋体、全框线表格，不设彩色标签。
   唯一的彩色是报头的机构名称与红色横线，与参考件保持一致。
   =================================================================== */
.report-page {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  gap: 10px;
}

/* ================= 工具条 ================= */
.rp-toolbar {
  flex: none;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 10px 14px;
  background: #fff;
  border: 1px solid var(--line);
  border-radius: 6px;
}
.tb-left,
.tb-right {
  display: flex;
  align-items: center;
  gap: 10px;
}
.tb-sep {
  width: 1px;
  height: 18px;
  background: var(--line-strong);
}
.rp-hint {
  flex: none;
  padding: 7px 12px;
  font-size: 12px;
  color: #4a4a4a;
  background: #f7f7f7;
  border: 1px solid #e2e2e2;
  border-radius: 4px;
}
.rp-hint b {
  color: #000;
}

/* ================= 舞台与纸张 ================= */
.rp-stage {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  display: flex;
  justify-content: center;
  padding: 0 0 24px;
}
.paper {
  width: 794px; /* A4 @96dpi */
  min-height: 1123px;
  box-sizing: border-box;
  padding: 24mm 20mm 20mm;
  background: #fff;
  border: 1px solid #dcdcdc;
  box-shadow: 0 2px 14px rgba(0, 0, 0, 0.08);
  color: #000;
  font-family: 'SimSun', '宋体', 'Songti SC', 'STSong', serif;
  font-size: 13px;
  line-height: 1.9;
}

/* 报头 */
.paper-head {
  text-align: center;
}
.org-line {
  margin: 0;
  font-size: 17px;
  font-weight: 700;
  letter-spacing: 3px;
  color: #c8161d;
}
.org-rule {
  height: 0;
  margin: 9px 0 0;
  padding-top: 2px;
  border-top: 2.5px solid #c8161d;
  border-bottom: 1px solid #c8161d;
}
.doc-title {
  margin: 24px 0 10px;
  font-size: 21px;
  font-weight: 700;
  line-height: 1.6;
  letter-spacing: 2px;
  outline: none;
}
.doc-meta {
  margin: 0;
  font-size: 10.5px;
  color: #444;
  line-height: 1.7;
}

/* 抬头称呼 */
.salutation {
  margin: 22px 0 4px;
  font-size: 13.5px;
  text-align: justify;
}
.sal-sub {
  font-size: 11px;
  color: #555;
}

/* 正文段 */
.body-p {
  margin: 0 0 6px;
  text-indent: 2em;
  text-align: justify;
}
.body-p b {
  font-weight: 700;
}
.body-p i {
  font-style: normal;
  color: #555;
}

/* ================= 章节 ================= */
.sec {
  margin-top: 16px;
}
.sec h2 {
  margin: 0 0 8px;
  font-size: 15px;
  font-weight: 700;
  line-height: 1.8;
  letter-spacing: 0.5px;
  break-after: avoid;
}
.sec-no::after {
  content: '、';
}
.sec-desc,
.sec-tip {
  margin: 0 0 8px;
  font-size: 11.5px;
  color: #444;
  text-indent: 0;
}
.sec-tip {
  color: #666;
}
.sec-actions {
  margin: -2px 0 8px;
}
.sec-actions .el-button + .el-button {
  margin-left: 14px;
}
/* 依据行末的「去核对」：跟正文同一行，不另起一段 */
.ev-locate {
  margin-left: 8px;
  vertical-align: baseline;
}
.ev-locate-dash {
  color: #bbb;
}

/* ================= 结论 ================= */
.concl-list {
  margin: 0;
  padding-left: 22px;
}
.concl {
  margin-bottom: 10px;
  break-inside: avoid;
}
.cc-head {
  margin: 0;
  font-size: 13px;
  line-height: 1.9;
}
.cc-title {
  font-weight: 700;
  outline: none;
}
.cc-badge {
  font-weight: 400;
  color: #000;
}
.cc-text {
  margin: 0;
  text-indent: 2em;
  text-align: justify;
  outline: none;
}
.cc-ev {
  margin: 2px 0 0;
  font-size: 11px;
  color: #555;
  text-indent: 2em;
}
.ev-chip {
  margin-right: 5px;
  font-family: 'Times New Roman', serif;
  letter-spacing: 0.3px;
}

/* ================= 表格：全框线，灰底表头 ================= */
.data-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 11.5px;
  line-height: 1.7;
  table-layout: fixed;
}
.data-table th,
.data-table td {
  border: 1px solid #333;
  padding: 4px 6px;
  vertical-align: middle;
  word-break: break-all;
  text-align: center;
}
.data-table thead th {
  background: #f0f0f0;
  font-weight: 700;
  white-space: nowrap;
}
.data-table tbody tr {
  break-inside: avoid;
}
.data-table tbody tr.row-empty td {
  color: #888;
}
.data-table .desc-cell {
  text-align: left;
  line-height: 1.7;
}
.unit {
  font-style: normal;
  color: #555;
  font-size: 10.5px;
}
/* 判定/级别一律纯文本，不再用彩色胶囊 */
.st {
  display: inline;
  padding: 0;
  background: none !important;
  color: #000 !important;
  font-size: 11.5px;
  white-space: nowrap;
}
.st.lv3 {
  font-weight: 700;
}

/* ================= 建议 ================= */
.sug-list {
  margin: 0;
  padding-left: 22px;
}
.sug-list li {
  margin-bottom: 7px;
  break-inside: avoid;
  text-align: justify;
}
.sug-text {
  outline: none;
}
.sug-basis {
  display: block;
  font-size: 11px;
  color: #555;
}

/* ================= 医师意见 ================= */
.doctor-note {
  min-height: 84px;
  padding: 8px 10px;
  border: 1px solid #333;
  line-height: 1.95;
  text-align: justify;
  outline: none;
  white-space: pre-wrap;
}
.doctor-note.editing {
  background: #fcfcf7;
}

/* ================= 说明 ================= */
.note-list {
  margin: 0;
  padding-left: 22px;
  font-size: 11.5px;
  color: #333;
}
.note-list li {
  margin-bottom: 4px;
  text-align: justify;
}
.notes .note-list li {
  break-inside: avoid;
}

/* 落款（右对齐） */
.paper-foot {
  margin-top: 26px;
  text-align: right;
  line-height: 1.9;
}
.sign-org {
  margin: 0;
  font-size: 13px;
}
.sign-date {
  margin: 0;
  font-size: 13px;
}

/* 打印页脚由导出时（CDP / 浏览器页眉页脚）提供，页面内不重复渲染 */

/* 编辑态提示：可编辑区淡灰底 */
.paper :deep([contenteditable='true']:hover) {
  background: #f7f7f2;
  outline: 1px dashed #b9b9a8;
}

/* ================= 打印 ================= */
@media print {
  :global(html),
  :global(body),
  :global(#app),
  :global(.layout),
  :global(.right-wrap),
  :global(.main) {
    height: auto !important;
    min-height: 0 !important;
    overflow: visible !important;
    padding: 0 !important;
    margin: 0 !important;
    background: #fff !important;
  }
  :global(.aside),
  :global(.header),
  :global(.el-message),
  :global(.el-message-box__wrapper) {
    display: none !important;
  }
  .no-print {
    display: none !important;
  }
  .report-page {
    display: block !important;
    height: auto !important;
  }
  .rp-stage {
    display: block !important;
    overflow: visible !important;
    padding: 0 !important;
  }
  .paper {
    width: auto !important;
    min-height: auto !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
    box-shadow: none !important;
    font-size: 12pt;
  }
  .concl,
  .data-table tbody tr,
  .sug-list li,
  .notes .note-list li {
    break-inside: avoid;
  }
  .sec h2 {
    break-after: avoid;
  }
  /* 报告说明压缩一点，给末尾的落款腾出一页之内的空间，避免落款被单独推到新页 */
  .notes .note-list {
    font-size: 10pt;
    line-height: 1.55;
  }
  /* 落款（单位 + 日期）不允许被拆到下一页单独成页 */
  .paper-foot {
    margin-top: 16px !important;
    break-inside: avoid;
    break-before: avoid;
  }
}

@page {
  size: A4;
  margin: 18mm 16mm 18mm;
}
</style>
