<template>
  <div class="page-container">
    <!-- 工具条 -->
    <div class="search-bar">
      <el-form inline>
        <el-form-item label="统计窗口">
          <el-radio-group v-model="days">
            <el-radio-button :value="7">近 7 天</el-radio-button>
            <el-radio-button :value="30">近 30 天</el-radio-button>
            <el-radio-button :value="90">近 90 天</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item>
          <el-button :icon="Refresh" @click="load">刷新</el-button>
          <span class="tip" v-if="data">
            统计窗口 {{ data.period.start }} ～ {{ data.period.end }}，
            依据系统启用的 {{ data.ruleCount }} 条预警规则<template v-if="data.scoped">，
            仅统计本人可见患者</template>
          </span>
        </el-form-item>
      </el-form>
    </div>

    <!-- 概览 -->
    <div class="kpi-row" v-loading="loading">
      <div class="kpi">
        <span class="kpi-label">管理患者</span>
        <b class="kpi-val">{{ ov.patientDiseaseCount || 0 }}</b>
        <span class="kpi-sub">人·病种</span>
      </div>
      <div class="kpi">
        <span class="kpi-label">有监测数据</span>
        <b class="kpi-val">{{ ov.withData || 0 }}</b>
        <span class="kpi-sub">纳入分母</span>
      </div>
      <div class="kpi">
        <span class="kpi-label">达标</span>
        <b class="kpi-val ok">{{ ov.qualified || 0 }}</b>
        <span class="kpi-sub">核心指标全在范围内</span>
      </div>
      <div class="kpi">
        <span class="kpi-label">总体控制率</span>
        <b class="kpi-val" :class="rateClass(ov.rate)">{{ ov.rate === null || ov.rate === undefined ? '-' : ov.rate + '%' }}</b>
        <span class="kpi-sub">达标 / 有数据</span>
      </div>
      <div class="kpi">
        <span class="kpi-label">无数据</span>
        <b class="kpi-val warn">{{ ov.noData || 0 }}</b>
        <span class="kpi-sub">未计入分母</span>
      </div>
    </div>

    <!-- 图表 + 口径 -->
    <el-row :gutter="16" class="mid-row">
      <el-col :span="15">
        <div class="table-card chart-card">
          <div class="card-title">各病种控制率</div>
          <div ref="chartRef" class="chart-box"></div>
        </div>
      </el-col>
      <el-col :span="9">
        <div class="table-card note-card">
          <div class="card-title">口径说明</div>
          <ul class="note-list">
            <li v-for="(n, i) in data && data.notes ? data.notes : []" :key="i">{{ n }}</li>
          </ul>
        </div>
      </el-col>
    </el-row>

    <!-- 病种明细 -->
    <div class="table-card" v-for="d in data ? data.diseases : []" :key="d.code">
      <div class="dz-head">
        <div class="dz-left">
          <span class="dz-name">{{ d.name }}</span>
          <span class="dz-ind">判定指标：{{ d.indicatorText }}</span>
        </div>
        <div class="dz-right">
          <span class="dz-stat">
            患者 <b>{{ d.patientCount }}</b> ·
            有数据 <b>{{ d.withData }}</b> ·
            达标 <b class="ok">{{ d.qualified }}</b> ·
            无数据 <b class="warn">{{ d.noData }}</b>
          </span>
          <el-progress
            :percentage="d.rate === null ? 0 : Number(d.rate)"
            :color="progressColor"
            :stroke-width="14"
            class="dz-progress"
          >
            <span class="dz-rate">{{ d.rate === null ? '-' : d.rate + '%' }}</span>
          </el-progress>
        </div>
      </div>

      <el-table :data="d.details" border stripe size="small" empty-text="窗口内该病种无任何监测数据">
        <el-table-column prop="name" label="患者" width="110" />
        <el-table-column label="判定" width="90">
          <template #default="{ row }">
            <el-tag :type="row.qualified ? 'success' : 'danger'" size="small" effect="plain">
              {{ row.qualified ? '达标' : '不达标' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="各指标实测与参考范围" min-width="360">
          <template #default="{ row }">
            <span v-for="(it, idx) in row.items" :key="it.code" class="item-line">
              <i v-if="idx > 0" class="sep">｜</i>
              <b class="item-name">{{ it.name }}</b>&nbsp;
              <template v-if="it.count === 0">
                <span class="v-muted">未采集</span>
              </template>
              <template v-else>
                <span :class="it.qualified ? 'v-ok' : 'v-bad'">{{ fmtRange(it) }}</span>
                <span class="v-ref">（参考 {{ refText(it) }}）</span>
                <span v-if="!it.qualified" class="v-bad">超标 {{ it.abnormalCount }} 次</span>
              </template>
            </span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="90">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="goPatient(row.patientId)">档案 →</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-empty v-if="!loading && data && !data.diseases.length" description="暂无病种数据" />
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import * as echarts from 'echarts'
import { CDMS_THEME, brandColor } from '@/utils/echartsTheme'
import { getDiseaseControl } from '@/api/stat'

const router = useRouter()
const days = ref(30)
const loading = ref(false)
const data = ref(null)
const chartRef = ref(null)
let chart = null

const ov = computed(() => (data.value && data.value.overall) || {})

const load = async () => {
  loading.value = true
  try {
    const res = await getDiseaseControl(days.value)
    data.value = res.data
    await nextTick()
    renderChart()
  } catch (e) {
    ElMessage.error('控制率加载失败')
  } finally {
    loading.value = false
  }
}

const renderChart = () => {
  if (!chartRef.value) return
  if (!chart) chart = echarts.init(chartRef.value, CDMS_THEME)
  const list = (data.value && data.value.diseases) || []
  chart.setOption(
    {
      grid: { left: 58, right: 24, top: 32, bottom: 34 },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        confine: true,
        formatter: (ps) => {
          const p = ps[0]
          const d = list[p.dataIndex]
          return `${d.name}<br/>控制率 <b>${d.rate === null ? '-' : d.rate + '%'}</b><br/>达标 ${d.qualified} / 有数据 ${d.withData}（患者 ${d.patientCount}，无数据 ${d.noData}）`
        }
      },
      xAxis: {
        type: 'category',
        data: list.map((d) => d.name),
        axisTick: { show: false }
      },
      yAxis: {
        type: 'value',
        name: '控制率 %',
        max: 100,
        splitLine: { lineStyle: { type: 'dashed' } }
      },
      series: [
        {
          type: 'bar',
          barWidth: 42,
          data: list.map((d) => ({
            value: d.rate === null ? 0 : Number(d.rate),
            itemStyle: { color: barColor(d.rate), borderRadius: [4, 4, 0, 0] }
          })),
          label: {
            show: true,
            position: 'top',
            formatter: (p) => (p.value ? p.value + '%' : '无数据')
          }
        }
      ]
    },
    true
  )
}

const barColor = (rate) => {
  const v = Number(rate)
  if (Number.isNaN(v)) return '#bbb'
  if (v >= 80) return brandColor()
  if (v >= 50) return '#e6a23c'
  return '#d9534f'
}

const progressColor = (p) => (p >= 80 ? brandColor() : p >= 50 ? '#e6a23c' : '#d9534f')
const rateClass = (v) => {
  const n = Number(v)
  if (Number.isNaN(n)) return ''
  return n >= 80 ? 'ok' : n >= 50 ? 'warn' : 'bad'
}

const fmtRange = (it) => {
  const min = it.min === null || it.min === undefined ? '-' : it.min
  const max = it.max === null || it.max === undefined ? '-' : it.max
  const u = it.unit || ''
  return min === max ? `${min} ${u}` : `${min} ～ ${max} ${u}`
}

const refText = (it) => {
  const u = it.unit || ''
  if (it.lower !== null && it.lower !== undefined && it.upper !== null && it.upper !== undefined) {
    return `${it.lower} ～ ${it.upper} ${u}`
  }
  if (it.upper !== null && it.upper !== undefined) return `＜ ${it.upper} ${u}`
  if (it.lower !== null && it.lower !== undefined) return `＞ ${it.lower} ${u}`
  return '未配置规则'
}

const goPatient = (patientId) => {
  router.push({ path: `/patient/detail/${patientId}` })
}

const onResize = () => chart && chart.resize()

onMounted(() => {
  load()
  window.addEventListener('resize', onResize)
})
onBeforeUnmount(() => {
  window.removeEventListener('resize', onResize)
  if (chart) {
    chart.dispose()
    chart = null
  }
})
watch(days, () => load())
</script>

<style scoped>
.tip {
  margin-left: 12px;
  color: var(--t-sub);
  font-size: 13px;
}

/* 概览 */
.kpi-row {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 14px;
  margin-bottom: 16px;
}
.kpi {
  background: #fff;
  border: 1px solid var(--t-border, #e6e8eb);
  border-radius: 8px;
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.kpi-label {
  font-size: 13px;
  color: var(--t-sub);
}
.kpi-val {
  font-size: 26px;
  line-height: 1.2;
  font-weight: 600;
  color: #253238;
}
.kpi-val.ok {
  color: var(--brand, #00a0b0);
}
.kpi-val.warn {
  color: #e6a23c;
}
.kpi-val.bad {
  color: #d9534f;
}
.kpi-sub {
  font-size: 12px;
  color: #93a0a8;
}

/* 图表区 */
.mid-row {
  margin-bottom: 16px;
}
.chart-card,
.note-card {
  height: 100%;
}
.card-title {
  font-size: 14px;
  font-weight: 600;
  color: #253238;
  margin-bottom: 10px;
}
.chart-box {
  height: 290px;
}
.note-list {
  margin: 0;
  padding-left: 18px;
  font-size: 12.5px;
  line-height: 1.85;
  color: #55636b;
}

/* 病种卡片 */
.dz-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  padding: 4px 2px 12px;
  flex-wrap: wrap;
}
.dz-left {
  display: flex;
  align-items: baseline;
  gap: 12px;
}
.dz-name {
  font-size: 16px;
  font-weight: 600;
  color: #253238;
}
.dz-ind {
  font-size: 12.5px;
  color: var(--t-sub);
}
.dz-right {
  display: flex;
  align-items: center;
  gap: 16px;
  flex: 1;
  justify-content: flex-end;
}
.dz-stat {
  font-size: 13px;
  color: #55636b;
  white-space: nowrap;
}
.dz-stat .ok {
  color: var(--brand, #00a0b0);
}
.dz-stat .warn {
  color: #e6a23c;
}
.dz-progress {
  width: 220px;
}
.dz-rate {
  font-size: 12px;
  color: #55636b;
}

/* 指标文本 */
.item-line {
  font-size: 12.5px;
  line-height: 1.9;
}
.item-line .sep {
  color: #d8dee3;
  font-style: normal;
  margin: 0 8px 0 0;
}
.item-name {
  /* 与后面的实测值之间用 &nbsp; 隔开，这里不再加 margin，避免双重留白 */
  white-space: nowrap;
}
.v-ok {
  color: #2f8f5b;
}
.v-bad {
  color: #d9534f;
  font-weight: 600;
}
.v-muted {
  color: #a4b0b8;
}
.v-ref {
  color: #93a0a8;
}
</style>
