<template>
  <div class="page-container">
    <div class="search-bar">
      <el-form :model="query" inline>
        <el-form-item label="指标名称">
          <el-input v-model="query.indicatorName" placeholder="如：收缩压" clearable
            style="width:170px" @keyup.enter="handleQuery" />
        </el-form-item>
        <el-form-item label="编码">
          <el-input v-model="query.indicatorCode" placeholder="如：sbp" clearable
            style="width:140px" @keyup.enter="handleQuery" />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="query.status" placeholder="全部" clearable style="width:110px">
            <el-option label="启用" value="0" />
            <el-option label="停用" value="1" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :icon="Search" @click="handleQuery">搜索</el-button>
          <el-button :icon="Refresh" @click="resetQuery">重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <el-alert type="info" :closable="false" style="margin-bottom:12px"
      title="监测指标统一建模：新增一种指标只需在这里登记编码与单位，采集端、趋势图、评分权重会自动识别，不需要改表结构。" />

    <div class="table-card">
      <div class="table-toolbar">
        <el-button type="primary" :icon="Plus" @click="openAdd">新增指标</el-button>
      </div>
      <el-table v-loading="loading" :data="list" border stripe>
        <el-table-column prop="indicatorCode" label="指标编码" width="140" />
        <el-table-column prop="indicatorName" label="指标名称" min-width="150" />
        <el-table-column prop="unit" label="单位" width="110" />
        <el-table-column prop="sort" label="排序" width="80" align="center" />
        <el-table-column label="状态" width="90" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === '0' ? 'success' : 'info'" size="small">
              {{ row.status === '0' ? '启用' : '停用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="remark" label="备注" min-width="160" show-overflow-tooltip />
        <el-table-column prop="createTime" label="创建时间" width="160" />
        <el-table-column label="操作" width="140" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="openEdit(row)">编辑</el-button>
            <el-button type="danger" link size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination">
        <el-pagination v-model:current-page="query.pageNum" v-model:page-size="query.pageSize"
          :page-sizes="[10, 20, 50]" :total="total" layout="total, sizes, prev, pager, next, jumper"
          @size-change="loadList" @current-change="loadList" />
      </div>
    </div>

    <el-dialog v-model="dialogVisible" :title="form.indicatorId ? '编辑指标' : '新增指标'" width="520px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="90px">
        <el-form-item label="指标编码" prop="indicatorCode">
          <el-input v-model="form.indicatorCode" placeholder="英文小写，如 sbp / fbg" :disabled="!!form.indicatorId" />
        </el-form-item>
        <el-form-item label="指标名称" prop="indicatorName">
          <el-input v-model="form.indicatorName" placeholder="如：收缩压" />
        </el-form-item>
        <el-form-item label="单位" prop="unit">
          <el-input v-model="form.unit" placeholder="如：mmHg / mmol/L / 次/分" />
        </el-form-item>
        <el-form-item label="排序">
          <el-input-number v-model="form.sort" :min="1" :max="999" />
        </el-form-item>
        <el-form-item label="状态">
          <el-radio-group v-model="form.status">
            <el-radio value="0">启用</el-radio>
            <el-radio value="1">停用</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="2" maxlength="200" show-word-limit />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Refresh, Plus } from '@element-plus/icons-vue'
import { listIndicator, addIndicator, updateIndicator, delIndicator } from '@/api/system'

const loading = ref(false)
const list = ref([])
const total = ref(0)
const query = reactive({ pageNum: 1, pageSize: 10, indicatorName: '', indicatorCode: '', status: '' })

const dialogVisible = ref(false)
const submitting = ref(false)
const formRef = ref()
const form = reactive({
  indicatorId: null, indicatorCode: '', indicatorName: '', unit: '', sort: 1, status: '0', remark: ''
})

const rules = {
  indicatorCode: [{ required: true, message: '请输入指标编码', trigger: 'blur' }],
  indicatorName: [{ required: true, message: '请输入指标名称', trigger: 'blur' }],
  unit: [{ required: true, message: '请输入单位', trigger: 'blur' }]
}

const loadList = async () => {
  loading.value = true
  try {
    const res = await listIndicator(query)
    const d = res.data || {}
    list.value = d.rows || []
    total.value = d.total || 0
  } finally {
    loading.value = false
  }
}

const handleQuery = () => {
  query.pageNum = 1
  loadList()
}

const resetQuery = () => {
  Object.assign(query, { pageNum: 1, pageSize: 10, indicatorName: '', indicatorCode: '', status: '' })
  loadList()
}

const resetForm = () => {
  Object.assign(form, {
    indicatorId: null, indicatorCode: '', indicatorName: '', unit: '', sort: 1, status: '0', remark: ''
  })
}

const openAdd = () => {
  resetForm()
  form.sort = (total.value || 0) + 1
  dialogVisible.value = true
}

const openEdit = (row) => {
  resetForm()
  Object.assign(form, row)
  dialogVisible.value = true
}

const handleSubmit = async () => {
  await formRef.value.validate()
  submitting.value = true
  try {
    const res = form.indicatorId ? await updateIndicator(form) : await addIndicator(form)
    if (res.code === 200) {
      ElMessage.success(form.indicatorId ? '已保存' : '已新增')
      dialogVisible.value = false
      loadList()
    } else {
      ElMessage.error(res.msg || '保存失败')
    }
  } finally {
    submitting.value = false
  }
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(
      `确定删除指标「${row.indicatorName}」吗？已有历史监测数据不受影响，但新采集将不再识别该编码。`,
      '删除指标',
      { type: 'warning', confirmButtonText: '确定删除', cancelButtonText: '取消' }
    )
  } catch (e) {
    return
  }
  const res = await delIndicator(row.indicatorId)
  if (res.code === 200) {
    ElMessage.success('已删除')
    loadList()
  } else {
    ElMessage.error(res.msg || '删除失败')
  }
}

onMounted(loadList)
</script>

<style scoped>
.pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}
</style>
