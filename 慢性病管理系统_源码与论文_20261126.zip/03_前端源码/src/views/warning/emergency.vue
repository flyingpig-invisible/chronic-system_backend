<template>
  <div class="page-container">
    <div class="search-bar">
      <el-form :model="query" inline>
        <el-form-item label="患者">
          <PatientSelect v-model="query.patientId" width="200px" style="display:inline-block" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :icon="Search" @click="handleQuery">搜索</el-button>
          <el-button :icon="Refresh" @click="resetQuery">重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <el-alert type="info" :closable="false" style="margin-bottom:12px"
      title="高危预警触发后，系统自动通知值班医生并联系家属，联动过程在此留痕，可按患者追溯。" />

    <div class="table-card">
      <el-table v-loading="loading" :data="list" border stripe>
        <el-table-column prop="linkId" label="联动编号" width="100" align="center" />
        <el-table-column prop="patientName" label="患者" width="100" />
        <el-table-column label="渠道" width="110">
          <template #default="{ row }">
            <el-tag :type="channelTag(row.channel)" size="small">{{ channelName(row.channel) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="receiver" label="接收方" min-width="200" show-overflow-tooltip />
        <el-table-column prop="linkResult" label="联动结果" min-width="300" show-overflow-tooltip />
        <el-table-column prop="linkBy" label="发起人" width="100" />
        <el-table-column prop="linkTime" label="联动时间" width="160" />
        <el-table-column label="关联预警" width="100" align="center">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="goWarning(row)">#{{ row.warningId }}</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination">
        <el-pagination v-model:current-page="query.pageNum" v-model:page-size="query.pageSize"
          :page-sizes="[10, 20, 50]" :total="total" layout="total, sizes, prev, pager, next, jumper"
          @size-change="loadList" @current-change="loadList" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { Search, Refresh } from '@element-plus/icons-vue'
import { listEmergency } from '@/api/warning'

const router = useRouter()
const loading = ref(false)
const list = ref([])
const total = ref(0)

const query = reactive({ pageNum: 1, pageSize: 10, patientId: null })

// 后端实体定义：联动渠道 120 / hospital / family / community，库内以 1~4 存储
const channelName = (c) => ({ 1: '120 急救', 2: '转诊医院', 3: '家属通知', 4: '社区上报' }[c] || '未标注')
const channelTag = (c) => ({ 1: 'danger', 2: 'warning', 3: 'primary', 4: 'info' }[c] || 'info')

const loadList = async () => {
  loading.value = true
  try {
    const res = await listEmergency(query)
    const d = res.data || {}
    list.value = d.rows || []
    total.value = d.total || 0
  } finally {
    loading.value = false
  }
}

const handleQuery = () => {
  query.pageNum = 1
  loadList()
}

const resetQuery = () => {
  Object.assign(query, { pageNum: 1, pageSize: 10, patientId: null })
  loadList()
}

const goWarning = (row) => {
  router.push({ path: '/warning/list', query: { patientId: row.patientId } })
}

onMounted(loadList)
</script>

<style scoped>
.pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}
</style>
